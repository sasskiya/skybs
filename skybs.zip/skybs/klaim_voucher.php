<?php
session_start();
include "database.php";
// Cek login
if (!isset($_SESSION['id_user'])) {
    echo "<script>alert('Silakan login terlebih dahulu!'); window.location='login.php';</script>";
    exit;
}

$id_user = (int)$_SESSION['id_user'];
// Deteksi asal halaman (default ke checkout.php jika tidak ada parameter)
$redirect_target = 'checkout.php';
if (isset($_GET['from']) && $_GET['from'] === 'war') {
    $id_transaksi_war = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    $redirect_target = $id_transaksi_war > 0 ? "checkout_war.php?id=$id_transaksi_war" : "checkout_war.php";
}
// Cek ke database apakah user ini sudah pernah klaim kuis sebelumnya
$stmt_check = mysqli_prepare($conn, "SELECT kuis_claimed FROM users WHERE id_user = ?");
mysqli_stmt_bind_param($stmt_check, "i", $id_user);
mysqli_stmt_execute($stmt_check);
$user_status = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_check));

if ($user_status && isset($user_status['kuis_claimed']) && $user_status['kuis_claimed'] == 1) {
    echo "<script>
        alert('⚠️ Anda sudah pernah menggunakan kesempatan kuis voucher ini! Voucher hanya dapat diklaim 1 kali per akun.');
        window.location='$redirect_target';
    </script>";
    exit;
}
// Daftar soal kuis
$daftar_soal = [
    [
        'pertanyaan' => 'Apa nama platform toko buku digital tempat Anda berbelanja saat ini?',
        'pilihan' => ['Gramedia Digital', 'SKYBS BookStore', 'Google Books', 'Amazon Kindle'],
        'kunci' => 'SKYBS BookStore'
    ],
    [
        'pertanyaan' => 'Di kota manakah gudang pengiriman utama SKYBS BookStore berada?',
        'pilihan' => ['Bandung', 'Surabaya', 'Jakarta', 'Yogyakarta'],
        'kunci' => 'Jakarta'
    ]
];

$index_soal = isset($_GET['soal']) ? (int)$_GET['soal'] : array_rand($daftar_soal);
if (!isset($daftar_soal[$index_soal])) $index_soal = 0;
$soal_aktif = $daftar_soal[$index_soal];
// Jika user mengirimkan jawaban
if (isset($_POST['kirim_jawaban'])) {
    $jawaban_user = trim($_POST['jawaban'] ?? '');
    $kunci_jawaban = trim($_POST['kunci_jawaban'] ?? '');

    if ($jawaban_user === $kunci_jawaban) {
        // Update status di database bahwa user ini SUDAH KLAIM (kuis_claimed = 1)
        $stmt_update = mysqli_prepare($conn, "UPDATE users SET kuis_claimed = 1 WHERE id_user = ?");
        mysqli_stmt_bind_param($stmt_update, "i", $id_user);
        mysqli_stmt_execute($stmt_update);

        // Set session promo diskon 30% atau sesuai kebutuhan
        $_SESSION['applied_promo'] = 'SKYBSHEBAT';
        $_SESSION['discount_rate'] = 0.30; 

        // Menentukan pemisah query parameter (? atau &) secara dinamis agar tidak 404
        $separator = (strpos($redirect_target, '?') !== false) ? '&' : '?';

        echo "<script>
            alert('🎉 Selamat! Jawaban Benar. Anda mendapatkan Voucher Diskon (SKYBSHEBAT). Voucher ini telah diklaim!');
            window.location='$redirect_target{$separator}promo=SKYBSHEBAT';
        </script>";
        exit;
    } else {
        $rand_next = array_rand($daftar_soal);
        $separator = (strpos($redirect_target, '?') !== false) ? '&' : '?';
        $from_param = isset($_GET['from']) ? "&from=" . htmlspecialchars($_GET['from']) : "";
        $id_param = isset($_GET['id']) ? "&id=" . (int)$_GET['id'] : "";
        
        echo "<script>
            alert('❌ Jawaban salah. Coba lagi!');
            window.location='klaim_voucher.php?soal=$rand_next$from_param$id_param';
        </script>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kuis Tantangan Berhadiah Kupon | SKY BookStore</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        body { background-color: #F7F1DE; font-family: 'Plus Jakarta Sans', sans-serif; color: #4E220F; min-height: 100vh; display: flex; flex-direction: column; }
        .card-quiz { background: #FFFFFF; border-radius: 20px; box-shadow: 0 10px 25px rgba(78, 34, 15, 0.08); border: 1px solid rgba(78, 34, 15, 0.08); }
        .option-box { background: #F7F1DE; border: 1px solid rgba(78, 34, 15, 0.1); border-radius: 12px; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark" style="background: #4E220F;">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php"><i class="fa-solid fa-book-open text-warning me-2"></i>SKYBS BookStore</a>
            <a href="<?= htmlspecialchars($redirect_target); ?>" class="btn btn-sm btn-outline-light rounded-pill px-3">Kembali ke Checkout</a>
        </div>
    </nav>

    <div class="container py-5 my-auto">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card card-quiz p-4 p-md-5">
                    <div class="text-center mb-4">
                        <span class="badge bg-warning text-dark fw-bold px-3 py-1 mb-2">Kuis Tantangan Berhadiah Diskon</span>
                        <h3 class="fw-bold" style="font-family: 'Playfair Display', serif;">Uji Wawasan Literasi</h3>
                        <p class="text-muted small">Kesempatan klaim hanya diberikan <strong>1 kali</strong> untuk akun Anda.</p>
                    </div>

                    <form method="POST">
                        <input type="hidden" name="kunci_jawaban" value="<?= htmlspecialchars($soal_aktif['kunci']); ?>">
                        
                        <div class="mb-4">
                            <label class="fw-bold mb-3 text-dark fs-6">
                                <i class="fa-solid fa-circle-question text-warning me-2"></i><?= htmlspecialchars($soal_aktif['pertanyaan']); ?>
                            </label>

                            <?php foreach ($soal_aktif['pilihan'] as $opt): ?>
                                <div class="form-check option-box p-3 mb-2">
                                    <input class="form-check-input ms-0 me-3" type="radio" name="jawaban" id="opt_<?= md5($opt); ?>" value="<?= htmlspecialchars($opt); ?>" required>
                                    <label class="form-check-label fw-semibold w-100" for="opt_<?= md5($opt); ?>">
                                        <?= htmlspecialchars($opt); ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <button type="submit" name="kirim_jawaban" class="btn btn-dark w-100 rounded-pill fw-bold py-3 shadow-sm" style="background: #4E220F;">
                            <i class="fa-solid fa-paper-plane me-2 text-warning"></i> Kirim Jawaban & Klaim Diskon
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>