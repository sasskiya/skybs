<?php
session_start();
require_once "database.php";

if (!isset($_SESSION['id_admin'])) {
    header("Location: login.php");
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Ambil data menggunakan JOIN ke tabel pembayaran
$stmt = mysqli_prepare($conn, "SELECT p.*, u.nama, bayar.metode, bayar.bukti, bayar.status AS status_bayar 
                               FROM pesanan p 
                               JOIN users u ON p.id_user = u.id_user 
                               LEFT JOIN pembayaran bayar ON p.id_pesanan = bayar.id_pesanan 
                               WHERE p.id_pesanan = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$pesanan = mysqli_stmt_get_result($stmt)->fetch_assoc();

if (!$pesanan) {
    echo "<script>alert('Pesanan tidak ditemukan.'); location.href='admin_pesanan.php';</script>";
    exit;
}

$namaFileBukti = trim($pesanan['bukti'] ?? '');
$metode = trim($pesanan['metode'] ?? $pesanan['metode_pembayaran'] ?? '');

$pathGambar = "";
if (!empty($namaFileBukti)) {
    if (filter_var($namaFileBukti, FILTER_VALIDATE_URL) || file_exists($namaFileBukti)) {
        $pathGambar = $namaFileBukti;
    } elseif (file_exists("img/bukti/" . $namaFileBukti)) {
        $pathGambar = "img/bukti/" . $namaFileBukti;
    } elseif (file_exists("uploads/" . $namaFileBukti)) {
        $pathGambar = "uploads/" . $namaFileBukti;
    } elseif (file_exists("../" . $namaFileBukti)) {
        $pathGambar = "../" . $namaFileBukti;
    } else {
        $pathGambar = "uploads/" . $namaFileBukti;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Bukti Pembayaran - Pesanan #<?= $pesanan['id_pesanan']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        body { background: #F7F1DE; font-family: 'Plus Jakarta Sans', sans-serif; color: #4E220F; padding: 40px; }
        .card-bukti { background: #fff; border-radius: 20px; padding: 30px; box-shadow: 0 10px 25px rgba(78, 34, 15, 0.08); max-width: 600px; margin: 0 auto; }
    </style>
</head>
<body>
    <div class="card-bukti">
        <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3">
            <h4 class="fw-bold mb-0"><i class="fa-solid fa-receipt text-warning me-2"></i> Bukti Pembayaran</h4>
            <a href="admin_pesanan.php" class="btn btn-sm btn-outline-secondary rounded-pill px-3">
                <i class="fa-solid fa-arrow-left me-1"></i> Kembali
            </a>
        </div>

        <div class="mb-3 small">
            <p class="mb-1"><strong>ID Pesanan:</strong> #<?= $pesanan['id_pesanan']; ?></p>
            <p class="mb-1"><strong>Nama Customer:</strong> <?= htmlspecialchars($pesanan['nama']); ?></p>
            <p class="mb-1"><strong>Total Tagihan:</strong> Rp <?= number_format($pesanan['total_harga'] ?? $pesanan['total'] ?? 0, 0, ',', '.'); ?></p>
            <p class="mb-0"><strong>Metode Pembayaran:</strong> <?= htmlspecialchars($metode); ?></p>
        </div>

        <hr>

        <div class="text-center my-4">
            <?php if (strtoupper($metode) === 'COD'): ?>
                <div class="alert alert-warning py-4">
                    <i class="fa-solid fa-truck fs-2 mb-2 d-block"></i>
                    <strong>Pesanan COD</strong><br>Pembayaran dilakukan tunai di tempat. Bukti transfer tidak diperlukan.
                </div>
            <?php elseif (!empty($namaFileBukti)): ?>
                <div class="border rounded p-2 bg-light d-inline-block">
                    <img src="<?= htmlspecialchars($pathGambar); ?>" alt="Bukti Transfer" class="img-fluid rounded" style="max-height: 450px;" onerror="this.src='https://via.placeholder.com/300x400?text=File+Gambar+Tidak+Ditemukan';">
                </div>
                <div class="text-muted mt-2" style="font-size: 11px;">
                    File terdeteksi di database: <code><?= htmlspecialchars($namaFileBukti); ?></code>
                </div>
            <?php else: ?>
                <div class="alert alert-secondary py-4">
                    <i class="fa-solid fa-circle-exclamation fs-2 mb-2 d-block"></i>
                    Customer belum mengunggah file bukti pembayaran.
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>