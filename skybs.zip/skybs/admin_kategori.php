<?php
session_start();
include "database.php";

if (!isset($_SESSION['id_admin'])) {
    header("Location: login.php");
    exit;
}

// Nama admin default
$nama_admin = isset($_SESSION['nama']) && !empty($_SESSION['nama'])
    ? $_SESSION['nama']
    : 'Saskiya';

// Tambah Data
if (isset($_POST['tambah'])) {
    $nama_kategori = trim($_POST['nama_kategori']);
    if (!empty($nama_kategori)) {
        $stmt = mysqli_prepare($conn, "INSERT INTO kategori (nama_kategori) VALUES (?)");
        mysqli_stmt_bind_param($stmt, "s", $nama_kategori);
        mysqli_stmt_execute($stmt);
    }
    header("Location: admin_kategori.php");
    exit;
}

// Hapus Data
if (isset($_GET['hapus'])) {
    $id_hapus = (int)$_GET['hapus'];
    $stmt = mysqli_prepare($conn, "DELETE FROM kategori WHERE id_kategori = ?");
    mysqli_stmt_bind_param($stmt, "i", $id_hapus);
    mysqli_stmt_execute($stmt);
    header("Location: admin_kategori.php");
    exit;
}

// Edit Data
if (isset($_POST['update'])) {
    $id_kategori = (int)$_POST['id_kategori'];
    $nama_kategori = trim($_POST['nama_kategori']);
    if (!empty($nama_kategori)) {
        $stmt = mysqli_prepare($conn, "UPDATE kategori SET nama_kategori = ? WHERE id_kategori = ?");
        mysqli_stmt_bind_param($stmt, "si", $nama_kategori, $id_kategori);
        mysqli_stmt_execute($stmt);
    }
    header("Location: admin_kategori.php");
    exit;
}

$edit = null;
if (isset($_GET['edit'])) {
    $id_edit = (int)$_GET['edit'];
    $stmt = mysqli_prepare($conn, "SELECT * FROM kategori WHERE id_kategori = ?");
    mysqli_stmt_bind_param($stmt, "i", $id_edit);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $edit = mysqli_fetch_assoc($res);
}

$data = mysqli_query($conn, "SELECT * FROM kategori ORDER BY id_kategori DESC");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Kategori Buku | SKY Bookstore Admin</title>

    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --brand-card-bg: #FCF9F0;
            
            --shadow-sm: 0 4px 18px rgba(78, 34, 15, 0.05);
            --shadow-md: 0 10px 25px rgba(78, 34, 15, 0.1);

            --radius-md: 16px;
            --radius-lg: 20px;
        }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }

        h1, h2, h3, h4, h5, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        /* --- SIDEBAR NAVIGATION --- */
        .sidebar {
            width: 270px;
            height: 100vh;
            background: var(--brand-dark-brown);
            position: fixed;
            left: 0;
            top: 0;
            z-index: 1000;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            display: flex;
            flex-direction: column;
            transition: all 0.3s ease;
        }

        .sidebar-brand {
            color: white;
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.12);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-badge {
            background: rgba(176, 186, 153, 0.25);
            border: 1px solid var(--brand-sage-green);
            color: var(--brand-sage-green);
            padding: 2px 8px;
            border-radius: 6px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 700;
        }

        .sidebar-menu {
            padding: 20px 0;
            flex-grow: 1;
            overflow-y: auto;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            padding: 13px 25px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }

        .sidebar a i {
            width: 32px;
            font-size: 16px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: rgba(255, 255, 255, 0.12);
            color: #FFFFFF;
            border-left-color: var(--brand-warm-brown);
        }

        .btn-view-website {
            margin: 18px 20px 0;
            padding: 12px 16px !important;
            border-radius: 10px;
            background: var(--brand-sage-green);
            color: var(--brand-dark-brown) !important;
            border: 1px solid var(--brand-sage-green) !important;
            font-weight: 700 !important;
            justify-content: center;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-view-website:hover {
            background: #DCCFC0;
            transform: translateY(-2px);
        }

        /* --- CONTENT WRAPPER --- */
        .content {
            margin-left: 270px;
            padding: 35px 40px;
            transition: all 0.3s ease;
        }

        .profile-badge {
            background: #FFFFFF;
            padding: 8px 18px;
            border-radius: 50px;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(78, 34, 15, 0.08);
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        /* --- CARDS & FORM --- */
        .card-custom {
            background: var(--brand-card-bg);
            border: 1px solid rgba(78, 34, 15, 0.08);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .card-custom:hover {
            box-shadow: var(--shadow-md);
        }

        .form-control-custom {
            background: #FFFFFF;
            border: 1px solid rgba(78, 34, 15, 0.2);
            border-radius: 12px;
            padding: 12px 16px;
            font-size: 14px;
            color: var(--brand-dark-brown);
            transition: all 0.3s ease;
        }

        .form-control-custom:focus {
            background: #FFFFFF;
            border-color: var(--brand-warm-brown);
            box-shadow: 0 0 0 4px rgba(157, 102, 56, 0.15);
        }

        /* --- BUTTONS --- */
        .btn-sage {
            background: var(--brand-warm-brown);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 10px 24px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-sage:hover {
            background: var(--brand-dark-brown);
            color: white;
            transform: translateY(-2px);
        }

        .btn-gold {
            background: var(--brand-sage-green);
            color: var(--brand-dark-brown);
            border: none;
            border-radius: 50px;
            padding: 10px 24px;
            font-weight: 700;
            transition: all 0.3s ease;
        }

        .btn-gold:hover {
            background: #9fa988;
            color: var(--brand-dark-brown);
            transform: translateY(-2px);
        }

        .btn-action-edit {
            background: #EAE3D2;
            color: var(--brand-dark-brown);
            border: none;
            border-radius: 10px;
            padding: 6px 14px;
            font-size: 13px;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        .btn-action-edit:hover {
            background: var(--brand-sage-green);
            color: var(--brand-dark-brown);
        }

        .btn-action-delete {
            background: #F8D7DA;
            color: #842029;
            border: none;
            border-radius: 10px;
            padding: 6px 14px;
            font-size: 13px;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        .btn-action-delete:hover {
            background: #F5C2C7;
        }

        .btn-logout {
            background: rgba(220, 53, 69, 0.15);
            color: #FF6B6B;
            border: 1px solid rgba(220, 53, 69, 0.2);
            width: 100%;
            border-radius: 12px;
            padding: 10px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .btn-logout:hover {
            background: #DC3545;
            color: white;
        }

        /* --- TABLE --- */
        .table-custom {
            margin-bottom: 0;
            vertical-align: middle;
            background: #ffffff;
        }

        .table-custom thead {
            background: var(--brand-dark-brown) !important;
        }

        .table-custom thead th {
            color: #FFFFFF !important;
            font-weight: 700;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            padding: 18px 16px;
            border: none;
            background-color: var(--brand-dark-brown) !important;
        }

        .table-custom tbody td {
            padding: 16px;
            border-bottom: 1px solid rgba(78, 34, 15, 0.05);
            color: var(--brand-dark-brown);
        }

        .table-custom tbody tr:hover {
            background-color: rgba(157, 102, 56, 0.03);
        }

        .category-badge {
            background: rgba(176, 186, 153, 0.3);
            color: var(--brand-dark-brown);
            font-weight: 700;
            font-size: 12px;
            padding: 6px 14px;
            border-radius: 50px;
            display: inline-block;
            border: 1px solid var(--brand-sage-green);
        }

        @media (max-width: 992px) {
            .sidebar { 
                width: 100%; 
                height: auto; 
                position: relative; 
            }
            .content { 
                margin-left: 0; 
                padding: 20px 15px; 
            }
        }
    </style>
</head>

<body>

    <!-- SIDEBAR NAVIGATION -->
    <div class="sidebar">
        <div class="sidebar-brand">
            <i class="fa-solid fa-book-open text-warning fs-4"></i>
            <div>
                <h5 class="fw-bold mb-0 text-white">SKYBS Admin</h5>
                <span class="brand-badge">Panel System</span>
            </div>
        </div>

        <div class="sidebar-menu">
            <a href="admin.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
            <a href="admin_kategori.php" class="active"><i class="fa-solid fa-tags"></i> Kategori Buku</a>
            <a href="admin_buku.php"><i class="fa-solid fa-book"></i> Data Buku</a>
            <a href="admin_user.php"><i class="fa-solid fa-users"></i> Data User</a>
            <a href="admin_pesanan.php"><i class="fa-solid fa-cart-shopping"></i> Pesanan</a>
            <a href="admin_war.php"><i class="fa-solid fa-ticket"></i> War Tiket</a>
            <a href="admin_contact.php"><i class="fa-solid fa-comments"></i> Pesan User</a>

            <a href="index.php" target="_blank" class="btn-view-website">
                <i class="fa-solid fa-eye"></i> Buka Full Website
            </a>
        </div>

        <div class="p-3">
            <form action="logout.php" method="POST">
                <button type="submit" class="btn btn-logout d-flex align-items-center justify-content-center gap-2" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <span>Logout</span>
                </button>
            </form>
        </div>
    </div>

    <!-- MAIN CONTENT AREA -->
    <div class="content animate__animated animate__fadeIn">

        <!-- HEADER TOPBAR -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 pb-3 border-bottom border-secondary-subtle">
            <div>
                <h2 class="font-heading fw-bold mb-1" style="color: var(--brand-dark-brown);">Kategori Buku</h2>
                <p class="text-muted mb-0">Kelola dan atur pengelompokan kategori koleksi buku SKY Bookstore</p>
            </div>
            <div>
                <div class="profile-badge">
                    <i class="fa-solid fa-user-gear fs-5" style="color: var(--brand-warm-brown);"></i>
                    <span class="fw-bold fs-6" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($nama_admin); ?> (Admin)</span>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- FORM INPUT / EDIT -->
            <div class="col-lg-4">
                <div class="card-custom p-4">
                    <h5 class="fw-bold mb-3 font-heading" style="color: var(--brand-dark-brown);">
                        <?= $edit ? '<i class="fa-solid fa-pen-to-square text-warning me-2"></i>Edit Kategori' : '<i class="fa-solid fa-circle-plus text-success me-2"></i>Tambah Kategori' ?>
                    </h5>

                    <form method="POST">
                        <?php if ($edit): ?>
                            <input type="hidden" name="id_kategori" value="<?= $edit['id_kategori']; ?>">
                            <div class="mb-3">
                                <label class="form-label small fw-bold text-muted">Nama Kategori</label>
                                <input type="text" name="nama_kategori" class="form-control form-control-custom" value="<?= htmlspecialchars($edit['nama_kategori']); ?>" required autocomplete="off">
                            </div>
                            <div class="d-flex gap-2">
                                <button name="update" type="submit" class="btn btn-gold w-100">
                                    <i class="fa-solid fa-floppy-disk me-1"></i> Simpan
                                </button>
                                <a href="admin_kategori.php" class="btn btn-light rounded-pill w-100 text-muted fw-semibold">Batal</a>
                            </div>
                        <?php else: ?>
                            <div class="mb-3">
                                <label class="form-label small fw-bold text-muted">Nama Kategori Baru</label>
                                <input type="text" name="nama_kategori" class="form-control form-control-custom" placeholder="Misal: Novel, Komik, Bisnis" required autocomplete="off">
                            </div>
                            <button name="tambah" type="submit" class="btn btn-sage w-100">
                                <i class="fa-solid fa-plus me-1"></i> Tambahkan
                            </button>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <!-- TABEL DAFTAR KATEGORI -->
            <div class="col-lg-8">
                <div class="card-custom">
                    <div class="table-responsive">
                        <table class="table table-custom">
                            <thead>
                                <tr>
                                    <th class="text-center" width="70">No</th>
                                    <th>Nama Kategori</th>
                                    <th class="text-center" width="160">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (mysqli_num_rows($data) > 0): ?>
                                    <?php 
                                    $no = 1;
                                    while ($d = mysqli_fetch_assoc($data)): 
                                    ?>
                                        <tr>
                                            <td class="text-center fw-bold text-muted"><?= $no++; ?></td>
                                            <td>
                                                <span class="fw-bold fs-6 d-block mb-1" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($d['nama_kategori']); ?></span>
                                                <span class="category-badge">ID: #<?= $d['id_kategori']; ?></span>
                                            </td>
                                            <td class="text-center">
                                                <div class="d-flex justify-content-center gap-2">
                                                    <a href="?edit=<?= $d['id_kategori']; ?>" class="btn btn-action-edit" title="Edit Kategori">
                                                        <i class="fa-solid fa-pen"></i> Edit
                                                    </a>
                                                    <a href="?hapus=<?= $d['id_kategori']; ?>" class="btn btn-action-delete" onclick="return confirm('Menghapus kategori akan mempengaruhi buku terkait. Yakin ingin menghapus?')" title="Hapus Kategori">
                                                        <i class="fa-solid fa-trash"></i> Hapus
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="3" class="text-center py-5 text-muted">
                                            <i class="fa-solid fa-tags fs-1 opacity-50 mb-3 d-block"></i>
                                            Belum ada data kategori buku.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <footer class="mt-5 text-center text-muted small">
            <p class="mb-0">&copy; <?= date("Y"); ?> <strong>SKY Bookstore</strong> - Admin Dashboard System.</p>
        </footer>

    </div>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>