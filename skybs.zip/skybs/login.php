<?php
session_start();
include "database.php";

$error = "";

if (isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        $error = "Email dan password wajib diisi!";
    } else {
        $stmt = mysqli_prepare($conn, "SELECT id_user, nama, password FROM users WHERE email = ?");
        if (!$stmt) {
            die("Gagal menyiapkan query: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($result)) {
            // Verifikasi password (mendukung teks biasa atau password_hash)
            if (password_verify($password, $row['password']) || $password === $row['password']) {
                
                // === CEK APAKAH INI AKUN ADMIN ATAU USER BIASA ===
                if ($email === 'admin@skybs.com') {
                    // Set session khusus admin
                    $_SESSION['id_admin'] = $row['id_user'];
                    $_SESSION['nama_admin'] = $row['nama'];

                    header("location: admin.php"); // Langsung masuk ke halaman admin!
                    exit;
                } else {
                    // Set session user biasa
                    $_SESSION['id_user'] = $row['id_user'];
                    $_SESSION['nama_user'] = $row['nama'];

                    header("location: index.php"); // Masuk ke beranda toko biasa
                    exit;
                }

            } else {
                $error = "Password yang Anda masukkan salah!";
            }
        } else {
            $error = "Email tidak terdaftar!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | SKY BookStore</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        body { background-color: #F7F1DE; font-family: 'Plus Jakarta Sans', sans-serif; color: #4E220F; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .card-login { background: #FFFFFF; border-radius: 20px; box-shadow: 0 10px 25px rgba(78, 34, 15, 0.08); border: 1px solid rgba(78, 34, 15, 0.08); width: 100%; max-width: 420px; }
        .form-control { background: #F7F1DE; border: 1px solid rgba(78, 34, 15, 0.15); border-radius: 12px; padding: 12px 16px; color: #4E220F; }
        .form-control:focus { background: #FFFFFF; border-color: #9D6638; box-shadow: 0 0 0 4px rgba(157, 102, 56, 0.15); }
        .btn-custom { background: #9D6638; color: white; border-radius: 50px; padding: 12px; font-weight: 700; border: none; transition: all 0.2s; }
        .btn-custom:hover { background: #4E220F; color: white; }
    </style>
</head>
<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card card-login p-4 p-md-5">
                    <div class="text-center mb-4">
                        <a href="index.php" class="text-decoration-none">
                            <i class="fa-solid fa-book-open text-warning fs-1 mb-2"></i>
                        </a>
                        <h3 class="fw-bold" style="font-family: 'Playfair Display', serif; color: #4E220F;">SKY BookStore</h3>
                        <p class="text-muted small">Silakan masuk ke akun Anda untuk melanjutkan.</p>
                    </div>

                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger py-2 small text-center mb-3 rounded-3">
                            <?= htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">Email</label>
                            <input type="email" name="email" class="form-control" placeholder="nama@email.com" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label small fw-bold text-muted">Password</label>
                            <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                        </div>
                        <button type="submit" name="login" class="btn btn-custom w-100 shadow-sm mb-3">
                            <i class="fa-solid fa-right-to-bracket me-2"></i> Masuk
                        </button>
                        <div class="text-center small">
                            <span class="text-muted">Belum punya akun?</span> <a href="register.php" class="fw-bold text-decoration-none" style="color: #9D6638;">Daftar di sini</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
</html>