<?php
session_start();
include "database.php";

if (isset($_POST['register'])) {
    $nama     = trim($_POST['nama']);
    $email    = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $no_hp    = trim($_POST['no_hp']);
    $alamat   = trim($_POST['alamat']);
    $foto     = "default.png";

    // 1. Cek Email Terdaftar
    $stmt_cek = mysqli_prepare($conn, "SELECT id_user FROM users WHERE email = ?");
    mysqli_stmt_bind_param($stmt_cek, "s", $email);
    mysqli_stmt_execute($stmt_cek);
    mysqli_stmt_store_result($stmt_cek);

    if (mysqli_stmt_num_rows($stmt_cek) > 0) {
        echo "<script>
            alert('Email sudah terdaftar! Silakan gunakan email lain.');
            window.location='register.php';
        </script>";
        exit;
    } else {
        // 2. Simpan Data User Baru
        $stmt_ins = mysqli_prepare($conn, "
            INSERT INTO users (nama, email, password, no_hp, alamat, foto) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        mysqli_stmt_bind_param($stmt_ins, "ssssss", $nama, $email, $password, $no_hp, $alamat, $foto);

        if (mysqli_stmt_execute($stmt_ins)) {
            // Clear session lama supaya tidak tertukar
            session_unset();
            session_destroy();

            echo "<script>
                alert('Registrasi akun berhasil! Silakan login dengan akun baru Anda.');
                window.location='login.php';
            </script>";
            exit;
        } else {
            echo "<script>alert('Gagal mendaftar. Terjadi kesalahan sistem.');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun Baru | SKY BookStore</title>

    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-cream-bg: #F7F1DE;
            --shadow-md: 0 10px 30px rgba(78, 34, 15, 0.1);
            --radius-lg: 20px;
        }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 30px 0;
        }

        h1, h2, h3, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        .card-auth {
            background: #FFFFFF;
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
            width: 100%;
            max-width: 500px;
            border: 1px solid rgba(78, 34, 15, 0.08);
        }

        .form-control-custom {
            background: #FCF9F2;
            border: 1px solid #E6DCD1;
            border-radius: 12px;
            padding: 10px 16px;
            font-size: 14px;
            color: var(--brand-dark-brown);
        }

        .form-control-custom:focus {
            background: #FFFFFF;
            border-color: var(--brand-warm-brown);
            box-shadow: 0 0 0 4px rgba(157, 102, 56, 0.1);
        }

        .btn-auth {
            background: var(--brand-dark-brown);
            color: white;
            border-radius: 50px;
            padding: 12px;
            font-weight: 700;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .btn-auth:hover {
            background: var(--brand-warm-brown);
            color: white;
        }
    </style>
</head>

<body>

    <div class="container p-3 d-flex justify-content-center">
        <div class="card-auth p-4 p-md-5">

            <!-- HEADER TITLE -->
            <div class="text-center mb-4">
                <i class="fa-solid fa-book-open fs-1 mb-2" style="color: var(--brand-warm-brown);"></i>
                <h3 class="font-heading fw-bold mb-1">Daftar Akun Baru</h3>
                <p class="text-muted small">Buat akun untuk mulai berbelanja di SKY BookStore</p>
            </div>

            <!-- FORM REGISTER -->
            <form method="POST">
                
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Nama Lengkap <span class="text-danger">*</span></label>
                    <input type="text" name="nama" class="form-control form-control-custom" placeholder="Masukkan nama lengkap" required autocomplete="off">
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Alamat Email <span class="text-danger">*</span></label>
                    <input type="email" name="email" class="form-control form-control-custom" placeholder="nama@email.com" required autocomplete="off">
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Kata Sandi <span class="text-danger">*</span></label>
                    <input type="password" name="password" class="form-control form-control-custom" placeholder="Buat kata sandi yang aman" required>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">No. WhatsApp / HP</label>
                    <input type="text" name="no_hp" class="form-control form-control-custom" placeholder="Contoh: 081234567890">
                </div>

                <div class="mb-4">
                    <label class="form-label small fw-bold text-muted">Alamat Pengiriman Utama</label>
                    <textarea name="alamat" class="form-control form-control-custom" rows="2" placeholder="Masukkan alamat lengkap pengiriman"></textarea>
                </div>

                <button type="submit" name="register" class="btn btn-auth w-100 mb-3">
                    <i class="fa-solid fa-user-plus me-2"></i> Daftar Sekarang
                </button>

                <div class="text-center small text-muted">
                    Sudah punya akun? 
                    <a href="login.php" class="fw-bold text-decoration-none" style="color: var(--brand-warm-brown);">
                        Masuk di sini
                    </a>
                </div>

                <div class="text-center mt-3 pt-3 border-top">
                    <a href="index.php" class="small text-secondary text-decoration-none">
                        <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Beranda
                    </a>
                </div>

            </form>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>