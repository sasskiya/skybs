-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 10, 2026 at 07:31 AM
-- Server version: 8.4.3
-- PHP Version: 8.3.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skybs`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id_buku` int NOT NULL,
  `id_kategori` int NOT NULL,
  `judul` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `penulis` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `stok` int NOT NULL DEFAULT '25',
  `rating` decimal(3,1) DEFAULT '4.5',
  `cover` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `tipe_buku` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'reguler',
  `badge` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `id_kategori`, `judul`, `penulis`, `harga`, `stok`, `rating`, `cover`, `deskripsi`, `tipe_buku`, `badge`) VALUES
(1, 1, 'Laskar Pelangi', 'Andrea Hirata', 89000.00, 25, 4.1, '1L.jpg', 'Kisah menyentuh tentang perjuangan sepuluh anak Belitung dalam menggapai mimpi di tengah keterbatasan fasilitas pendidikan.', 'reguler', NULL),
(2, 1, 'Bumi Manusia', 'Pramoedya Ananta Toer', 135000.00, 25, 4.0, '2B.jpg', 'Mahakarya sastra Indonesia latar masa kolonial yang menceritakan pergulatan cinta, perlawanan, dan pencarian identitas Minke.', 'reguler', 'Bestseller'),
(3, 1, 'Hujan', 'Tere Liye', 95000.00, 25, 4.3, '3H.jpg', 'Novel romantis berlatar masa depan pascabencana alam dahsyat yang menguji arti ketulusan, kenangan, dan melupakan.', 'reguler', NULL),
(4, 1, 'Cantik Itu Luka', 'Eka Kurniawan', 120000.00, 25, 4.0, '4C.jpg', 'Kisah epik penuh magis dan kelam tentang seorang pelacur cantik di masa kolonial yang bangkit kembali dari kuburnya.', 'reguler', 'Bestseller'),
(5, 1, 'Laut Bercerita', 'Leila S. Chudori', 115000.00, 25, 4.5, '5L.jpg', 'Novel menyayat hati mengenai aktivis mahasiswa yang diculik pada masa Orde Baru serta perjuangan keluarga yang ditinggalkan.', 'reguler', NULL),
(6, 2, 'Harry Potter dan Batu Bertuah', 'J.K. Rowling', 128000.00, 25, 4.5, '11h.jpg', 'Awal mula petualangan ajaib seorang anak yatim piatu yang menemukan bahwa dirinya adalah seorang penyihir terkenal.', 'reguler', NULL),
(7, 2, 'Sang Alkemis (The Alchemist)', 'Paulo Coelho', 78000.00, 25, 3.9, '12s.jpg', 'Novel alegoris inspiratif tentang seorang gembala muda bernama Santiago yang menjelajah demi mengejar harta karun impiannya.', 'reguler', NULL),
(8, 2, 'Di Mana Tempatmu Menyimpan Rahasia? (The Midnight Library)', 'Matt Haig', 99000.00, 25, 4.0, '14t.jpg', 'Perpustakaan ajaib di antara hidup dan mati yang memberikan kesempatan untuk mencoba berbagai jalur kehidupan alternatif.', 'reguler', NULL),
(9, 2, 'Toko Kelontong Namiya', 'Keigo Higashino', 115000.00, 25, 4.4, '15t.jpg', 'Tiga pemuda berandal yang bersembunyi di toko tua mendadak menerima surat konsultasi misterius dari masa lalu.', 'reguler', NULL),
(10, 2, 'Pembunuhan di ABC (The ABC Murders)', 'Agatha Christie', 68000.00, 25, 4.0, '16t.jpg', 'Detektif jenius Hercule Poirot menghadapi pembunuh berantai licik yang meninggalkan jadwal kereta api di setiap tempat kejadian.', 'reguler', NULL),
(11, 3, 'Atomic Habits', 'James Clear', 108000.00, 25, 4.4, '21a.jpg', 'Panduan praktis berbasis sains untuk membangun kebiasaan baik dan membuang kebiasaan buruk melalui perubahan kecil.', 'reguler', NULL),
(12, 3, 'Filosofi Teras', 'Henry Manampiring', 98000.00, 24, 4.4, '22f.jpg', 'Penerapan filsafat Stoa Yunani-Romawi kuno untuk mengatasi emosi negatif dan mental overthinking di era modern.', 'reguler', NULL),
(13, 3, 'Sebuah Seni untuk Bersikap Bodo Amat', 'Mark Manson', 78000.00, 25, 3.9, '23s.jpg', 'Pendekatan kontraintuitif untuk hidup bahagia dengan cara fokus pada hal-hal yang benar-benar penting saja.', 'reguler', NULL),
(14, 3, 'Berani Tidak Disukai', 'Ichiro Kishimi & Fumitake Koga', 98000.00, 25, 4.1, '24b.jpg', 'Buku psikologi populer berbasis Adlerian tentang cara membebaskan diri dari ekspektasi orang lain demi kebahagiaan sejati.', 'reguler', NULL),
(15, 3, 'Bicara Itu Ada Seninya', 'Oh Su Hyang', 88000.00, 25, 3.9, '25b.jpg', 'Rahasia komunikasi efektif, persuasi, dan teknik berbicara memukau untuk membangun relasi sosial yang sukses.', 'reguler', NULL),
(16, 4, 'The Psychology of Money', 'Morgan Housel', 85000.00, 25, 4.4, '31t.jpg', 'Pelajaran abadi mengenai kekayaan, keserakahan, dan kebahagiaan yang dipengaruhi oleh perilaku serta emosi manusia.', 'reguler', NULL),
(17, 4, 'Rich Dad Poor Dad', 'Robert T. Kiyosaki', 78000.00, 25, 4.1, '32r.jpg', 'Perbedaan pola pikir orang kaya dan kelas pekerja dalam mengelola uang serta aset produktif.', 'reguler', NULL),
(18, 4, 'The Intelligent Investor', 'Benjamin Graham', 165000.00, 25, 4.2, '33t.jpg', 'Kitab suci investasi nilai (value investing) terbaik sepanjang masa yang direkomendasikan oleh Warren Buffett.', 'reguler', NULL),
(19, 4, 'Zero to One', 'Peter Thiel', 88000.00, 25, 4.2, '34z.jpg', 'Catatan penting dari pendiri PayPal tentang bagaimana membangun perusahaan rintisan (startup) yang menciptakan inovasi monopoli.', 'reguler', NULL),
(20, 4, 'Principles for Dealing with the Changing World Order', 'Ray Dalio', 210000.00, 25, 4.1, '38p.jpg', 'Analisis siklus ekonomi makro, kejayaan, dan keruntuhan imperasi besar dunia masa lalu hingga masa depan.', 'reguler', NULL),
(21, 5, 'Thinking, Fast and Slow', 'Daniel Kahneman', 145000.00, 25, 4.2, '41t.jpg', 'Penjelasan dua sistem otak manusia yang mengontrol cara kita berpikir, mengambil keputusan, dan mengalami bias.', 'reguler', NULL),
(22, 5, 'Emotional Intelligence', 'Daniel Goleman', 110000.00, 25, 4.0, '42e.jpg', 'Argumen ilmiah bahwa kecerdasan emosional jauh lebih menentukan kesuksesan hidup ketimbang IQ semata.', 'reguler', NULL),
(23, 5, 'Quiet (Kekuatan Orang Introver)', 'Susan Cain', 105000.00, 24, 4.1, '43q.jpg', 'Apologia dan kekuatan tersembunyi kaum introver di dunia yang terlalu bising dan mendewakan ekstrover.', 'reguler', NULL),
(24, 5, 'Flow: The Psychology of Optimal Experience', 'Mihaly Csikszentmihalyi', 95000.00, 24, 4.1, '46f.jpg', 'Konsep psikologis tentang keadaan fokus total dan kenikmatan tertinggi saat seseorang tenggelam dalam aktivitasnya.', 'reguler', NULL),
(25, 5, 'Insecurity is My Middle Name', 'Alvi Syahrin', 93000.00, 25, 4.3, '50i.jpg', 'Buku refleksi diri untuk mengatasi rasa tidak aman, kecemasan sosial, dan keraguan terhadap kemampuan diri sendiri.', 'reguler', NULL),
(26, 6, 'Sapiens: Riwayat Singkat Umat Manusia', 'Yuval Noah Harari', 135000.00, 25, 4.4, '51s.jpg', 'Perjalanan evolusi spesies Homo Sapiens dari primata tak penting hingga penguasa planet bumi.', 'reguler', NULL),
(27, 6, 'Homo Deus', 'Yuval Noah Harari', 135000.00, 25, 4.2, '52h.jpg', 'Spekulasi masa depan umat manusia ketika teknologi, kecerdasan buatan, dan bioteknologi melampaui batas biologis.', 'reguler', NULL),
(28, 6, 'Cosmos', 'Carl Sagan', 120000.00, 25, 4.4, '53c.jpg', 'Petualangan kosmik menjelajahi luasnya alam semesta, sains, dan peradaban manusia lintas galaksi.', 'reguler', NULL),
(29, 6, 'Sejarah Singkat Waktu (A Brief History of Time)', 'Stephen Hawking', 78000.00, 24, 4.2, '54b.jpg', 'Penjelasan populer fisika teoretis mengenai asal-usul alam semesta, lubang hitam, dan waktu.', 'reguler', NULL),
(30, 6, 'Astrofisika untuk Orang Tergesa-gesa', 'Neil deGrasse Tyson', 68000.00, 25, 3.9, '57a.jpg', 'Pengantar singkat dan jenaka mengenai misteri kuantum, galaksi, dan bintang-bintang di luar angkasa.', 'reguler', NULL),
(31, 7, 'Nusantara: Sejarah Indonesia', 'Bernard H.M. Vlekke', 140000.00, 25, 4.2, '61n.jpg', 'Kronologi sejarah kepulauan Nusantara dari masa kerajaan Hindu-Buddha hingga era kemerdekaan.', 'reguler', NULL),
(32, 7, 'Guns, Germs, & Steel', 'Jared Diamond', 150000.00, 24, 4.1, '63n.jpg', 'Analisis mengapa peradaban Eurasia berkembang pesat sementara benua lain mengalami hambatan geografis.', 'reguler', NULL),
(33, 7, '21 Pelajaran untuk Abad ke-21', 'Yuval Noah Harari', 125000.00, 24, 4.2, '65p.jpg', 'Fokus pada tantangan mendesak masa kini seperti disrupsi teknologi, politik global, dan hoaks.', 'reguler', NULL),
(34, 7, 'Catatan Seorang Demonstran', 'Soe Hok Gie', 85000.00, 25, 4.3, '66c.jpg', 'Diari jujur seorang aktivis mahasiswa idealis yang kritis terhadap ketidakadilan rezim pemerintah.', 'reguler', NULL),
(35, 7, 'Hoakiau di Indonesia', 'Pramoedya Ananta Toer', 75000.00, 23, 4.2, '68h.jpg', 'Kajian historis mengenai peran, dinamika, dan kontribusi etnis Tionghoa dalam sejarah perjuangan bangsa.', 'reguler', NULL),
(36, 8, 'Steve Jobs', 'Walter Isaacson', 180000.00, 25, 4.1, '71s.jpg', 'Biografi resmi pendiri Apple yang visioner, perfeksionis, dan penuh kontroversi dalam dunia teknologi.', 'reguler', NULL),
(37, 8, 'Becoming', 'Michelle Obama', 168000.00, 25, 4.3, '72b.jpg', 'Memoar jujur dan menginspirasi dari mantan Ibu Negara Amerika Serikat tentang perjalanan hidupnya.', 'reguler', NULL),
(38, 8, 'Shoe Dog', 'Phil Knight', 120000.00, 25, 4.5, '74s.jpg', 'Kisah jatuh bangun pendiri Nike dalam merintis merek sepatu global dari modal pinjaman.', 'reguler', NULL),
(39, 8, 'Long Walk to Freedom', 'Nelson Mandela', 150000.00, 25, 4.3, '78l.jpg', 'Otobiografi pejuang hak asasi manusia asal Afrika Selatan yang mendekam di penjara demi kesetaraan ras.', 'reguler', NULL),
(40, 8, 'Einstein: His Life and Universe', 'Walter Isaacson', 175000.00, 24, 4.2, '79e.jpg', 'Membongkar sisi jenius, kepribadian unik, dan pemikiran fisikawan terhebat abad ke-20 Albert Einstein.', 'reguler', NULL),
(41, 9, 'One Piece Vol. 1', 'Eiichiro Oda', 45000.00, 25, 4.4, '81o.jpg', 'Petualangan awal Monkey D. Luffy yang bercita-cita menjadi Raja Bajak Laut di lautan lepas.', 'reguler', NULL),
(42, 9, 'Doraemon Vol. 1', 'Fujiko F. Fujio', 40000.00, 25, 4.4, '83d.jpg', 'Kisah robot kucing dari masa depan yang datang menolong anak pemalas bernama Nobita.', 'reguler', NULL),
(43, 9, 'Spy x Family Vol. 1', 'Tatsuya Endo', 45000.00, 24, 4.5, '85s.jpg', 'Misi penyamaran agen rahasia yang membentuk keluarga palsu dengan pembunuh bayaran dan anak telepati.', 'reguler', NULL),
(44, 9, 'Jujutsu Kaisen Vol. 1', 'Gege Akutami', 45000.00, 23, 4.4, '86j.jpg', 'Pertarungan sengit dunia gaib dan kutukan setelah Yuji Itadori menelan jari terkutuk Sukuna.', 'reguler', NULL),
(45, 9, 'Detektif Conan Vol. 1', 'Gosho Aoyama', 40000.00, 25, 4.0, '89d.jpg', 'Detektif remaja SMA Shinichi Kudo yang tubuhnya menyusut akibat racun misterius organisasi hitam.', 'reguler', ''),
(46, 10, 'Tasawuf Modern', 'Buya Hamka', 68000.00, 25, 4.4, '92t.jpg', 'Panduan mencapai ketenangan jiwa, kebahagiaan batin, dan keluhuran budi pekerti dalam kehidupan modern.', 'reguler', NULL),
(47, 10, 'Fihi Ma Fihi', 'Jalaluddin Rumi', 99000.00, 24, 4.4, '93f.jpg', 'Kumpulan ceramah dan dialog spiritual sufi agung Jalaluddin Rumi mengenai hakikat cinta ilahi.', 'reguler', NULL),
(48, 10, 'La Tahzan', 'Aidh Al-Qarni', 110000.00, 25, 4.2, '95l.jpg', 'Buku motivasi Islami bestseller yang menenangkan hati dari kesedihan, putus asa, dan kecemasan hidup.', 'reguler', NULL),
(49, 10, 'Islam Risalah Cinta dan Kebahagiaan', 'Haidar Bagir', 75000.00, 25, 4.0, '96i.jpg', 'Refleksi mendalam tentang wajah Islam yang penuh kasih sayang, kedamaian, dan universalitas cinta.', 'reguler', 'Pilihan Editor'),
(50, 10, 'Jilbab: Pakaian Wanita Muslimah', 'M. Quraish Shihab', 80000.00, 25, 4.0, '99j.jpg', 'Kajian komprehensif dan objektif mengenai dalil serta esensi berpakaian sopan bagi wanita muslimah.', 'reguler', 'Baru'),
(52, 1, 'Setiap Hari, Hari Ini', 'Valerián Patkan', 90000.00, 3, 4.5, 'war_1793679410_251.jpeg', 'Novel ini mengajak pembaca merenungkan makna dari setiap hari yang berjalan, bagaimana sebuah rutinitas menyimpan cerita berharga, serta pergulatan batin untuk menghargai momen masa kini secara utuh', 'war', NULL),
(54, 1, 'Keigo Higashino - Naoko', 'Keigo Higashino', 98000.00, 5, 4.5, 'war_1794272506_663.jpg', 'Berkisah tentang Heisuke, seorang ayah yang hidupnya berubah drastis setelah kecelakaan bus maut merenggut nyawa istrinya dan membuat jiwa sang anak, Naoko, tertukar dengan raga ibunya yang koma.', 'war', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id_chat` int NOT NULL,
  `id_user` int NOT NULL,
  `pengirim` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'user',
  `pesan` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `waktu` datetime DEFAULT CURRENT_TIMESTAMP,
  `gambar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id_chat`, `id_user`, `pengirim`, `pesan`, `waktu`, `gambar`) VALUES
(4, 3, 'user', 'MIN', '2026-10-29 21:45:17', NULL),
(5, 3, 'admin', 'ADA APA ?', '2026-10-29 21:47:12', NULL),
(6, 4, 'user', 'ka', '2026-11-04 23:30:58', NULL),
(7, 4, 'admin', 'apa dek', '2026-11-04 23:31:25', NULL),
(8, 4, 'admin', 'dek?', '2026-11-05 18:22:42', NULL),
(9, 4, 'user', 'kak', '2026-11-10 09:21:39', 'chat_user_1794277299_374.png'),
(10, 4, 'admin', 'saya udah kirim pengembalian dana ya ka udah masuk belum?', '2026-11-10 09:22:46', 'chat_admin_1794277366_702.png'),
(11, 4, 'user', 'ka untuk war dijam berapa ya?', '2026-11-10 14:18:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `detail_pesanan`
--

CREATE TABLE `detail_pesanan` (
  `id_detail` int NOT NULL,
  `id_pesanan` int NOT NULL,
  `id_buku` int NOT NULL,
  `jumlah` int NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `detail_pesanan`
--

INSERT INTO `detail_pesanan` (`id_detail`, `id_pesanan`, `id_buku`, `jumlah`, `harga`, `subtotal`) VALUES
(2, 2, 52, 1, 90000.00, 90000.00),
(3, 3, 44, 1, 45000.00, 45000.00),
(4, 4, 32, 1, 150000.00, 150000.00),
(5, 5, 29, 1, 78000.00, 78000.00),
(6, 6, 23, 1, 105000.00, 105000.00),
(7, 7, 35, 1, 75000.00, 75000.00),
(8, 8, 24, 1, 95000.00, 95000.00),
(9, 9, 40, 1, 175000.00, 175000.00),
(10, 10, 44, 1, 45000.00, 45000.00),
(11, 11, 43, 1, 45000.00, 45000.00),
(12, 11, 35, 1, 75000.00, 75000.00),
(13, 11, 33, 1, 125000.00, 125000.00),
(14, 12, 47, 1, 99000.00, 99000.00),
(15, 13, 52, 1, 90000.00, 90000.00),
(16, 14, 45, 2, 40000.00, 80000.00),
(17, 15, 12, 1, 98000.00, 98000.00);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int NOT NULL,
  `nama_kategori` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`, `deskripsi`) VALUES
(1, 'Fiksi & Novel Indonesia', 'Koleksi karya sastra fiksi, novel legendaris, dan cerita inspiratif karya penulis ternama Indonesia.'),
(2, 'Novel Terjemahan / Fiksi Internasional', 'Karya sastra fiksi terbaik dari seluruh dunia yang telah diterjemahkan ke dalam bahasa Indonesia.'),
(3, 'Pengembangan Diri (Self-Improvement)', 'Buku-buku praktis untuk membangun kebiasaan positif, mental tangguh, dan peningkatan kualitas hidup.'),
(4, 'Bisnis & Keuangan', 'Panduan cerdas mengelola keuangan pribadi, investasi saham, pola pikir pengusaha, dan strategi ekonomi.'),
(5, 'Psikologi', 'Eksplorasi mendalam mengenai cara kerja pikiran manusia, kecerdasan emosional, dan perilaku sosial.'),
(6, 'Sains & Popular Science', 'Buku sains populer yang mengupas rahasia alam semesta, sejarah peradaban manusia, dan teknologi masa depan.'),
(7, 'Sejarah & Budaya', 'Catatan penting mengenai perjalanan sejarah bangsa, peradaban dunia, dan dinamika sosial kemasyarakatan.'),
(8, 'Biografi & Otobiografi', 'Kisah nyata perjalanan hidup tokoh-tokoh inspiratif dunia, pemimpin besar, dan innovator sukses.'),
(9, 'Komik / Manga', 'Seri komik dan manga terpopuler yang menyuguhkan petualangan seru dan menghibur.'),
(10, 'Agama & Spiritualitas', 'Kumpulan literatur pencerahan rohani, tasawuf, motivasi Islami, dan panduan hidup beragama yang damai.');

-- --------------------------------------------------------

--
-- Table structure for table `keranjang`
--

CREATE TABLE `keranjang` (
  `id_keranjang` int NOT NULL,
  `id_user` int NOT NULL,
  `id_buku` int NOT NULL,
  `jumlah` int NOT NULL DEFAULT '1',
  `tanggal` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `keranjang`
--

INSERT INTO `keranjang` (`id_keranjang`, `id_user`, `id_buku`, `jumlah`, `tanggal`) VALUES
(20, 5, 48, 1, '2026-11-05 07:47:48');

-- --------------------------------------------------------

--
-- Table structure for table `login_log`
--

CREATE TABLE `login_log` (
  `id_log` int NOT NULL,
  `id_user` int NOT NULL,
  `waktu_login` datetime DEFAULT CURRENT_TIMESTAMP,
  `ip_address` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '127.0.0.1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifikasi`
--

CREATE TABLE `notifikasi` (
  `id_notifikasi` int NOT NULL,
  `id_user` int NOT NULL,
  `pesan` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Belum Dibaca',
  `tanggal` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifikasi`
--

INSERT INTO `notifikasi` (`id_notifikasi`, `id_user`, `pesan`, `status`, `tanggal`) VALUES
(2, 3, 'Pesanan War Tiket SKYBS-WARORD-20261029-5657 (Setiap Hari, Hari Ini) berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-10-29 21:44:47'),
(3, 3, 'Pesanan SKYBS-20261029-4478 berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-10-29 21:46:19'),
(4, 4, 'Pesanan SKYBS-20261103-8266 berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-11-03 09:30:13'),
(5, 4, 'Pesanan SKYBS-20261103-9486 berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-11-03 10:07:10'),
(6, 4, 'Pesanan SKYBS-20261103-5143 berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-11-03 10:09:41'),
(7, 4, 'Pesanan SKYBS-20261103-4011 berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-11-03 10:25:38'),
(8, 4, 'Pesanan SKYBS-20261103-9935 berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-11-03 10:35:28'),
(9, 4, 'Pesanan SKYBS-20261103-2352 berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-11-03 10:43:07'),
(10, 4, 'Pesanan SKYBS-20261103-7710 berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-11-03 11:03:50'),
(11, 4, 'Pesanan SKYBS-20261103-1471 berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-11-03 11:15:23'),
(12, 4, 'Pesanan SKYBS-20261104-9215 berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-11-04 09:22:37'),
(13, 4, 'Pesanan War Tiket SKYBS-WARORD-20261104-4771 (Setiap Hari, Hari Ini) berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-11-04 23:09:42'),
(14, 4, 'Pesanan SKYBS-20261105-9721 berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-11-05 07:18:19'),
(15, 4, 'Pesanan SKYBS-20261109-1700 berhasil dibuat. Silakan tunggu konfirmasi admin.', 'Belum Dibaca', '2026-11-09 20:34:49');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int NOT NULL,
  `id_pesanan` int NOT NULL,
  `metode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bukti` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Menunggu Verification',
  `tanggal` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_pesanan`, `metode`, `bukti`, `status`, `tanggal`) VALUES
(2, 2, 'COD', '', 'COD', '2026-10-29 21:44:47'),
(3, 3, 'COD', '', 'COD', '2026-10-29 21:46:19'),
(4, 4, 'BCA', 'bukti_1793673013_448.jpg', 'Menunggu Verification', '2026-11-03 09:30:13'),
(5, 5, 'BCA', 'bukti_1793675230_677.png', 'Menunggu Verification', '2026-11-03 10:07:10'),
(6, 6, 'Mandiri', 'bukti_1793675381_377.png', 'Menunggu Verification', '2026-11-03 10:09:41'),
(7, 7, 'DANA', 'bukti_1793676338_837.png', 'Menunggu Verification', '2026-11-03 10:25:38'),
(8, 8, 'BRI', 'bukti_1793676928_408.png', 'Menunggu Verification', '2026-11-03 10:35:28'),
(9, 9, 'DANA', 'bukti_1793677387_244.png', 'Menunggu Verification', '2026-11-03 10:43:07'),
(10, 10, 'Mandiri', 'bukti_1793678630_896.png', 'Menunggu Verification', '2026-11-03 11:03:50'),
(11, 11, 'BCA', 'bukti_1793679323_438.png', 'Menunggu Verification', '2026-11-03 11:15:23'),
(12, 12, 'BCA', 'bukti_1793758957_234.png', 'Menunggu Verification', '2026-11-04 09:22:37'),
(13, 13, 'BRI', 'bukti_war_1793808582_6176.png', 'Menunggu Verifikasi', '2026-11-04 23:09:42'),
(14, 14, 'BRI', 'bukti_1793837899_669.png', 'Menunggu Verification', '2026-11-05 07:18:19'),
(15, 15, 'COD', '', 'COD', '2026-11-09 20:34:49');

-- --------------------------------------------------------

--
-- Table structure for table `pengaturan_war`
--

CREATE TABLE `pengaturan_war` (
  `id` int NOT NULL,
  `nama_event` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'War Tiket Eksklusif',
  `waktu_mulai` datetime NOT NULL,
  `waktu_selesai` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pengaturan_war`
--

INSERT INTO `pengaturan_war` (`id`, `nama_event`, `waktu_mulai`, `waktu_selesai`) VALUES
(1, 'skdebut', '2026-11-09 09:07:00', '2026-11-09 17:10:00');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE `pesanan` (
  `id_pesanan` int NOT NULL,
  `kode_pesanan` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_user` int NOT NULL,
  `total_harga` decimal(10,2) NOT NULL,
  `metode_pembayaran` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Menunggu Konfirmasi',
  `alamat_pengiriman` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `voucher_terpakai` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal` datetime DEFAULT CURRENT_TIMESTAMP,
  `bukti_transfer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_refund` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Belum Diproses',
  `rekening_tujuan` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`id_pesanan`, `kode_pesanan`, `id_user`, `total_harga`, `metode_pembayaran`, `status`, `alamat_pengiriman`, `voucher_terpakai`, `tanggal`, `bukti_transfer`, `status_refund`, `rekening_tujuan`) VALUES
(2, 'SKYBS-WARORD-20261029-5657', 3, 88000.00, 'COD', 'Selesai', '[War Tiket: SKYBS-WAR-00001] [Kota: Luar Jakarta] jogja', NULL, '2026-10-29 21:44:47', NULL, 'Belum Diproses', NULL),
(3, 'SKYBS-20261029-4478', 3, 55000.00, 'COD', 'Selesai', '[Kota: Luar Jakarta] jogja', NULL, '2026-10-29 21:46:19', NULL, 'Belum Diproses', NULL),
(4, 'SKYBS-20261103-8266', 4, 160000.00, 'BCA', 'Selesai', '[Kota: Jakarta Pusat] jogja', NULL, '2026-11-03 09:30:13', NULL, 'Belum Diproses', NULL),
(5, 'SKYBS-20261103-9486', 4, 88000.00, 'BCA', 'Selesai', '[Kota: Jakarta Pusat] jogja', NULL, '2026-11-03 10:07:10', NULL, 'Belum Diproses', NULL),
(6, 'SKYBS-20261103-5143', 4, 115000.00, 'Mandiri', 'Selesai', '[Kota: Jakarta Pusat] jogja', NULL, '2026-11-03 10:09:41', NULL, 'Belum Diproses', NULL),
(7, 'SKYBS-20261103-4011', 4, 85000.00, 'DANA', 'Selesai', '[Kota: Jakarta Selatan] jogja', NULL, '2026-11-03 10:25:38', NULL, 'Belum Diproses', NULL),
(8, 'SKYBS-20261103-9935', 4, 105000.00, 'BRI', 'Selesai', '[Kota: Jakarta Pusat] jogja', NULL, '2026-11-03 10:35:28', NULL, 'Belum Diproses', NULL),
(9, 'SKYBS-20261103-2352', 4, 185000.00, 'DANA', 'Selesai', '[Kota: Jakarta Pusat] jogja', NULL, '2026-11-03 10:43:07', NULL, 'Belum Diproses', NULL),
(10, 'SKYBS-20261103-7710', 4, 55000.00, 'Mandiri', 'Selesai', '[Kota: Jakarta Pusat] jogja', NULL, '2026-11-03 11:03:50', NULL, 'Belum Diproses', NULL),
(11, 'SKYBS-20261103-1471', 4, 255000.00, 'BCA', 'Selesai', '[Kota: Jakarta Selatan] jogja', NULL, '2026-11-03 11:15:23', NULL, 'Belum Diproses', NULL),
(12, 'SKYBS-20261104-9215', 4, 109000.00, 'BCA', 'Selesai', '[Kota: Jakarta Barat] jogja', NULL, '2026-11-04 09:22:37', NULL, 'Belum Diproses', NULL),
(13, 'SKYBS-WARORD-20261104-4771', 4, 100000.00, 'BRI', 'Selesai', '[War Tiket: SKYBS-WAR-00002] [Kota: Jakarta Utara] jl.ibunda2rt007rw001no1', NULL, '2026-11-04 23:09:42', NULL, 'Belum Diproses', NULL),
(14, 'SKYBS-20261105-9721', 4, 66000.00, 'BRI', 'Refund', '[Kota: Jakarta Pusat] jogja', NULL, '2026-11-05 07:18:19', NULL, 'Belum Diproses', NULL),
(15, 'SKYBS-20261109-1700', 4, 108000.00, 'COD', 'Diproses', '[Kota: Jakarta Pusat] jogja', NULL, '2026-11-09 20:34:48', NULL, 'Belum Diproses', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sys_config`
--

CREATE TABLE `sys_config` (
  `variable` varchar(128) NOT NULL,
  `value` varchar(128) DEFAULT NULL,
  `set_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `set_by` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sys_config`
--

INSERT INTO `sys_config` (`variable`, `value`, `set_time`, `set_by`) VALUES
('diagnostics.allow_i_s_tables', 'OFF', '2026-10-24 10:31:50', NULL),
('diagnostics.include_raw', 'OFF', '2026-10-24 10:31:50', NULL),
('ps_thread_trx_info.max_length', '65535', '2026-10-24 10:31:50', NULL),
('statement_performance_analyzer.limit', '100', '2026-10-24 10:31:50', NULL),
('statement_performance_analyzer.view', NULL, '2026-10-24 10:31:50', NULL),
('statement_truncate_len', '64', '2026-10-24 10:31:50', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int NOT NULL,
  `id_user` int NOT NULL,
  `id_buku` int NOT NULL,
  `tipe` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'war',
  `total_harga` decimal(10,2) NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `voucher_terpakai` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_user`, `id_buku`, `tipe`, `total_harga`, `status`, `voucher_terpakai`, `tanggal`) VALUES
(1, 3, 52, 'war', 90000.00, 'Checkout Selesai', NULL, '2026-10-29 21:43:53'),
(2, 4, 52, 'war', 90000.00, 'Checkout Selesai', NULL, '2026-11-04 23:07:07'),
(3, 4, 52, 'war', 90000.00, 'Pending', NULL, '2026-11-09 12:53:58');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int NOT NULL,
  `nama` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_hp` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `foto` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `voucher_terpakai` int DEFAULT '0',
  `kuis_claimed` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nama`, `email`, `password`, `no_hp`, `alamat`, `foto`, `voucher_terpakai`, `kuis_claimed`) VALUES
(1, 'Administrator SKYBS', 'admin@skybs.com', 'admin123', '085891403949', 'Gudang Utama SKYBS, Jakarta Pusat', NULL, 0, 0),
(3, 'eomseo', 'eomseo@gmail.com', '$2y$10$Gcm/IWZe.2WwF.1bLSp0hOmcJQFNGb5L9xhg71x0iRaBCj63Ya/o2', '000', 'jogja', 'user_1793283442_131.jpg', 0, 0),
(4, 'sean', 'sean@gmail.com', '$2y$10$rSopLKuoKbLdLnJ7PhqkUOe5.qUmzImBaMera5OeWcZ6z92OxlKe.', '087525', 'jogja', 'user_1793672449_593.jpg', 1, 0),
(5, 'salwa', 'salwa@gmail.com', '$2y$10$5BmTqPeoWGaQdRevuPMI1uZYdpTIMTJ4oSSg5vvBnqywdtq3lq4gK', '999', 'bandung', 'default.png', 0, 0),
(6, 'kipas', 'kipas@1', '$2y$10$RGD58jyuzNmSS.czLLBLuuLBxIFDeFeTLywedNWKBjXKGflGx9gpq', '123', 'jln. manadulu', 'default.png', 0, 1),
(7, 'dafa', 'dafa@gmail.com', '$2y$10$lyTeEry3YladbW2thR3DqepjwR.ex73T8bij71VI85Ggvyvn0IWzK', '123', 'jln. manadulu', 'default.png', 0, 0),
(8, 'dafa', 'dafa@3', '$2y$10$vHNllHGNWaT6EnMGGqMZxuZ4GeskU16IiOZ8tpo0fuZ..IW93BlLW', '123', 'jln. manadulu', 'default.png', 0, 1),
(9, 'saskiya', 'sas@gmail.com', '$2y$10$RsPHPInWS5BT5qt3bVGW0OQkj6o3L4VeTsmzwPdqvPr6JYlSTLGA2', '123', 'jl kambja', 'default.png', 0, 0),
(10, 'saskiya', 'sas@1', '$2y$10$mXhThnJZmuhEk3GBEisKXOxFFvzjDmLWZMU8gVc8ve.L6JMDJVzyK', '', 'jl', 'default.png', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `war_books`
--

CREATE TABLE `war_books` (
  `id_buku` int NOT NULL,
  `status_war` enum('Dibuka','Ditutup') NOT NULL DEFAULT 'Ditutup',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `war_books`
--

INSERT INTO `war_books` (`id_buku`, `status_war`, `created_at`) VALUES
(52, 'Ditutup', '2026-10-29 14:43:30'),
(54, 'Ditutup', '2026-11-10 01:01:46');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id_wishlist` int NOT NULL,
  `id_user` int NOT NULL,
  `id_buku` int NOT NULL,
  `tanggal` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id_wishlist`, `id_user`, `id_buku`, `tanggal`) VALUES
(2, 3, 44, '2026-10-29 21:45:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id_chat`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `detail_pesanan`
--
ALTER TABLE `detail_pesanan`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `id_pesanan` (`id_pesanan`),
  ADD KEY `id_buku` (`id_buku`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD PRIMARY KEY (`id_keranjang`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_buku` (`id_buku`);

--
-- Indexes for table `login_log`
--
ALTER TABLE `login_log`
  ADD PRIMARY KEY (`id_log`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `notifikasi`
--
ALTER TABLE `notifikasi`
  ADD PRIMARY KEY (`id_notifikasi`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD KEY `id_pesanan` (`id_pesanan`);

--
-- Indexes for table `pengaturan_war`
--
ALTER TABLE `pengaturan_war`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id_pesanan`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `sys_config`
--
ALTER TABLE `sys_config`
  ADD PRIMARY KEY (`variable`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_buku` (`id_buku`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `war_books`
--
ALTER TABLE `war_books`
  ADD PRIMARY KEY (`id_buku`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id_wishlist`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_buku` (`id_buku`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `id_buku` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id_chat` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `detail_pesanan`
--
ALTER TABLE `detail_pesanan`
  MODIFY `id_detail` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `keranjang`
--
ALTER TABLE `keranjang`
  MODIFY `id_keranjang` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `login_log`
--
ALTER TABLE `login_log`
  MODIFY `id_log` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifikasi`
--
ALTER TABLE `notifikasi`
  MODIFY `id_notifikasi` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `pengaturan_war`
--
ALTER TABLE `pengaturan_war`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id_pesanan` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id_wishlist` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
