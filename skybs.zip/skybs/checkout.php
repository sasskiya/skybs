<?php
session_start();
include "database.php";

// 1. Cek Sesi Login User
if (!isset($_SESSION['id_user'])) {
    echo "<script>
        alert('Silakan login terlebih dahulu!');
        window.location='login.php';
    </script>";
    exit;
}

$id_user = (int)$_SESSION['id_user'];

// Cek status apakah user sudah pernah menggunakan voucher sebelumnya dari database
$stmt_usr_check = mysqli_prepare($conn, "SELECT voucher_terpakai FROM users WHERE id_user = ?");
mysqli_stmt_bind_param($stmt_usr_check, "i", $id_user);
mysqli_stmt_execute($stmt_usr_check);
$res_usr_check = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_usr_check));
$sudah_pernah_pakai = isset($res_usr_check['voucher_terpakai']) && $res_usr_check['voucher_terpakai'] == 1;

// 2. Cek Apakah Voucher Diklik dari Banner atau Dimasukkan Manual
if (isset($_GET['promo'])) {
    $promo_input = trim($_GET['promo']);
    
    // Jika user sudah pernah pakai voucher sebelumnya, tolak!
    if ($sudah_pernah_pakai) {
        echo "<script>
            alert('⚠ Maaf, Anda sudah pernah menggunakan voucher diskon sebelumnya! Voucher hanya berlaku 1 kali per akun.');
            window.location='checkout.php';
        </script>";
        exit;
    }

    if (strtoupper($promo_input) === 'SKYBSHEBAT') {
        $rate = (isset($_GET['source']) && $_GET['source'] === 'kuis') ? 0.20 : 0.30;
        
        $_SESSION['applied_promo'] = 'SKYBSHEBAT';
        $_SESSION['discount_rate'] = $rate;
    } else {
        $_SESSION['applied_promo'] = strtoupper($promo_input);
        $_SESSION['discount_rate'] = 0.15; // Diskon kustom lain
    }
}

// Jika user sudah pernah pakai sebelumnya, pastikan session diskon kosong
if ($sudah_pernah_pakai) {
    unset($_SESSION['applied_promo']);
    unset($_SESSION['discount_rate']);
}

// 3. Ambil Data User untuk Pre-fill Alamat & No HP
$stmt_user = mysqli_prepare($conn, "SELECT nama, no_hp, alamat FROM users WHERE id_user = ?");
mysqli_stmt_bind_param($stmt_user, "i", $id_user);
mysqli_stmt_execute($stmt_user);
$data_user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_user));

// 4. Ambil Item Keranjang
$stmt_cart = mysqli_prepare($conn, "
    SELECT keranjang.*, buku.judul, buku.cover, buku.harga, buku.stok 
    FROM keranjang 
    JOIN buku ON keranjang.id_buku = buku.id_buku 
    WHERE keranjang.id_user = ?
");
mysqli_stmt_bind_param($stmt_cart, "i", $id_user);
mysqli_stmt_execute($stmt_cart);
$res_cart = mysqli_stmt_get_result($stmt_cart);

$items = [];
$subtotal_produk = 0;

while ($row = mysqli_fetch_assoc($res_cart)) {
    $subtotal_item = $row['harga'] * $row['jumlah'];
    $subtotal_produk += $subtotal_item;
    $row['subtotal'] = $subtotal_item;
    $items[] = $row;
}

// 5. Redirect jika keranjang kosong
if (count($items) === 0) {
    echo "<script>
        alert('Keranjang Anda kosong! Silakan pilih buku terlebih dahulu.');
        window.location='index.php';
    </script>";
    exit;
}

// 6. Hitung Diskon dari Promo (Pastikan tidak melebihi subtotal produk agar tidak minus)
$discount_rate = $_SESSION['discount_rate'] ?? 0;
$promo_code = $_SESSION['applied_promo'] ?? '';
$nominal_diskon = $subtotal_produk * $discount_rate;

if ($nominal_diskon > $subtotal_produk) {
    $nominal_diskon = $subtotal_produk;
}

// 7. Eksekusi Proses Checkout
if (isset($_POST['checkout'])) {
    $metode = trim($_POST['metode']);
    $kota_tujuan = trim($_POST['kota_tujuan']);
    $alamat_pengiriman = trim($_POST['alamat_pengiriman']);
    $no_hp = trim($_POST['no_hp']);

    $is_jakarta = (strpos(strtolower($kota_tujuan), 'jakarta') !== false);
    $ongkir = $is_jakarta ? 10000 : 25000;
    
    $total_final = ($subtotal_produk - $nominal_diskon) + $ongkir;
    if ($total_final < 0) $total_final = $ongkir;

    if (empty($metode) || empty($alamat_pengiriman) || empty($kota_tujuan)) {
        echo "<script>alert('Harap lengkapi kota tujuan, alamat pengiriman, dan metode pembayaran!');</script>";
    } else {
        if ($metode == "COD") {
            $status_pesanan = "Diproses";
            $status_pembayaran = "COD";
            $bukti = "";
        } else {
            $status_pesanan = "Menunggu Konfirmasi";
            $status_pembayaran = "Menunggu Verification";
            $bukti = "";

            if (isset($_FILES['bukti']) && $_FILES['bukti']['error'] === UPLOAD_ERR_OK) {
                $ext = pathinfo($_FILES['bukti']['name'], PATHINFO_EXTENSION);
                $bukti = "bukti_" . time() . "_" . rand(100, 999) . "." . strtolower($ext);
                
                if (!is_dir("img/bukti")) {
                    mkdir("img/bukti", 0777, true);
                }
                
                move_uploaded_file($_FILES['bukti']['tmp_name'], "img/bukti/" . $bukti);
            }
        }

        $kode_pesanan = "SKYBS-" . date("Ymd") . "-" . rand(1000, 9999);

        // A. Simpan Tabel Pesanan
        $full_address = "[Kota: $kota_tujuan] " . $alamat_pengiriman;
        $stmt_ins_p = mysqli_prepare($conn, "
            INSERT INTO pesanan (kode_pesanan, id_user, total_harga, metode_pembayaran, status, alamat_pengiriman, tanggal) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        mysqli_stmt_bind_param($stmt_ins_p, "sidsss", $kode_pesanan, $id_user, $total_final, $metode, $status_pesanan, $full_address);
        mysqli_stmt_execute($stmt_ins_p);
        $id_pesanan = mysqli_insert_id($conn);

        // B. Simpan Detail Pesanan & Potong Stok
        foreach ($items as $item) {
            $stmt_det = mysqli_prepare($conn, "
                INSERT INTO detail_pesanan (id_pesanan, id_buku, jumlah, harga, subtotal) 
                VALUES (?, ?, ?, ?, ?)
            ");
            mysqli_stmt_bind_param($stmt_det, "iiidd", $id_pesanan, $item['id_buku'], $item['jumlah'], $item['harga'], $item['subtotal']);
            mysqli_stmt_execute($stmt_det);

            $stmt_stok = mysqli_prepare($conn, "UPDATE buku SET stok = stok - ? WHERE id_buku = ?");
            mysqli_stmt_bind_param($stmt_stok, "ii", $item['jumlah'], $item['id_buku']);
            mysqli_stmt_execute($stmt_stok);
        }

        // C. Simpan Pembayaran
        $stmt_pay = mysqli_prepare($conn, "
            INSERT INTO pembayaran (id_pesanan, metode, bukti, status) 
            VALUES (?, ?, ?, ?)
        ");
        mysqli_stmt_bind_param($stmt_pay, "isss", $id_pesanan, $metode, $bukti, $status_pembayaran);
        mysqli_stmt_execute($stmt_pay);

        // D. Simpan Notifikasi
        $pesan_notif = "Pesanan " . $kode_pesanan . " berhasil dibuat. Silakan tunggu konfirmasi admin.";
        $stmt_notif = mysqli_prepare($conn, "
            INSERT INTO notifikasi (id_user, pesan, status) 
            VALUES (?, ?, 'Belum Dibaca')
        ");
        mysqli_stmt_bind_param($stmt_notif, "is", $id_user, $pesan_notif);
        mysqli_stmt_execute($stmt_notif);

        // E. Jika user menggunakan voucher pada transaksi ini, tandai di database agar voucher hangus
        if ($nominal_diskon > 0) {
            $stmt_mark_voucher = mysqli_prepare($conn, "UPDATE users SET voucher_terpakai = 1 WHERE id_user = ?");
            mysqli_stmt_bind_param($stmt_mark_voucher, "i", $id_user);
            mysqli_stmt_execute($stmt_mark_voucher);
        }

        // F. Bersihkan Keranjang & Session Promo
        $stmt_del = mysqli_prepare($conn, "DELETE FROM keranjang WHERE id_user = ?");
        mysqli_stmt_bind_param($stmt_del, "i", $id_user);
        mysqli_stmt_execute($stmt_del);

        unset($_SESSION['applied_promo']);
        unset($_SESSION['discount_rate']);

        echo "<script>
            alert('Checkout Berhasil! Kode Pesanan Anda: $kode_pesanan');
            window.location='history.php';
        </script>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout & Pembayaran | SKY Bookstore</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --shadow-md: 0 10px 25px rgba(78, 34, 15, 0.08);
            --radius-lg: 20px;
        }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }

        h1, h2, h3, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        .navbar-custom {
            background: var(--brand-dark-brown);
            padding: 14px 0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }

        .navbar-brand {
            color: #FFFFFF !important;
            font-weight: 800;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .card-custom {
            background: #FFFFFF;
            border: 1px solid rgba(78, 34, 15, 0.08);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
        }

        .book-cover {
            width: 55px;
            height: 75px;
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .form-control-custom, .form-select-custom {
            background: var(--brand-cream-bg);
            border: 1px solid rgba(78, 34, 15, 0.15);
            border-radius: 12px;
            padding: 10px 16px;
            font-size: 14px;
            color: var(--brand-dark-brown);
        }

        .form-control-custom:focus, .form-select-custom:focus {
            background: #FFFFFF;
            border-color: var(--brand-warm-brown);
            box-shadow: 0 0 0 4px rgba(157, 102, 56, 0.15);
            color: var(--brand-dark-brown);
        }

        .btn-checkout {
            background: var(--brand-warm-brown);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 14px;
            font-weight: 700;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .btn-checkout:hover {
            background: var(--brand-dark-brown);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(78, 34, 15, 0.2);
        }

        .promo-applied-badge {
            background: rgba(176, 186, 153, 0.3);
            color: var(--brand-dark-brown);
            border: 1px solid var(--brand-sage-green);
            border-radius: 12px;
            padding: 10px 16px;
            font-size: 13px;
            font-weight: 600;
        }

        footer {
            background: var(--brand-dark-brown);
            color: var(--brand-cream-bg);
            padding: 30px 0;
            margin-top: 80px;
            border-top: 4px solid var(--brand-warm-brown);
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-custom sticky-top">
        <div class="container">
            <a href="index.php" class="navbar-brand">
                <i class="fa-solid fa-book-open text-warning me-1"></i>
                <span>SKYBS BookStore</span>
            </a>
            <a href="keranjang.php" class="btn btn-sm btn-outline-light rounded-pill px-3">
                <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Keranjang
            </a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="mb-4">
            <h2 class="font-heading fw-bold mb-1" style="color: var(--brand-dark-brown);">Checkout & Pembayaran</h2>
            <p class="text-muted">Lengkapi data pengiriman dan pilih metode pembayaran untuk menyelesaikan pesanan.</p>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <div class="row g-4">
                
                <!-- SISI KIRI: RINGKASAN ITEM & BIAYA -->
                <div class="col-lg-7">
                    <div class="card-custom p-4 mb-4">
                        <h5 class="font-heading fw-bold mb-3 border-bottom pb-2" style="color: var(--brand-dark-brown);">
                            <i class="fa-solid fa-bag-shopping me-2" style="color: var(--brand-warm-brown);"></i>Ringkasan Pesanan
                        </h5>

                        <div class="table-responsive">
                            <table class="table align-middle mb-0">
                                <thead>
                                    <tr class="text-muted small">
                                        <th>Buku</th>
                                        <th class="text-center">Harga</th>
                                        <th class="text-center">Jumlah</th>
                                        <th class="text-end">Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($items as $item): ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center gap-3">
                                                    <img src="img/buku/<?= htmlspecialchars($item['cover']); ?>" 
                                                         alt="Cover" 
                                                         class="book-cover"
                                                         onerror="this.src='https://via.placeholder.com/55x75?text=No+Cover'">
                                                    <span class="fw-bold fs-6" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($item['judul']); ?></span>
                                                </div>
                                            </td>
                                            <td class="text-center small">
                                                Rp <?= number_format($item['harga'], 0, ",", "."); ?>
                                            </td>
                                            <td class="text-center fw-bold">
                                                <?= $item['jumlah']; ?>
                                            </td>
                                            <td class="text-end fw-bold" style="color: var(--brand-warm-brown);">
                                                Rp <?= number_format($item['subtotal'], 0, ",", "."); ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- PERHITUNGAN BIAYA & DISKON -->
                        <div class="border-top pt-3 mt-3">
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted">Subtotal Produk</span>
                                <span class="fw-bold">Rp <?= number_format($subtotal_produk, 0, ",", "."); ?></span>
                            </div>

                            <!-- BADGE PROMO DISKON -->
                            <?php if ($nominal_diskon > 0): ?>
                                <div class="promo-applied-badge d-flex justify-content-between align-items-center my-2">
                                    <span><i class="fa-solid fa-ticket me-2" style="color: var(--brand-warm-brown);"></i>Promo (<?= htmlspecialchars($promo_code); ?> - Diskon Aktif)</span>
                                    <span class="text-danger fw-bold">- Rp <?= number_format($nominal_diskon, 0, ",", "."); ?></span>
                                </div>
                            <?php endif; ?>

                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted">Ongkos Kirim (Dikirim dari Jakarta)</span>
                                <span class="fw-bold text-primary" id="textOngkir">Pilih Wilayah...</span>
                            </div>

                            <hr>

                            <div class="d-flex justify-content-between align-items-center">
                                <span class="font-heading fw-bold fs-5" style="color: var(--brand-dark-brown);">Total Pembayaran</span>
                                <span class="fw-extrabold fs-4" style="color: var(--brand-warm-brown);" id="textTotal">
                                    Rp <?= number_format(($subtotal_produk - $nominal_diskon), 0, ",", "."); ?>
                                </span>
                            </div>
                        </div>

                        <!-- INPUT VOUCHER & KUIS TANTANGAN -->
                        <div class="mt-4 pt-3 border-top">
                            <label class="form-label small fw-bold text-muted">Punya Kode Voucher / Ingin Tantangan Diskon?</label>
                            <?php if ($sudah_pernah_pakai): ?>
                                <div class="alert alert-warning py-2 small mb-0">
                                    <i class="fa-solid fa-circle-exclamation me-1"></i> Anda sudah pernah menggunakan voucher diskon pada transaksi sebelumnya. Voucher tidak dapat digunakan lagi.
                                </div>
                            <?php else: ?>
                                <div class="input-group mb-2">
                                    <input type="text" id="inputVoucherCode" class="form-control form-control-custom" placeholder="Masukkan kode voucher...">
                                    <button type="button" onclick="prosesVoucher()" class="btn btn-dark px-4 fw-bold" style="background: var(--brand-dark-brown);">Gunakan</button>
                                </div>
                                <div class="form-text text-muted" style="font-size: 11px;">
                                    💡 Coba masukkan <strong class="text-dark">`SKYBSHEBAT`</strong> atau ikuti <a href="klaim_voucher.php?code=PROMO" class="text-decoration-underline" style="color: var(--brand-warm-brown);">Kuis Tantangan Web</a> untuk klaim kupon! (Hanya 1x pakai)
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- SISI KANAN: FORM ALAMAT & ONGKIR -->
                <div class="col-lg-5">
                    <div class="card-custom p-4">
                        <h5 class="font-heading fw-bold mb-3 border-bottom pb-2" style="color: var(--brand-dark-brown);">
                            <i class="fa-solid fa-truck-fast me-2" style="color: var(--brand-warm-brown);"></i>Informasi Pengiriman
                        </h5>

                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">No. WhatsApp / HP</label>
                            <input type="text" name="no_hp" class="form-control form-control-custom" value="<?= htmlspecialchars($data_user['no_hp'] ?? ''); ?>" placeholder="Contoh: 081234567890" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">Kota / Wilayah Tujuan</label>
                            <select name="kota_tujuan" id="selectKota" class="form-select form-select-custom" onchange="hitungOngkir()" required>
                                <option value="">-- Pilih Kota Tujuan --</option>
                                <option value="Jakarta Pusat">Jakarta Pusat (Flat Rp 10.000)</option>
                                <option value="Jakarta Selatan">Jakarta Selatan (Flat Rp 10.000)</option>
                                <option value="Jakarta Barat">Jakarta Barat (Flat Rp 10.000)</option>
                                <option value="Jakarta Timur">Jakarta Timur (Flat Rp 10.000)</option>
                                <option value="Jakarta Utara">Jakarta Utara (Flat Rp 10.000)</option>
                                <option value="Luar Jakarta">Luar Jakarta / Lainnya (Rp 25.000)</option>
                            </select>
                            <small class="text-muted mt-1 d-block" style="font-size: 11px;">*Gudang pengiriman utama SKYBS berada di Jakarta.</small>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">Alamat Lengkap Pengiriman</label>
                            <textarea name="alamat_pengiriman" class="form-control form-control-custom" rows="3" placeholder="Masukkan jalan, RT/RW, kecamatan, dan kode pos" required><?= htmlspecialchars($data_user['alamat'] ?? ''); ?></textarea>
                        </div>

                        <h5 class="font-heading fw-bold my-3 border-bottom pb-2" style="color: var(--brand-dark-brown);">
                            <i class="fa-solid fa-wallet me-2" style="color: var(--brand-warm-brown);"></i>Metode Pembayaran
                        </h5>

                        <div class="mb-3">
                            <select name="metode" class="form-select form-select-custom" required>
                                <option value="">-- Pilih Metode Pembayaran --</option>
                                <optgroup label="Transfer Bank">
                                    <option value="BCA">Bank BCA (123-456-7890 a/n SKYBS)</option>
                                    <option value="BRI">Bank BRI (098-765-4321 a/n SKYBS)</option>
                                    <option value="Mandiri">Bank Mandiri (112-000-888 a/n SKYBS)</option>
                                </optgroup>
                                <optgroup label="E-Wallet & QRIS">
                                    <option value="DANA">DANA (085891403949)</option>
                                    <option value="GoPay">GoPay (085891403949)</option>
                                    <option value="QRIS">QRIS All Payment</option>
                                </optgroup>
                                <optgroup label="Lainnya">
                                    <option value="COD">COD (Bayar di Tempat)</option>
                                </optgroup>
                            </select>
                        </div>
                        <div class="mb-4">
                            <label class="form-label small fw-bold text-muted">Upload Bukti Transfer</label>
                            <input type="file" name="bukti" class="form-control form-control-custom" accept="image/*">
                            <div class="form-text text-muted small" style="font-size: 11px;">*Kosongkan jika Anda memilih metode COD.</div>
                        </div>

                        <button type="submit" name="checkout" class="btn btn-checkout w-100 shadow-sm">
                            <i class="fa-solid fa-paper-plane me-2"></i> Buat Pesanan Sekarang
                        </button>
                    </div>
                </div>

            </div>
        </form>
    </div>

    <footer class="text-center">
        <div class="container">
            <h6 class="fw-bold mb-1">SKY Bookstore</h6>
            <p class="small mb-0 opacity-75">&copy; <?= date('Y'); ?> SKY Bookstore. All Rights Reserved.</p>
        </div>
    </footer>

    <!-- SCRIPT JS UNTUK KALKULASI ONGKIR & VOUCHER -->
    <script>
        const subtotalProduk = <?= $subtotal_produk; ?>;
        const nominalDiskon = <?= $nominal_diskon; ?>;

        function hitungOngkir() {
            const selectKota = document.getElementById("selectKota").value;
            const textOngkir = document.getElementById("textOngkir");
            const textTotal = document.getElementById("textTotal");

            let ongkir = 0;

            if (selectKota === "") {
                textOngkir.innerText = "Pilih Wilayah...";
                ongkir = 0;
            } else if (selectKota.toLowerCase().includes("jakarta") && !selectKota.toLowerCase().includes("luar")) {
                ongkir = 10000;
                textOngkir.innerText = "Rp 10.000 (Flat Jakarta)";
            } else {
                ongkir = 25000;
                textOngkir.innerText = "Rp 25.000 (Luar Jakarta)";
            }

            let totalFinal = (subtotalProduk - nominalDiskon) + ongkir;
            if (totalFinal < ongkir) totalFinal = ongkir;
            
            textTotal.innerText = "Rp " + totalFinal.toLocaleString("id-ID");
        }

        function prosesVoucher() {
            const kode = document.getElementById('inputVoucherCode').value.trim();
            if (kode === "") {
                alert('Silakan masukkan kode voucher terlebih dahulu!');
                return;
            }
            window.location.href = 'checkout.php?promo=' + encodeURIComponent(kode);
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>