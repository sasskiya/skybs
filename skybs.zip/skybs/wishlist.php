<?php
session_start();
include "database.php";

// 1. Cek Autentikasi User
if (!isset($_SESSION['id_user'])) {
    echo "<script>
        alert('Silakan login terlebih dahulu!');
        window.location='login.php';
    </script>";
    exit;
}

$id_user = (int)$_SESSION['id_user'];

// 2. TAMBAH KE WISHLIST
if (isset($_GET['id'])) {
    $id_buku = (int)$_GET['id'];
    try {
        $stmt_cek = mysqli_prepare($conn, "SELECT id_wishlist FROM wishlist WHERE id_user = ? AND id_buku = ?");
        if ($stmt_cek) {
            mysqli_stmt_bind_param($stmt_cek, "ii", $id_user, $id_buku);
            mysqli_stmt_execute($stmt_cek);
            $res_cek = mysqli_stmt_get_result($stmt_cek);
            if ($res_cek && mysqli_num_rows($res_cek) == 0) {
                $stmt_ins = mysqli_prepare($conn, "INSERT INTO wishlist (id_user, id_buku) VALUES (?, ?)");
                if ($stmt_ins) {
                    mysqli_stmt_bind_param($stmt_ins, "ii", $id_user, $id_buku);
                    mysqli_stmt_execute($stmt_ins);
                }
            }
        }
    } catch (mysqli_sql_exception $e) {
        // Abaikan jika tabel belum ada
    }
    header("Location: wishlist.php");
    exit;
}

// 3. HAPUS ITEM DARI WISHLIST
if (isset($_GET['hapus'])) {
    $hapus_id = (int)$_GET['hapus'];
    try {
        $stmt_del = mysqli_prepare($conn, "DELETE FROM wishlist WHERE id_wishlist = ? AND id_user = ?");
        if ($stmt_del) {
            mysqli_stmt_bind_param($stmt_del, "ii", $hapus_id, $id_user);
            mysqli_stmt_execute($stmt_del);
        }
    } catch (mysqli_sql_exception $e) {
        // Abaikan jika tabel belum ada
    }
    header("Location: wishlist.php");
    exit;
}

// 4. AMBIL DATA WISHLIST
$data = false;
try {
    $stmt_get = mysqli_prepare($conn, "
        SELECT wishlist.id_wishlist, buku.*, kategori.nama_kategori 
        FROM wishlist 
        JOIN buku ON wishlist.id_buku = buku.id_buku 
        LEFT JOIN kategori ON buku.id_kategori = kategori.id_kategori 
        WHERE wishlist.id_user = ? 
        ORDER BY wishlist.id_wishlist DESC
    ");
    if ($stmt_get) {
        mysqli_stmt_bind_param($stmt_get, "i", $id_user);
        mysqli_stmt_execute($stmt_get);
        $data = mysqli_stmt_get_result($stmt_get);
    }
} catch (mysqli_sql_exception $e) {
    $data = false;
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wishlist Saya | SKY Bookstore</title>

    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <style>
        :root {
            --brand-dark-brown: #3C180A;
            --brand-warm-brown: #8D5524;
            --brand-sage-green: #97A97C;
            --brand-cream-bg: #F7F1DE;
            --brand-card-bg: #FCF9F0;
            --shadow-sm: 0 4px 20px rgba(60, 24, 10, 0.05);
            --shadow-md: 0 12px 30px rgba(60, 24, 10, 0.08);
            --radius-lg: 24px;
        }

        body { 
            background-color: var(--brand-cream-bg); 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            color: var(--brand-dark-brown); 
            min-height: 100vh; 
        }

        h1, h2, h3, h4, .font-heading { 
            font-family: 'Playfair Display', serif; 
        }

        /* --- NAVBAR --- */
        .navbar-custom { 
            background: rgba(60, 24, 10, 0.95); 
            backdrop-filter: blur(10px);
            padding: 14px 0; 
            box-shadow: 0 4px 25px rgba(0, 0, 0, 0.1); 
        }

        .navbar-brand { 
            color: #FFFFFF !important; 
            font-weight: 800; 
            font-size: 20px;
            display: flex; 
            align-items: center; 
            gap: 10px; 
            text-decoration: none;
        }

        /* --- BOOK CARD MODERN --- */
        .book-card { 
            background: var(--brand-card-bg); 
            border: 1px solid rgba(141, 85, 36, 0.12);
            border-radius: var(--radius-lg); 
            overflow: hidden; 
            box-shadow: var(--shadow-sm); 
            transition: all 0.3s ease; 
            height: 100%; 
            display: flex; 
            flex-direction: column; 
        }

        .book-card:hover { 
            transform: translateY(-6px); 
            box-shadow: var(--shadow-md); 
        }

        .book-cover-wrap { 
            position: relative; 
            height: 250px; 
            overflow: hidden; 
            background: #F4EEDC; 
        }

        .book-cover-wrap img { 
            width: 100%; 
            height: 100%; 
            object-fit: cover; 
            transition: transform 0.5s ease; 
        }

        .book-card:hover .book-cover-wrap img { 
            transform: scale(1.05); 
        }

        .price-tag { 
            font-size: 16px; 
            font-weight: 800; 
            color: var(--brand-warm-brown); 
        }

        /* --- BUTTONS --- */
        .btn-custom-primary { 
            background: var(--brand-dark-brown); 
            color: white; 
            border: none; 
            border-radius: 12px; 
            padding: 8px 12px; 
            font-size: 13px; 
            font-weight: 600; 
            transition: all 0.2s ease; 
        }

        .btn-custom-primary:hover { 
            background: var(--brand-warm-brown); 
            color: white; 
        }

        .btn-custom-danger { 
            background: #F8D7DA; 
            color: #842029; 
            border: none; 
            border-radius: 12px; 
            padding: 8px 12px; 
            font-size: 13px; 
            font-weight: 600; 
            transition: all 0.2s ease; 
        }

        .btn-custom-danger:hover { 
            background: #F5C2C7; 
            color: #842029; 
        }

        /* --- FOOTER --- */
        footer { 
            background: var(--brand-dark-brown); 
            color: var(--brand-cream-bg); 
            padding: 40px 0 25px; 
            margin-top: 80px; 
            border-top: 4px solid var(--brand-warm-brown);
        }
    </style>
</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-custom sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fa-solid fa-book-open text-warning"></i>
                <span>SKY Bookstore</span>
            </a>
            <div class="ms-auto">
                <a href="index.php" class="btn btn-sm btn-outline-light rounded-pill px-3 fw-semibold">
                    <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Beranda
                </a>
            </div>
        </div>
    </nav>

    <!-- KONTEN UTAMA -->
    <div class="container py-5 animate__animated animate__fadeIn">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <div>
                <h2 class="font-heading fw-bold mb-1" style="color: var(--brand-dark-brown);">
                    <i class="fa-solid fa-heart text-danger me-2"></i>Wishlist Saya
                </h2>
                <p class="text-muted small mb-0">Daftar buku favorit yang telah Anda simpan.</p>
            </div>
        </div>

        <?php if ($data && mysqli_num_rows($data) > 0): ?>
            <div class="row g-4">
                <?php while ($d = mysqli_fetch_assoc($data)): ?>
                    <?php
                    $cover_path = "img/buku/" . $d['cover'];
                    $img_src = (!empty($d['cover']) && file_exists($cover_path)) ? $cover_path : "https://via.placeholder.com/260x360?text=No+Cover";
                    ?>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="book-card">
                            <div class="book-cover-wrap">
                                <span class="badge bg-danger position-absolute top-0 start-0 m-2 rounded-pill px-3 py-1 shadow-sm" style="font-size: 10px;">FAVORIT</span>
                                <img src="<?= htmlspecialchars($img_src); ?>" alt="<?= htmlspecialchars($d['judul']); ?>">
                            </div>
                            <div class="p-3 d-flex flex-column flex-grow-1">
                                <small class="text-muted fw-bold mb-1 text-uppercase" style="font-size: 10px;">
                                    <?= !empty($d['nama_kategori']) ? htmlspecialchars($d['nama_kategori']) : 'Umum'; ?>
                                </small>
                                <h6 class="fw-bold text-dark text-truncate mb-1" title="<?= htmlspecialchars($d['judul']); ?>">
                                    <?= htmlspecialchars($d['judul']); ?>
                                </h6>
                                <small class="text-muted mb-2 text-truncate" style="font-size: 12px;">
                                    <i class="fa-solid fa-pen-nib me-1"></i><?= htmlspecialchars($d['penulis'] ?? 'Anonim'); ?>
                                </small>
                                <div class="price-tag mb-3 mt-auto">Rp <?= number_format($d['harga'], 0, ",", "."); ?></div>
                                <div class="d-grid gap-2">
                                    <a href="keranjang.php?id=<?= $d['id_buku']; ?>" class="btn btn-custom-primary btn-sm text-center">
                                        <i class="fa-solid fa-cart-plus me-1"></i> Beli / Masuk Keranjang
                                    </a>
                                    <a href="?hapus=<?= $d['id_wishlist']; ?>" class="btn btn-custom-danger btn-sm text-center" onclick="return confirm('Apakah Anda yakin ingin menghapus buku ini dari wishlist?')">
                                        <i class="fa-solid fa-trash me-1"></i> Hapus
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="card p-5 text-center shadow-sm border-0 rounded-4 mt-4" style="background: var(--brand-card-bg);">
                <div class="mb-3">
                    <i class="fa-regular fa-heart fs-1 text-warning opacity-75"></i>
                </div>
                <h4 class="fw-bold font-heading mb-2">Wishlist Anda Masih Kosong</h4>
                <p class="text-muted small mb-4">Ayo mulai jelajahi katalog buku kami dan simpan buku favorit Anda di sini!</p>
                <div>
                    <a href="index.php" class="btn btn-custom-primary px-4 py-2 rounded-pill shadow-sm">
                        <i class="fa-solid fa-compass me-2"></i> Jelajahi Katalog Buku
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- FOOTER -->
    <footer>
        <div class="container text-center">
            <p class="mb-0 small text-white-50">&copy; <?= date("Y"); ?> <strong>SKY Bookstore</strong>. All Rights Reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>