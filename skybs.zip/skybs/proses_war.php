<?php
session_start();
include "database.php";

/* =========================================================
   CEK LOGIN USER
========================================================= */
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit();
}

$id_user = (int) $_SESSION['id_user'];

/* =========================================================
   AMBIL ID BUKU WAR
========================================================= */
if (!isset($_GET['buku']) || !is_numeric($_GET['buku'])) {
    die("Buku War tidak ditemukan.");
}

$id_buku_war = (int) $_GET['buku'];

/* =========================================================
   CEK TABEL TRANSAKSI
========================================================= */
$cek_tabel = mysqli_query($conn, "SHOW TABLES LIKE 'transaksi'");

if (!$cek_tabel || mysqli_num_rows($cek_tabel) == 0) {

    $buat_tabel = mysqli_query($conn, "
        CREATE TABLE transaksi (
            id_transaksi INT AUTO_INCREMENT PRIMARY KEY,
            id_user INT NOT NULL,
            id_buku INT NOT NULL,
            tipe VARCHAR(50) DEFAULT 'war',
            total_harga DECIMAL(10,2) NOT NULL,
            tanggal DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    if (!$buat_tabel) {
        die("Gagal membuat tabel transaksi: " . mysqli_error($conn));
    }
}

/* =========================================================
   CEK JUMLAH TIKET WAR USER
   MAKSIMAL 2 TIKET PER AKUN
========================================================= */
$stmt_limit = mysqli_prepare(
    $conn,
    "
    SELECT COUNT(*) AS jumlah
    FROM transaksi
    WHERE id_user = ?
    AND tipe = 'war'
    "
);

mysqli_stmt_bind_param($stmt_limit, "i", $id_user);
mysqli_stmt_execute($stmt_limit);

$result_limit = mysqli_stmt_get_result($stmt_limit);
$data_limit = mysqli_fetch_assoc($result_limit);

$jumlah_tiket = (int) ($data_limit['jumlah'] ?? 0);

if ($jumlah_tiket >= 2) {

    echo "
    <script>
        alert('Maaf, maksimal pembelian War adalah 2 tiket per akun.');
        window.location.href = 'myticket.php';
    </script>
    ";

    exit();
}

/* =========================================================
   AMBIL DATA BUKU WAR
   HARUS BERTIPE WAR
========================================================= */

$stmt_buku = mysqli_prepare(
    $conn,
    "
    SELECT id_buku, judul, harga, stok
    FROM buku
    WHERE id_buku = ?
    LIMIT 1
    "
);


mysqli_stmt_bind_param($stmt_buku, "i", $id_buku_war);
mysqli_stmt_execute($stmt_buku);

$result_buku = mysqli_stmt_get_result($stmt_buku);
$data_buku = mysqli_fetch_assoc($result_buku);

if (!$data_buku) {

    echo "
    <script>
        alert('Buku War tidak ditemukan atau bukan buku War.');
        window.location.href = 'index.php';
    </script>
    ";

    exit();
}


/* =========================================================
   CEK STOK
========================================================= */

$stok = (int) $data_buku['stok'];

if ($stok <= 0) {

    echo "
    <script>
        alert('Maaf, stok tiket sudah habis.');
        window.location.href = 'index.php';
    </script>
    ";

    exit();
}


/* =========================================================
   CEK JADWAL WAR
   Waktu selesai berasal dari database.
========================================================= */

$q_set_war = mysqli_query(
    $conn,
    "SELECT * FROM pengaturan_war WHERE id = 1"
);

$data_set_war = mysqli_fetch_assoc($q_set_war);

$waktu_mulai = $data_set_war['waktu_mulai'] ?? null;
$waktu_selesai = $data_set_war['waktu_selesai'] ?? null;

$sekarang = date('Y-m-d H:i:s');


/* =========================================================
   CEK STATUS WAR
========================================================= */

if (!empty($waktu_mulai) && $sekarang < $waktu_mulai) {

    echo "
    <script>
        alert('War tiket belum dibuka.');
        window.location.href = 'index.php';
    </script>
    ";

    exit();
}

if (!empty($waktu_selesai) && $sekarang > $waktu_selesai) {

    echo "
    <script>
        alert('War tiket sudah ditutup.');
        window.location.href = 'index.php';
    </script>
    ";

    exit();
}


/* =========================================================
   AMBIL HARGA DARI DATABASE
========================================================= */

$harga_war = (float) $data_buku['harga'];


/* =========================================================
   MULAI TRANSAKSI DATABASE
========================================================= */

mysqli_begin_transaction($conn);

try {

    /* Kunci stok agar tidak bentrok saat banyak user membeli bersamaan */

    $stmt_stok = mysqli_prepare(
        $conn,
        "
        SELECT stok
        FROM buku
        WHERE id_buku = ?
        AND tipe_buku = 'war'
        FOR UPDATE
        "
    );

    mysqli_stmt_bind_param($stmt_stok, "i", $id_buku_war);
    mysqli_stmt_execute($stmt_stok);

    $result_stok = mysqli_stmt_get_result($stmt_stok);
    $data_stok = mysqli_fetch_assoc($result_stok);

    if (!$data_stok || (int) $data_stok['stok'] <= 0) {
        throw new Exception("Stok tiket sudah habis.");
    }


    /* Simpan transaksi */

    $stmt_transaksi = mysqli_prepare(
        $conn,
        "
        INSERT INTO transaksi
        (id_user, id_buku, tipe, total_harga)
        VALUES (?, ?, 'war', ?)
        "
    );

    mysqli_stmt_bind_param(
        $stmt_transaksi,
        "iid",
        $id_user,
        $id_buku_war,
        $harga_war
    );

    if (!mysqli_stmt_execute($stmt_transaksi)) {
        throw new Exception("Gagal menyimpan transaksi.");
    }


    /* Kurangi stok buku War */

    $stmt_update_stok = mysqli_prepare(
        $conn,
        "
        UPDATE buku
        SET stok = stok - 1
        WHERE id_buku = ?
        AND tipe_buku = 'war'
        AND stok > 0
        "
    );

    mysqli_stmt_bind_param(
        $stmt_update_stok,
        "i",
        $id_buku_war
    );

    if (!mysqli_stmt_execute($stmt_update_stok)) {
        throw new Exception("Gagal mengurangi stok.");
    }


    /* Simpan semua perubahan */

    mysqli_commit($conn);


    echo "
    <script>
        alert('Berhasil! Tiket War berhasil diamankan.');
        window.location.href = 'myticket.php';
    </script>
    ";

    exit();

} catch (Exception $e) {

    mysqli_rollback($conn);

    echo "
    <script>
        alert('Gagal mengamankan tiket: " . addslashes($e->getMessage()) . "');
        window.location.href = 'index.php';
    </script>
    ";

    exit();
}
?>