<?php
session_start();
include "database.php";

// Cek status login user
$is_logged_in = isset($_SESSION['id_user']);
$user_data = null;

if ($is_logged_in) {
    $id_user = (int)$_SESSION['id_user'];
    $stmt_user = mysqli_prepare($conn, "SELECT nama, foto FROM users WHERE id_user = ?");
    mysqli_stmt_bind_param($stmt_user, "i", $id_user);
    mysqli_stmt_execute($stmt_user);
    $res_user = mysqli_stmt_get_result($stmt_user);
    $user_data = mysqli_fetch_assoc($res_user);
}

// Ambil Kategori untuk Menu Footer
$query_kategori = mysqli_query($conn, "SELECT * FROM kategori ORDER BY nama_kategori ASC");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami | SKY Bookstore </title>

    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <style>
        :root {
            --brand-dark-brown: #3C180A;
            --brand-warm-brown: #8D5524;
            --brand-sage-green: #97A97C;
            --brand-cream-bg: #F7F1DE;
            --brand-card-bg: #FCF9F0;
            --shadow-sm: 0 4px 20px rgba(60, 24, 10, 0.05);
            --shadow-md: 0 12px 30px rgba(60, 24, 10, 0.08);
            --radius-lg: 24px;
        }

        body {
            margin: 0;
            background-color: var(--brand-cream-bg);
            color: var(--brand-dark-brown);
            font-family: 'Plus Jakarta Sans', sans-serif;
            min-height: 100vh;
        }

        h1, h2, h3, h4, h5, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        /* --- NAVBAR --- */
        .navbar-custom {
            background: rgba(60, 24, 10, 0.95);
            backdrop-filter: blur(10px);
            padding: 14px 0;
            box-shadow: 0 4px 25px rgba(0, 0, 0, 0.1);
        }

        .navbar-brand {
            color: #FFFFFF !important;
            font-weight: 800;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.85) !important;
            font-size: 14px;
            font-weight: 500;
            margin: 0 4px;
            transition: color 0.2s;
        }

        .nav-link:hover, .nav-link.active {
            color: #FFFFFF !important;
        }

        .user-avatar-nav {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--brand-warm-brown);
        }

        /* --- HERO SECTION --- */
        .hero {
            min-height: 380px;
            display: flex;
            align-items: center;
            position: relative;
            overflow: hidden;
            background: linear-gradient(rgba(60, 24, 10, 0.88), rgba(60, 24, 10, 0.88)), url('img/about-bg.jpg') center/cover;
            border-bottom: 4px solid var(--brand-warm-brown);
        }

        .hero-content {
            color: white;
            text-align: center;
            max-width: 750px;
            margin: auto;
        }

        .hero-content h1 {
            font-size: 46px;
            margin-bottom: 15px;
            font-weight: 700;
        }

        .hero-content p {
            color: rgba(255, 255, 255, 0.85);
            line-height: 1.8;
            font-size: 15px;
        }

        /* --- SECTION & CARDS --- */
        .section-title {
            text-align: center;
            margin-bottom: 45px;
        }

        .section-title h2 {
            font-size: 32px;
            font-weight: 700;
        }

        .section-title p {
            color: #776b63;
            font-size: 14px;
        }

        .about-card {
            background: var(--brand-card-bg);
            border-radius: var(--radius-lg);
            padding: 35px;
            height: 100%;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(141, 85, 36, 0.12);
            transition: transform 0.3s ease;
        }

        .about-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
        }

        .about-card i {
            font-size: 36px;
            color: var(--brand-warm-brown);
            margin-bottom: 20px;
        }

        .about-card h4 {
            font-weight: 700;
            margin-bottom: 15px;
            font-size: 20px;
        }

        .about-card p {
            color: #776b63;
            font-size: 14px;
            line-height: 1.9;
            margin: 0;
        }

        .story-section {
            background: #FFFFFF;
            border-top: 1px solid rgba(141, 85, 36, 0.1);
            border-bottom: 1px solid rgba(141, 85, 36, 0.1);
        }

        .story-box p {
            color: #776b63;
            line-height: 1.9;
            font-size: 15px;
        }

        .highlight {
            color: var(--brand-warm-brown);
            font-weight: 700;
            font-style: italic;
        }

        /* --- STATS --- */
        .stats {
            background: var(--brand-dark-brown);
            color: white;
            border-radius: var(--radius-lg);
            padding: 40px 20px;
            box-shadow: var(--shadow-md);
        }

        .stat-item {
            text-align: center;
            border-right: 1px solid rgba(255, 255, 255, 0.15);
        }

        .stat-item:last-child {
            border-right: none;
        }

        .stat-item h3 {
            font-size: 36px;
            color: #FFC107;
            margin-bottom: 5px;
            font-weight: 800;
        }

        .stat-item p {
            margin: 0;
            font-size: 13px;
            color: rgba(255, 255, 255, 0.75);
        }

        /* --- FOOTER --- */
        footer {
            background: var(--brand-dark-brown);
            color: white;
            margin-top: 80px;
            padding: 60px 0 25px;
            border-top: 4px solid var(--brand-warm-brown);
        }

        footer h5, footer h6 {
            color: #FFC107;
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            margin-bottom: 20px;
        }

        footer p, footer a {
            color: rgba(255, 255, 255, 0.7);
            font-size: 13px;
            line-height: 1.8;
            text-decoration: none;
            transition: color 0.2s;
        }

        footer a:hover {
            color: #FFFFFF;
        }

        .footer-bottom {
            border-top: 1px solid rgba(255, 255, 255, 0.12);
            margin-top: 40px;
            padding-top: 20px;
            text-align: center;
            color: rgba(255, 255, 255, 0.5);
            font-size: 12px;
        }

        @media (max-width: 768px) {
            .hero-content h1 {
                font-size: 34px;
            }
            .hero {
                min-height: 320px;
            }
            .stat-item {
                border-right: none;
                border-bottom: 1px solid rgba(255, 255, 255, 0.15);
                padding: 15px 0;
            }
            .stat-item:last-child {
                border-bottom: none;
            }
        }
    </style>
</head>

<body>

    <!-- NAVBAR RESPONSIF -->
    <nav class="navbar navbar-expand-lg navbar-custom sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fa-solid fa-book-open text-warning me-2"></i>
                SKY Bookstore
            </a>

            <button class="navbar-toggler border-0 text-white shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <i class="fa-solid fa-bars-staggered fs-5"></i>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-lg-center mt-3 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="fa-solid fa-house me-1"></i> Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="about.php"><i class="fa-solid fa-circle-info me-1"></i> Tentang Kami</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php"><i class="fa-solid fa-headset me-1"></i> Kontak</a>
                    </li>
                    <?php if ($is_logged_in): ?>
                        <li class="nav-item"><a class="nav-link" href="myticket.php"><i class="fa-solid fa-ticket me-1"></i> Tiket Saya</a></li>
                    <?php endif; ?>

                    <?php if ($is_logged_in): ?>
                        <li class="nav-item ms-lg-3 mt-2 mt-lg-0">
                            <?php
                            $foto_user = "img/default.png";
                            if (!empty($user_data['foto'])) {
                                if (file_exists("img/users/" . $user_data['foto'])) $foto_user = "img/users/" . $user_data['foto'];
                                elseif (file_exists("img/" . $user_data['foto'])) $foto_user = "img/" . $user_data['foto'];
                            }
                            ?>
                            <a href="profil.php" class="btn btn-sm btn-light rounded-pill px-3 py-1 fw-bold d-inline-flex align-items-center gap-2 shadow-sm text-dark text-decoration-none">
                                <img src="<?= $foto_user; ?>" alt="Avatar" class="user-avatar-nav" style="width:26px; height:26px;">
                                <span><?= htmlspecialchars($user_data['nama'] ?? 'Profil'); ?></span>
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item ms-lg-3 mt-3 mt-lg-0">
                            <a href="login.php" class="btn btn-sm btn-outline-light rounded-pill px-4 fw-semibold py-2">
                                <i class="fa-solid fa-right-to-bracket me-1"></i> Masuk
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- HERO SECTION -->
    <section class="hero">
        <div class="container animate__animated animate__fadeIn">
            <div class="hero-content">
                <span class="badge bg-warning text-dark rounded-pill px-3 py-2 mb-3 fw-bold">
                    ABOUT SKY Bookstore
                </span>
                <h1>Tentang Kami</h1>
                <p>
                    Jendela dunia dan inspirasi tanpa batas. Kami hadir sebagai platform toko buku digital tepercaya 
                    yang menyediakan koleksi bacaan berkualitas tinggi untuk meningkatkan literasi di Indonesia.
                </p>
            </div>
        </div>
    </section>

    <!-- KONTEN KEUNGGULAN -->
    <section class="py-5">
        <div class="container">
            <div class="section-title">
                <h2>Kenapa Memilih SKY Bookstore?</h2>
                <p>Komitmen kami dalam memberikan pengalaman berbelanja dan membaca buku terbaik.</p>
            </div>

            <div class="row g-4">
                <div class="col-md-4">
                    <div class="about-card">
                        <i class="fa-solid fa-circle-check"></i>
                        <h4>100% Original</h4>
                        <p>
                            Semua buku dan koleksi novel yang kami sediakan dijamin keasliannya langsung dari penerbit resmi.
                        </p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="about-card">
                        <i class="fa-solid fa-truck-fast"></i>
                        <h4>Kirim Cepat</h4>
                        <p>
                            Proses pengemasan aman dan pengiriman cepat ke seluruh wilayah di Indonesia agar buku sampai tepat waktu.
                        </p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="about-card">
                        <i class="fa-solid fa-headset"></i>
                        <h4>Layanan 24/7</h4>
                        <p>
                            Dukungan layanan pelanggan yang siap membantu menjawab pertanyaan dan kendala belanja Anda kapan pun dibutuhkan.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CERITA SKYBS -->
    <section class="story-section py-5">
        <div class="container">
            <div class="row align-items-center g-5">
                <div class="col-lg-6">
                    <img
                        src="img/logo/skybs.png"
                        alt="Koleksi Buku SKYBS"
                        class="img-fluid rounded-4 shadow-sm"
                        style="width:100%; height:380px; object-fit:cover;"
                        onerror="this.src='https://via.placeholder.com/800x500?text=SKYBS+BookStore'"
                    >
                </div>
                <div class="col-lg-6">
                    <div class="story-box">
                        <span class="text-uppercase small fw-bold" style="color:var(--brand-warm-brown); letter-spacing:2px;">
                            Cerita Kami
                        </span>
                        <h2 class="mt-2 mb-4 font-heading fw-bold">
                            Membaca Lebih Mudah, Menemukan Lebih Banyak Cerita.
                        </h2>
                        <p>
                            Didirikan dengan semangat untuk meningkatkan literasi membaca di Indonesia, <strong>SKY Bookstore </strong> hadir sebagai toko buku digital tepercaya yang mempermudah pembaca menemukan buku favorit mereka.
                        </p>
                        <p>
                            Melalui platform online yang praktis dan fitur modern seperti war tiket eksklusif serta katalog kategori lengkap, kami terus berinovasi menghubungkan pembaca dengan dunia literasi.
                        </p>
                        <p class="highlight mt-3">
                            “Setiap buku memiliki cerita. Setiap pembaca memiliki perjalanan.”
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- STATISTIK -->
    <section class="py-5">
        <div class="container">
            <div class="stats">
                <div class="row g-0">
                    <div class="col-md-3 col-6 stat-item mb-3 mb-md-0">
                        <h3>100+</h3>
                        <p>Koleksi Buku</p>
                    </div>
                    <div class="col-md-3 col-6 stat-item mb-3 mb-md-0">
                        <h3>10</h3>
                        <p>Kategori Pilihan</p>
                    </div>
                    <div class="col-md-3 col-6 stat-item">
                        <h3>24/7</h3>
                        <p>Akses Platform</p>
                    </div>
                    <div class="col-md-3 col-6 stat-item">
                        <h3>100%</h3>
                        <p>Kepuasan Pembaca</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- VISI MISI -->
    <section class="py-5">
        <div class="container">
            <div class="section-title">
                <h2>Visi & Misi</h2>
                <p>Tujuan utama yang menjadi landasan pengembangan SKYBS </p>
            </div>

            <div class="row g-4">
                <div class="col-md-6">
                    <div class="about-card">
                        <i class="fa-solid fa-eye"></i>
                        <h4>Visi</h4>
                        <p>
                            Menjadi platform toko buku digital nomor satu yang modern, mudah diakses, dan memberikan pengalaman berbelanja buku terbaik bagi seluruh masyarakat Indonesia.
                        </p>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="about-card">
                        <i class="fa-solid fa-bullseye"></i>
                        <h4>Misi</h4>
                        <p>
                            Menyediakan koleksi buku original yang beragam, menghadirkan kemudahan transaksi digital, serta berkomitmen meningkatkan minat baca melalui layanan prima.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FOOTER -->
    <footer>
        <div class="container">
            <div class="row g-4 mb-5">
                <div class="col-lg-4">
                    <h5 class="text-warning"><i class="fa-solid fa-book-open me-2"></i>SKY Bookstore</h5>
                    <p class="small text-white-50">Platform toko buku digital tepercaya dengan ribuan koleksi novel dan buku pengetahuan terlengkap.</p>
                </div>
                <div class="col-lg-3 col-6">
                    <h6 class="text-white text-uppercase fs-6">Kategori Pilihan</h6>
                    <ul class="list-unstyled small">
                        <?php 
                        mysqli_data_seek($query_kategori, 0);
                        $count = 0;
                        while ($k_foot = mysqli_fetch_assoc($query_kategori)): 
                            if ($count >= 5) break;
                            $count++;
                        ?>
                            <li class="mb-2"><a href="index.php?kategori=<?= $k_foot['id_kategori']; ?>"><i class="fa-solid fa-angle-right me-1 small"></i> <?= htmlspecialchars($k_foot['nama_kategori']); ?></a></li>
                        <?php endwhile; ?>
                    </ul>
                </div>
                <div class="col-lg-5">
                    <h6 class="text-white text-uppercase fs-6">Hubungi & Lokasi Kami</h6>
                    <ul class="list-unstyled small text-white-50">
                        <li class="mb-2 d-flex gap-2"><i class="fa-solid fa-location-dot text-warning mt-1"></i><span>Jl. Raya Pendidikan No. 45, Jakarta Pusat</span></li>
                        <li class="mb-2 d-flex gap-2"><i class="fa-solid fa-envelope text-warning mt-1"></i><span>SKY Bookstore@gmail.com</span></li>
                        <li class="mb-2 d-flex gap-2"><i class="fa-solid fa-phone text-warning mt-1"></i><span>+62 858-9140-3949</span></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                © <?= date('Y'); ?> <strong>SKY Bookstore </strong>. All Rights Reserved.
            </div>
        </div>
    </footer>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>