<?php
session_start();
include "database.php";

if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit();
}

$id_user = (int) $_SESSION['id_user'];

/*
|--------------------------------------------------------------------------
| FUNGSI BANTUAN
|--------------------------------------------------------------------------
*/

function getWarCover($cover)
{
    $cover = trim((string) $cover);
    if ($cover === '') {
        return 'img/default-book.png';
    }
    if (filter_var($cover, FILTER_VALIDATE_URL)) {
        return $cover;
    }
    $nama_file = basename($cover);
    $folder = __DIR__ . '/img/war/';
    $url_folder = 'img/war/';

    $kemungkinan_file = [
        $nama_file,
        $nama_file . '.jpg',
        $nama_file . '.jpeg',
        $nama_file . '.png',
        $nama_file . '.webp'
    ];

    foreach ($kemungkinan_file as $file) {
        if (file_exists($folder . $file)) {
            return $url_folder . $file;
        }
    }
    return 'img/default-book.png';
}

// Cek apakah sudah dibayar berdasarkan status transaksi atau adanya pesanan terkait
function isSudahBayar($t)
{
    $status = strtolower(trim($t['status'] ?? ''));
    $status_pesanan = strtolower(trim($t['status_pesanan'] ?? ''));

    // Jika status transaksi 'Checkout Selesai' atau ada data pesanan (id_pesanan_terkait tidak null)
    if ($status === 'checkout selesai' || !empty($t['id_pesanan_terkait'])) {
        return true;
    }

    $status_sudah_bayar = [
        'paid', 'dibayar', 'sudah_dibayar', 'lunas', 'terverifikasi', 'berhasil', 'diproses', 'dikirim', 'selesai'
    ];

    if (in_array($status, $status_sudah_bayar) || in_array($status_pesanan, $status_sudah_bayar)) {
        return true;
    }

    return false;
}

function getStatusTiket($t)
{
    $status = strtolower(trim($t['status'] ?? ''));
    if ($status === 'checkout selesai' || !empty($t['id_pesanan_terkait'])) {
        return 'Sudah Dibayar';
    }
    if (in_array($status, ['paid', 'dibayar', 'sudah_dibayar', 'lunas', 'terverifikasi'])) {
        return 'Sudah Dibayar';
    }
    if (in_array($status, ['menunggu konfirmasi', 'menunggu_verifikasi', 'pending_verifikasi', 'menunggu pembayaran'])) {
        return 'Menunggu Verifikasi';
    }
    if ($status === 'diproses') {
        return 'Sedang Diproses';
    }
    if ($status === 'dikirim') {
        return 'Sedang Dikirim';
    }
    if ($status === 'selesai') {
        return 'Pesanan Selesai';
    }
    return 'Belum Dibayar';
}

function getFotoUser($foto)
{
    $foto = trim((string) $foto);
    if ($foto === '') {
        return 'img/default.png';
    }
    $kemungkinan = ['img/users/' . $foto, 'img/' . $foto, $foto];
    foreach ($kemungkinan as $path) {
        if (file_exists(__DIR__ . '/' . $path)) {
            return $path;
        }
    }
    return 'img/default.png';
}

$stmt_user = mysqli_prepare($conn, "SELECT nama, foto FROM users WHERE id_user = ? LIMIT 1");
mysqli_stmt_bind_param($stmt_user, "i", $id_user);
mysqli_stmt_execute($stmt_user);
$result_user = mysqli_stmt_get_result($stmt_user);
$user_data = mysqli_fetch_assoc($result_user);

if (!$user_data) {
    $user_data = ['nama' => 'User', 'foto' => ''];
}
$foto_user = getFotoUser($user_data['foto']);

// Ambil tiket war dengan mencocokkan apakah ada pesanan yang alamat_pengirimannya memuat kode tiket war
$query_tiket = false;
$cek_tabel = mysqli_query($conn, "SHOW TABLES LIKE 'transaksi'");

if ($cek_tabel && mysqli_num_rows($cek_tabel) > 0) {
    $query_tiket = mysqli_query(
        $conn,
        "
        SELECT 
            transaksi.*, 
            buku.judul, 
            buku.penulis, 
            buku.cover AS cover_buku, 
            buku.harga AS harga_buku,
            pesanan.id_pesanan AS id_pesanan_terkait,
            pesanan.status AS status_pesanan
        FROM transaksi
        LEFT JOIN buku ON transaksi.id_buku = buku.id_buku
        LEFT JOIN pesanan ON pesanan.alamat_pengiriman LIKE CONCAT('%SKYBS-WAR-', LPAD(transaksi.id_transaksi, 5, '0'), '%')
        WHERE transaksi.id_user = $id_user
          AND transaksi.tipe = 'war'
        ORDER BY transaksi.id_transaksi DESC
        "
    );
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tiket & Status War Saya | SKY BookStore</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        :root {
            --brand-dark-brown: #3C180A;
            --brand-warm-brown: #8D5524;
            --brand-sage-green: #97A97C;
            --brand-cream-bg: #FDFBF7;
            --shadow-sm: 0 4px 20px rgba(60, 24, 10, 0.05);
            --shadow-md: 0 12px 30px rgba(60, 24, 10, 0.08);
            --radius-lg: 24px;
        }
        body { background-color: var(--brand-cream-bg); font-family: 'Plus Jakarta Sans', sans-serif; color: var(--brand-dark-brown); min-height: 100vh; }
        h1, h2, h3, h4, .font-heading { font-family: 'Playfair Display', serif; }
        .navbar-custom { background: var(--brand-dark-brown); padding: 16px 0; box-shadow: 0 4px 25px rgba(0, 0, 0, 0.12); }
        .navbar-brand { color: #FFFFFF !important; font-weight: 800; font-size: 22px; display: flex; align-items: center; gap: 10px; }
        .nav-link { color: rgba(255, 255, 255, 0.85) !important; font-weight: 500; font-size: 14px; margin: 0 4px; transition: color 0.2s; }
        .nav-link:hover, .nav-link.active { color: #FFFFFF !important; }
        .ticket-card { background: #FFFFFF; border: 2px dashed var(--brand-warm-brown); border-radius: var(--radius-lg); box-shadow: var(--shadow-sm); overflow: hidden; transition: all 0.3s ease; position: relative; }
        .ticket-card:hover { transform: translateY(-5px); box-shadow: var(--shadow-md); }
        .ticket-header { background: var(--brand-dark-brown); color: white; padding: 15px 20px; }
        .ticket-body { padding: 20px; }
        .ticket-footer { background: #F4EEDC; padding: 15px 20px; border-top: 1px dashed rgba(141, 85, 36, 0.2); }
        .user-avatar-nav { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; border: 2px solid var(--brand-warm-brown); }
        .cover-war { height: 100px; width: 100%; object-fit: cover; border-radius: 12px; box-shadow: var(--shadow-sm); background: #f2f2f2; }
        .status-badge { display: inline-flex; align-items: center; gap: 6px; padding: 8px 13px; border-radius: 20px; font-size: 11px; font-weight: 700; }
        .status-paid { background: #dff5e5; color: #218739; }
        .status-warning { background: #fff0c7; color: #9a6800; }
        .btn-payment { background: #24282c; color: white; border: none; transition: 0.2s; }
        .btn-payment:hover { background: #000000; color: white; }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-custom sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fa-solid fa-book-open text-warning"></i>
                <span>SKY Bookstore</span>
            </a>
            <div class="collapse navbar-collapse" id="menuNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="index.php">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link active" href="myticket.php"><i class="fa-solid fa-ticket me-1"></i>Tiket & Status War</a></li>
                </ul>
                <div class="d-flex align-items-center gap-3">
                    <a href="keranjang.php" class="nav-link text-white"><i class="fa-solid fa-cart-shopping me-1"></i>Keranjang</a>
                    <div class="dropdown">
                        <button class="btn btn-sm btn-light rounded-pill px-3 py-1 dropdown-toggle fw-bold d-flex align-items-center gap-2 shadow-sm" type="button" data-bs-toggle="dropdown">
                            <img src="<?= htmlspecialchars($foto_user); ?>" alt="Foto Profile" class="user-avatar-nav">
                            <span><?= htmlspecialchars($user_data['nama']); ?></span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end border-0 shadow">
                            <li><a class="dropdown-item" href="profil.php"><i class="fa-solid fa-user-pen me-2"></i>Pengaturan Profil</a></li>
                            <li><a class="dropdown-item" href="history.php"><i class="fa-solid fa-clock-rotate-left me-2"></i>Riwayat Pesanan</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="mb-4">
            <h2 class="font-heading fw-bold text-dark"><i class="fa-solid fa-ticket text-warning me-2"></i>Tiket War & Status Pengiriman Anda</h2>
            <p class="text-muted small">Kelola tiket eksklusif yang berhasil Anda menangkan dan lihat status pembayaran serta pengirimannya.</p>
        </div>

        <div class="row g-4">
            <?php if ($query_tiket && mysqli_num_rows($query_tiket) > 0): ?>
                <?php while ($t = mysqli_fetch_assoc($query_tiket)): ?>
                    <?php
                    $judul_buku   = $t['judul'] ?? 'Buku Eksklusif War';
                    $penulis_buku = $t['penulis'] ?? 'Penulis Spesial';
                    $cover_db     = $t['cover_buku'] ?? '';
                    $cover_path   = getWarCover($cover_db);

                    $kode_tiket = "SKYBS-WAR-" . str_pad($t['id_transaksi'], 5, "0", STR_PAD_LEFT);

                    $harga = (int) ($t['total_harga'] ?? $t['harga_buku'] ?? 0);
                    if ($harga < 1000 && $harga > 0) {
                        $harga = $harga * 1000;
                    }

                    $sudah_bayar  = isSudahBayar($t);
                    $status_tiket = getStatusTiket($t);
                    ?>

                    <div class="col-md-6 col-lg-4">
                        <div class="ticket-card">
                            <div class="ticket-header d-flex justify-content-between align-items-center">
                                <span class="fw-bold small text-warning"><i class="fa-solid fa-bolt me-1"></i> VIP WAR TICKET</span>
                                <span class="badge bg-light text-dark fw-bold"><?= htmlspecialchars($kode_tiket); ?></span>
                            </div>

                            <div class="ticket-body">
                                <div class="row g-3 align-items-center">
                                    <div class="col-4">
                                        <img src="<?= htmlspecialchars($cover_path); ?>" alt="Cover Buku" class="cover-war" onerror="this.onerror=null; this.src='https://via.placeholder.com/260x320?text=No+Cover';">
                                    </div>
                                    <div class="col-8">
                                        <h6 class="fw-bold text-dark mb-1 text-truncate" title="<?= htmlspecialchars($judul_buku); ?>"><?= htmlspecialchars($judul_buku); ?></h6>
                                        <small class="text-muted d-block mb-1"><i class="fa-solid fa-pen-nib me-1"></i><?= htmlspecialchars($penulis_buku); ?></small>

                                        <?php if ($sudah_bayar): ?>
                                            <span class="status-badge status-paid"><i class="fa-solid fa-circle-check"></i> Sudah Dibayar</span>
                                        <?php elseif ($status_tiket === 'Menunggu Verifikasi'): ?>
                                            <span class="status-badge status-warning"><i class="fa-solid fa-clock"></i> Menunggu Verifikasi</span>
                                        <?php else: ?>
                                            <span class="status-badge status-warning"><i class="fa-solid fa-box-open"></i> Belum Dibayar</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="ticket-footer">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <small class="text-muted"><i class="fa-regular fa-calendar me-1"></i><?= date("d M Y, H:i", strtotime($t['tanggal'] ?? 'now')); ?></small>
                                    <span class="fw-bold text-danger">Rp <?= number_format($harga, 0, ',', '.'); ?></span>
                                </div>

                                <?php if ($sudah_bayar): ?>
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="status-badge status-paid w-100 justify-content-center py-2">
                                            <i class="fa-solid fa-check-circle"></i> Lunas (Sudah Dibayar)
                                        </span>
                                    </div>
                                <?php elseif (!empty($t['id_pesanan_terkait'])): ?>
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="status-badge status-warning w-100 justify-content-center py-2">
                                            <i class="fa-solid fa-hourglass-half"></i> Menunggu Verifikasi Admin
                                        </span>
                                    </div>
                                <?php else: ?>
                                    <a href="checkout_war.php?id=<?= (int) $t['id_transaksi']; ?>" class="btn btn-payment btn-sm rounded-pill fw-semibold px-3 w-100 text-center">
                                        <i class="fa-solid fa-credit-card me-1"></i> Lanjut Pembayaran
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 py-5 text-center text-muted">
                    <i class="fa-solid fa-ticket-simple fs-1 mb-3 opacity-50 d-block"></i>
                    <h5 class="fw-bold">Belum Ada Tiket War Buku</h5>
                    <p class="small">Anda belum memenangkan tiket War Buku eksklusif. Ikuti sesi War Tiket di halaman beranda untuk mendapatkannya!</p>
                    <a href="index.php" class="btn btn-dark rounded-pill px-4 mt-2">Cari Buku War</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>