<?php
session_start();
include "database.php";

// 1. Cek Login User
if (!isset($_SESSION['id_user'])) {
    echo "<script>
        alert('Silakan login terlebih dahulu!');
        window.location='login.php';
    </script>";
    exit;
}

$id_user = (int)$_SESSION['id_user'];

// 2. Ambil Daftar Pesanan User (Group Header)
$stmt_pesanan = mysqli_prepare($conn, "
    SELECT * FROM pesanan 
    WHERE id_user = ? 
    ORDER BY id_pesanan DESC
");
mysqli_stmt_bind_param($stmt_pesanan, "i", $id_user);
mysqli_stmt_execute($stmt_pesanan);
$res_pesanan = mysqli_stmt_get_result($stmt_pesanan);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pesanan | SKY Bookstore</title>

    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&family=Courier+Prime:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --shadow-md: 0 10px 25px rgba(78, 34, 15, 0.08);
            --radius-lg: 20px;
        }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }

        h1, h2, h3, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        /* NAVBAR */
        .navbar-custom {
            background: var(--brand-dark-brown);
            padding: 14px 0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }

        .navbar-brand {
            color: #FFFFFF !important;
            font-weight: 800;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .navbar-brand img {
            max-height: 40px;
            width: auto;
            object-fit: contain;
            border-radius: 6px;
        }

        /* CARDS & BADGES */
        .card-order {
            background: #FFFFFF;
            border: 1px solid rgba(78, 34, 15, 0.08);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
            max-width: 800px;
            margin: 0 auto;
        }

        .book-thumb {
            width: 55px;
            height: 75px;
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(78, 34, 15, 0.12);
        }

        .badge-status {
            padding: 6px 14px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 700;
            display: inline-block;
        }

        .btn-sage {
            background: var(--brand-warm-brown);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 10px 24px;
            font-weight: 700;
            transition: all 0.3s ease;
        }

        .btn-sage:hover {
            background: var(--brand-dark-brown);
            color: white;
        }

        footer {
            background: var(--brand-dark-brown);
            color: var(--brand-cream-bg);
            padding: 40px 0 25px;
            margin-top: 80px;
            border-top: 4px solid var(--brand-warm-brown);
        }

        /* ==========================================================
           PENGATURAN KHUSUS CETAK PDF / PRINT (1 HALAMAN & DI TENGAH)
           ========================================================== */
        @page {
            size: 80mm 200mm; /* Menentukan ukuran kertas rol kasir/thermal agar tidak meluas ke banyak halaman */
            margin: 0;
        }

        @media print {
            body, html {
                background: white !important;
                margin: 0 !important;
                padding: 0 !important;
                width: 100% !important;
                height: 100% !important;
                overflow: hidden !important;
            }

            body * {
                visibility: hidden !important;
            }

            /* Hanya tampilkan card pesanan yang aktif dicetak */
            .receipt-card.is-printing, 
            .receipt-card.is-printing * {
                visibility: visible !important;
            }

            .receipt-card.is-printing {
                position: fixed !important;
                left: 50% !important;
                top: 10px !important;
                transform: translateX(-50%) !important;
                width: 72mm !important; /* Lebar pas struk kasir */
                max-height: 95vh !important;
                margin: 0 !important;
                padding: 8px !important;
                background: #FFFFFF !important;
                box-shadow: none !important;
                border: none !important;
                font-family: 'Courier Prime', monospace !important;
                font-size: 11px !important;
                color: #000000 !important;
                overflow: hidden !important;
            }

            .receipt-card.is-printing .d-none-print {
                display: none !important;
            }
            
            .receipt-card.is-printing .d-block-print {
                display: block !important;
            }

            .receipt-card.is-printing table {
                font-size: 11px !important;
            }

            .no-print {
                display: none !important;
            }
        }
    </style>
</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-custom sticky-top no-print">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="assets/img/logo.png" alt="SKYBS Logo" onerror="this.style.display='none'; document.getElementById('fallback-icon').style.display='inline-block';">
                <i id="fallback-icon" class="fa-solid fa-book-open text-warning me-1" style="display:none;"></i>
                <span>SKY Bookstore</span>
            </a>
            <a href="index.php" class="btn btn-sm btn-outline-light rounded-pill px-3">
                <i class="fa-solid fa-house me-1"></i> Home
            </a>
        </div>
    </nav>

    <!-- CONTENT CONTAINER -->
    <div class="container py-5">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 no-print">
            <div>
                <h2 class="font-heading fw-bold mb-1" style="color: var(--brand-dark-brown);">
                    <i class="fa-solid fa-clock-rotate-left me-2" style="color: var(--brand-warm-brown);"></i>Riwayat Pesanan Saya
                </h2>
                <p class="text-muted mb-0">Lacak status transaksi dan cetak struk pembelian buku Anda di SKYBS</p>
            </div>
            <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4 btn-sm fw-semibold">
                <i class="fa-solid fa-arrow-left me-2"></i>Kembali Belanja
            </a>
        </div>

        <?php if (mysqli_num_rows($res_pesanan) > 0): ?>
            <div class="d-flex flex-column gap-4">
                <?php while ($p = mysqli_fetch_assoc($res_pesanan)): 
                    $id_pesanan = $p['id_pesanan'];
                    $status = trim($p['status']);
                    $metode_pembayaran = $p['metode_pembayaran'] ?? '-';
                    
                    // Deteksi kondisi refund: Status Batal / Refund / Dikembalikan dengan pembayaran non-COD
                    $status_lower = strtolower($status);
                    $is_refund = (($status_lower == 'batal' || $status_lower == 'refund' || $status_lower == 'dikembalikan') && strtolower($metode_pembayaran) !== 'cod');

                    // Penentuan Style Badge Status Pesanan
                    $badgeStyle = "background: #EAE3D2; color: #4A3E3D;";
                    if ($status_lower == "menunggu konfirmasi") {
                        $badgeStyle = "background: #FFF3CD; color: #856404; border: 1px solid #FFEBAA;";
                    } elseif ($status_lower == "diproses") {
                        $badgeStyle = "background: #CFF4FC; color: #055160; border: 1px solid #B6EFFB;";
                    } elseif ($status_lower == "dikirim") {
                        $badgeStyle = "background: #E0CFFC; color: #3D0A91; border: 1px solid #D0BFFF;";
                    } elseif ($status_lower == "selesai") {
                        $badgeStyle = "background: #D1E7DD; color: #0F5132; border: 1px solid #BADBCE;";
                    } elseif ($status_lower == "batal" || $status_lower == "refund" || $status_lower == "dikembalikan") {
                        $badgeStyle = "background: #F8D7DA; color: #842029; border: 1px solid #F5C2C7;";
                    }

                    // Query Detail Buku
                    $stmt_detail = mysqli_prepare($conn, "
                        SELECT detail_pesanan.*, buku.judul, buku.cover 
                        FROM detail_pesanan 
                        JOIN buku ON detail_pesanan.id_buku = buku.id_buku 
                        WHERE detail_pesanan.id_pesanan = ?
                    ");
                    mysqli_stmt_bind_param($stmt_detail, "i", $id_pesanan);
                    mysqli_stmt_execute($stmt_detail);
                    $res_detail = mysqli_stmt_get_result($stmt_detail);
                ?>

                <!-- CARD PER PESANAN DENGAN ID UNIK -->
                <div class="card-order p-4 receipt-card" id="receipt-<?= $id_pesanan; ?>">
                    
                    <!-- KOP / HEADER STRUK KHUSUS PRINT (Gaya Struk Kasir) -->
                    <div class="text-center pb-2 border-bottom mb-2 d-none d-block-print" style="display:none;">
                        <h4 class="fw-bold mb-1" style="font-family: 'Courier Prime', monospace; font-size: 14px;">SKYBS BOOKSTORE</h4>
                        <p class="small mb-0" style="font-size: 10px;">Jl. Raya Pendidikan No. 45, Jakarta Pusat</p>
                        <p class="small mb-1" style="font-size: 10px;">Telp : 085891403949</p>
                        <div style="border-top: 1px dashed #000; margin-top: 4px; padding-top: 4px;">
                            <span style="font-size: 10px;"><?= isset($p['tanggal']) ? date("d-m-Y  H:i", strtotime($p['tanggal'])) : '-'; ?></span><br>
                            <span style="font-size: 10px;">No: <?= htmlspecialchars($p['kode_pesanan'] ?? '#'.$p['id_pesanan']); ?></span>
                        </div>
                    </div>

                    <!-- HEADER NORMAL (Web View) -->
                    <div class="d-flex flex-wrap justify-content-between align-items-center border-bottom pb-3 mb-3 gap-2 d-none-print">
                        <div>
                            <span class="fw-bold me-2 fs-6" style="color: var(--brand-dark-brown);">
                                <i class="fa-solid fa-receipt me-1 text-muted"></i>
                                <?= htmlspecialchars($p['kode_pesanan'] ?? '#'.$p['id_pesanan']); ?>
                            </span>
                            <small class="text-muted border-start ps-2">
                                <?= isset($p['tanggal']) ? date("d M Y, H:i", strtotime($p['tanggal'])) : '-'; ?>
                            </small>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge-status" style="<?= $badgeStyle; ?>">
                                <?= htmlspecialchars($status); ?>
                            </span>
                            <span class="badge border rounded-pill px-3 py-1 small" style="background: var(--brand-cream-bg); color: var(--brand-dark-brown);">
                                Pembayaran: <strong><?= htmlspecialchars($metode_pembayaran); ?></strong>
                            </span>
                        </div>
                    </div>

                    <!-- TABEL BUKU -->
                    <div class="table-responsive">
                        <table class="table align-middle mb-0 w-100">
                            <thead class="d-none d-block-print" style="display:none; border-bottom: 1px dashed #000;">
                                <tr>
                                    <th style="font-size: 10px; padding: 2px;">Item</th>
                                    <th class="text-end" style="font-size: 10px; padding: 2px;">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($d = mysqli_fetch_assoc($res_detail)): 
                                    $cover_buku = "img/buku/" . ltrim($d['cover'] ?? '', '/');
                                    $cover_war  = "img/war/" . ltrim($d['cover'] ?? '', '/');

                                    if (!empty($d['cover']) && file_exists($cover_buku)) {
                                        $img_src = $cover_buku;
                                    } elseif (!empty($d['cover']) && file_exists($cover_war)) {
                                        $img_src = $cover_war;
                                    } else {
                                        $img_src = "https://via.placeholder.com/55x75?text=No+Cover";
                                    }
                                ?>
                                <tr>
                                    <td width="50" class="d-none-print">
                                        <img src="<?= $img_src; ?>" alt="Cover" class="book-thumb">
                                    </td>
                                    <td>
                                        <h6 class="fw-bold mb-1" style="color: var(--brand-dark-brown); font-size: 12px;"><?= htmlspecialchars($d['judul']); ?></h6>
                                        <small class="text-muted" style="font-size: 11px;">
                                            <?= $d['jumlah']; ?> x Rp <?= number_format($d['harga'], 0, ",", "."); ?>
                                        </small>
                                    </td>
                                    <td class="text-end fw-bold" style="color: var(--brand-warm-brown); font-size: 12px;">
                                        Rp <?= number_format($d['subtotal'], 0, ",", "."); ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- INFO TAMBAHAN JIKA REFUND -->
                    <?php if ($is_refund): ?>
                        <div class="alert alert-warning mt-3 mb-2 py-2 px-3 small d-none-print" style="font-size: 12px; background-color: #fff3cd; border-color: #ffeeba; color: #856404; border-radius: 10px;">
                            <div class="d-flex align-items-center gap-2">
                                <i class="fa-solid fa-triangle-exclamation fs-5"></i>
                                <div>
                                    <strong>Informasi Pengembalian Dana (Refund):</strong><br>
                                    Pesanan berstatus pengembalian. Dana Anda sebesar <strong>Rp <?= number_format($p['total_harga'] ?? $p['total'] ?? 0, 0, ",", "."); ?></strong> 
                                    sedang dalam proses pengembalian oleh Admin ke metode pembayaran awal (<strong><?= htmlspecialchars($metode_pembayaran); ?></strong>). 
                                    Estimasi waktu 1x24 jam.
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- FOOTER CARD / TOTAL -->
                    <div class="border-top pt-2 mt-2">
                        <div class="d-none d-block-print mb-2" style="display:none; border-top: 1px dashed #000; padding-top: 4px;">
                            <div class="d-flex justify-content-between fw-bold" style="font-size: 11px;">
                                <span>TOTAL:</span>
                                <span>Rp <?= number_format($p['total_harga'] ?? $p['total'] ?? 0, 0, ",", "."); ?></span>
                            </div>
                            <div class="text-center mt-2" style="font-size: 10px;">
                                <p class="mb-0">Terima Kasih Telah Berbelanja</p>
                                <p class="mb-0">Silakan Datang Kembali</p>
                            </div>
                        </div>

                        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-2 d-none-print">
                            <div class="small text-muted">
                                <i class="fa-solid fa-location-dot me-1" style="color: var(--brand-warm-brown);"></i> Alamat Pengiriman: 
                                <strong style="color: var(--brand-dark-brown);"><?= htmlspecialchars($p['alamat_pengiriman'] ?? '-'); ?></strong>
                            </div>
                            <div class="text-sm-end">
                                <span class="small text-muted me-2">Total Belanja:</span>
                                <span class="fs-5 fw-extrabold" style="color: var(--brand-warm-brown);">
                                    Rp <?= number_format($p['total_harga'] ?? $p['total'] ?? 0, 0, ",", "."); ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- TOMBOL CETAK ATAU TANDA REFUND TIDAK BISA CETAK STRUK -->
                    <div class="mt-3 pt-3 border-top d-flex justify-content-end gap-2 no-print">
                        <?php if ($is_refund): ?>
                            <span class="badge bg-danger text-white px-3 py-2 rounded-pill d-flex align-items-center gap-1" style="font-size: 12px; font-weight: 600;">
                                <i class="fa-solid fa-ban me-1"></i> Pengembalian Tidak Dilaksanakan / Refund (Struk Tidak Dapat Dicetak)
                            </span>
                        <?php else: ?>
                            <button onclick="cetakStruk(<?= $id_pesanan; ?>)" class="btn btn-sm btn-dark rounded-pill px-3 fw-bold" style="background: var(--brand-dark-brown);">
                                <i class="fa-solid fa-print me-1"></i> Cetak / Simpan PDF Struk Ini
                            </button>
                        <?php endif; ?>
                    </div>

                </div>

                <?php endwhile; ?>
            </div>

        <?php else: ?>
            <!-- TAMPILAN JIKA BELUM ADA PESANAN -->
            <div class="card-order p-5 text-center my-4">
                <i class="fa-solid fa-box-open fs-1 mb-3 text-muted opacity-50 d-block"></i>
                <h5 class="font-heading fw-bold mb-1" style="color: var(--brand-dark-brown);">Belum Ada Riwayat Pesanan</h5>
                <p class="text-muted small mb-4">Anda belum melakukan transaksi pembelian buku apapun di SKYBS BookStore.</p>
                <div>
                    <a href="index.php" class="btn btn-sage">
                        <i class="fa-solid fa-cart-plus me-2"></i>Mulai Belanja Sekarang
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- FOOTER -->
    <footer class="text-center no-print">
        <div class="container">
            <h5 class="fw-bold mb-2">SKY Bookstore</h5>
            <p class="small mb-0 opacity-75">&copy; <?= date("Y"); ?> SKY Bookstore. All Rights Reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap JS & Script Khusus Print -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function cetakStruk(idPesanan) {
            const receiptElement = document.getElementById('receipt-' + idPesanan);
            if (!receiptElement) return;

            // Beri tanda card mana yang akan dicetak
            receiptElement.classList.add('is-printing');

            // Cetak halaman
            window.print();

            // Lepaskan tanda setelah selesai
            receiptElement.classList.remove('is-printing');
        }
    </script>
</body>

</html>