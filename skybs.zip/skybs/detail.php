<?php
session_start();
include "database.php";

// 1. Validasi ID Buku
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = (int)$_GET['id'];

// 2. Ambil Detail Data Buku & Kategori (Prepared Statement)
$stmt = mysqli_prepare($conn, "
    SELECT buku.*, kategori.nama_kategori 
    FROM buku 
    LEFT JOIN kategori ON buku.id_kategori = kategori.id_kategori 
    WHERE buku.id_buku = ?
");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$data) {
    echo "<script>
        alert('Buku tidak ditemukan!');
        window.location='index.php';
    </script>";
    exit;
}

// 3. Proses Tambah ke Keranjang dengan Jumlah Kuantitas Dinamis
if (isset($_POST['tambah_keranjang'])) {
    if (!isset($_SESSION['id_user'])) {
        echo "<script>
            alert('Silakan login terlebih dahulu untuk menambah buku ke keranjang!');
            window.location='login.php';
        </script>";
        exit;
    }

    // Validasi tambahan: Blokir proses jika stok 0 atau kurang
    if ($data['stok'] <= 0) {
        echo "<script>
            alert('Maaf, stok buku ini habis dan tidak bisa dibeli.');
            window.location='detail.php?id=$id';
        </script>";
        exit;
    }

    $id_user = (int)$_SESSION['id_user'];
    $jumlah = (int)$_POST['jumlah'];

    if ($jumlah < 1) {
        $jumlah = 1;
    }

    // Validasi Stok
    if ($jumlah > $data['stok']) {
        echo "<script>
            alert('Jumlah melebihi stok yang tersedia (Stok: {$data['stok']})');
        </script>";
    } else {
        // Cek Apakah Buku Sudah Ada di Keranjang User
        $stmt_check = mysqli_prepare($conn, "SELECT id_keranjang, jumlah FROM keranjang WHERE id_user = ? AND id_buku = ?");
        mysqli_stmt_bind_param($stmt_check, "ii", $id_user, $id);
        mysqli_stmt_execute($stmt_check);
        $res_check = mysqli_stmt_get_result($stmt_check);

        if ($exist = mysqli_fetch_assoc($res_check)) {
            // Jika sudah ada, TAMBAHKAN jumlah lama dengan jumlah baru
            $jumlah_baru = $exist['jumlah'] + $jumlah;
            $stmt_up = mysqli_prepare($conn, "UPDATE keranjang SET jumlah = ? WHERE id_keranjang = ?");
            mysqli_stmt_bind_param($stmt_up, "ii", $jumlah_baru, $exist['id_keranjang']);
            mysqli_stmt_execute($stmt_up);
        } else {
            // Jika belum ada, SISIPKAN baris baru
            $stmt_in = mysqli_prepare($conn, "INSERT INTO keranjang (id_user, id_buku, jumlah) VALUES (?, ?, ?)");
            mysqli_stmt_bind_param($stmt_in, "iii", $id_user, $id, $jumlah);
            mysqli_stmt_execute($stmt_in);
        }

        echo "<script>
            alert('Buku berhasil ditambahkan ke keranjang!');
            window.location='keranjang.php';
        </script>";
        exit;
    }
}

// 4. Ambil Rekomendasi Buku Terkait
$stmt_related = mysqli_prepare($conn, "
    SELECT * FROM buku 
    WHERE id_kategori = ? AND id_buku != ? 
    ORDER BY RAND() LIMIT 4
");
mysqli_stmt_bind_param($stmt_related, "ii", $data['id_kategori'], $id);
mysqli_stmt_execute($stmt_related);
$related = mysqli_stmt_get_result($stmt_related);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($data['judul']); ?> | SKY Bookstore</title>

    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --shadow-md: 0 10px 25px rgba(78, 34, 15, 0.08);
            --radius-lg: 20px;
        }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }

        h1, h2, h3, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        /* NAVBAR */
        .navbar-custom {
            background: var(--brand-dark-brown);
            padding: 14px 0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }

        .navbar-brand {
            color: #FFFFFF !important;
            font-weight: 800;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .navbar-brand img {
            max-height: 40px;
            width: auto;
            object-fit: contain;
            border-radius: 6px;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.85) !important;
            margin: 0 10px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.2s ease;
        }

        .nav-link:hover {
            color: #FFFFFF !important;
        }

        /* DETAIL CARD & COVER */
        .card-custom {
            background: #FFFFFF;
            border: 1px solid rgba(78, 34, 15, 0.08);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
        }

        .cover-img {
            width: 100%;
            max-height: 480px;
            object-fit: cover;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(78, 34, 15, 0.15);
        }

        .price-tag {
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--brand-warm-brown);
        }

        .rating-stars {
            color: #FFB800;
            font-size: 1.1rem;
        }

        /* BUTTONS & QUANTITY SELECTOR */
        .btn-sage {
            background: var(--brand-warm-brown);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 12px 28px;
            font-weight: 700;
            transition: all 0.3s ease;
        }

        .btn-sage:hover {
            background: var(--brand-dark-brown);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(78, 34, 15, 0.2);
        }

        .qty-input-group {
            width: 140px;
            background: var(--brand-cream-bg);
            border: 1px solid rgba(78, 34, 15, 0.15);
            border-radius: 50px;
            overflow: hidden;
        }

        .qty-btn {
            background: transparent;
            border: none;
            color: var(--brand-dark-brown);
            font-weight: bold;
            padding: 8px 14px;
            transition: background 0.2s ease;
        }

        .qty-btn:hover {
            background: rgba(78, 34, 15, 0.08);
        }

        .qty-field {
            background: transparent;
            border: none;
            text-align: center;
            font-weight: 700;
            width: 50px;
            color: var(--brand-dark-brown);
        }

        .qty-field:focus {
            outline: none;
        }

        .badge-kategori {
            background: rgba(176, 186, 153, 0.3);
            color: var(--brand-dark-brown);
            border: 1px solid var(--brand-sage-green);
        }

        footer {
            background: var(--brand-dark-brown);
            color: var(--brand-cream-bg);
            padding: 40px 0 25px;
            margin-top: 80px;
            border-top: 4px solid var(--brand-warm-brown);
        }
    </style>
</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-custom sticky-top">
        <div class="container">
            <!-- LOGO KIRI -->
            <a class="navbar-brand" href="index.php">
                <img src="assets/img/logo.png" alt="SKYBS Logo" onerror="this.style.display='none'; document.getElementById('fallback-icon').style.display='inline-block';">
                <i id="fallback-icon" class="fa-solid fa-book-open text-warning me-1" style="display:none;"></i>
                <span>SKYBS BookStore</span>
            </a>
            <button class="navbar-toggler border-0 text-white shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
                <i class="fa-solid fa-bars-staggered"></i>
            </button>

            <div class="collapse navbar-collapse" id="menu">
                <ul class="navbar-nav ms-auto align-items-lg-center">
                    <li class="nav-item"><a class="nav-link" href="index.php"><i class="fa-solid fa-house me-1"></i> Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="wishlist.php"><i class="fa-regular fa-heart me-1"></i> Wishlist</a></li>
                    <li class="nav-item"><a class="nav-link" href="keranjang.php"><i class="fa-solid fa-cart-shopping me-1"></i> Keranjang</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- DETAIL CONTENT -->
    <div class="container py-5">
        <div class="card-custom p-4 p-md-5">
            <div class="row g-5 align-items-center">

                <!-- BOOK COVER IMAGE -->
                <div class="col-md-5 text-center">
                    <?php 
                    $cover_path = "img/buku/" . $data['cover'];
                    if (!empty($data['cover']) && file_exists($cover_path)) {
                        $img_src = $cover_path;
                    } else {
                        $img_src = "https://via.placeholder.com/350x500?text=No+Cover";
                    }
                    ?>
                    <img src="<?= $img_src; ?>" alt="<?= htmlspecialchars($data['judul']); ?>" class="cover-img">
                </div>

                <!-- BOOK DETAILS & ACTION FORM -->
                <div class="col-md-7">
                    <?php if (!empty($data['badge'])): ?>
                        <span class="badge badge-kategori px-3 py-2 rounded-pill fw-bold mb-2">
                            <?= htmlspecialchars($data['badge']); ?>
                        </span>
                    <?php endif; ?>

                    <h1 class="font-heading fw-bold mb-2" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($data['judul']); ?></h1>
                    <h5 class="text-muted fw-semibold mb-3"><i class="fa-solid fa-pen-nib me-2" style="color: var(--brand-warm-brown);"></i>Penulis: <?= htmlspecialchars($data['penulis'] ?? 'Anonim'); ?></h5>

                    <div class="d-flex align-items-center gap-3 mb-3">
                        <div class="rating-stars">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star-half-stroke"></i>
                            <span class="fs-6 ms-1 fw-bold" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($data['rating'] ?? '5.0'); ?></span>
                        </div>
                        <span class="text-muted">|</span>
                        <span class="badge badge-kategori rounded-pill px-3 py-2">
                            Kategori: <strong><?= htmlspecialchars($data['nama_kategori'] ?? 'Umum'); ?></strong>
                        </span>
                    </div>

                    <div class="price-tag mb-3">
                        Rp <?= number_format($data['harga'], 0, ",", "."); ?>
                    </div>

                    <div class="mb-4">
                        <strong class="me-2" style="color: var(--brand-dark-brown);">Ketersediaan Stok:</strong>
                        <?php if ($data['stok'] > 0): ?>
                            <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2 rounded-pill fw-semibold">
                                <i class="fa-solid fa-check me-1"></i>Tersedia (<?= $data['stok']; ?> eksemplar)
                            </span>
                        <?php else: ?>
                            <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-2 rounded-pill fw-semibold">
                                <i class="fa-solid fa-xmark me-1"></i>Stok Habis / Tidak Bisa Dibeli
                            </span>
                        <?php endif; ?>
                    </div>

                    <hr class="opacity-25">

                    <h5 class="fw-bold mb-2" style="color: var(--brand-dark-brown);">Sinopsis / Deskripsi</h5>
                    <p class="text-secondary mb-4" style="text-align: justify; line-height: 1.8; font-size: 15px;">
                        <?= nl2br(htmlspecialchars($data['deskripsi'] ?? 'Belum ada deskripsi khusus untuk buku ini.')); ?>
                    </p>

                    <hr class="opacity-25">

                    <!-- FORM QUANTITY & SUBMIT -->
                    <form method="POST" class="mt-4">
                        <div class="d-flex flex-wrap align-items-center gap-3">
                            <div>
                                <label class="fw-bold small text-muted d-block mb-1">Jumlah Pembelian:</label>
                                <div class="d-flex align-items-center qty-input-group">
                                    <button type="button" class="qty-btn" onclick="decreaseQty()"><i class="fa-solid fa-minus"></i></button>
                                    <input type="number" id="qtyInput" name="jumlah" class="qty-field" value="<?= ($data['stok'] > 0) ? 1 : 0; ?>" min="<?= ($data['stok'] > 0) ? 1 : 0; ?>" max="<?= $data['stok']; ?>" <?= ($data['stok'] <= 0) ? 'disabled' : ''; ?> readonly required>
                                    <button type="button" class="qty-btn" onclick="increaseQty(<?= $data['stok']; ?>)"><i class="fa-solid fa-plus"></i></button>
                                </div>
                            </div>

                            <div class="d-flex gap-2 align-self-end mt-2 mt-sm-0">
                                <?php if ($data['stok'] > 0): ?>
                                    <button type="submit" name="tambah_keranjang" class="btn btn-sage d-flex align-items-center gap-2">
                                        <i class="fa-solid fa-cart-plus"></i>
                                        <span>Tambah ke Keranjang</span>
                                    </button>
                                <?php else: ?>
                                    <button type="button" class="btn btn-secondary rounded-pill px-4 fw-bold disabled" style="cursor: not-allowed;">
                                        <i class="fa-solid fa-ban me-1"></i> Stok Habis / Tidak Bisa Dibeli
                                    </button>
                                <?php endif; ?>

                                <a href="wishlist.php?id=<?= $data['id_buku']; ?>" class="btn btn-outline-danger rounded-circle p-3 d-flex align-items-center justify-content-center" style="width:48px; height:48px;" title="Tambah Wishlist">
                                    <i class="fa-regular fa-heart fs-5"></i>
                                </a>

                                <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4 d-flex align-items-center">
                                    <i class="fa-solid fa-arrow-left me-2"></i> Kembali
                                </a>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>

        <!-- REKOMENDASI BUKU TERKAIT -->
        <?php if (mysqli_num_rows($related) > 0): ?>
            <div class="mt-5">
                <h4 class="font-heading fw-bold mb-4" style="color: var(--brand-dark-brown);">
                    <i class="fa-solid fa-layer-group me-2" style="color: var(--brand-warm-brown);"></i>Buku Terkait Lainnya
                </h4>
                <div class="row g-4">
                    <?php while ($r = mysqli_fetch_assoc($related)): ?>
                        <div class="col-6 col-md-3">
                            <div class="card-custom h-100 p-3 d-flex flex-column">
                                <?php 
                                $rel_cover = "img/buku/" . $r['cover'];
                                if (!empty($r['cover']) && file_exists($rel_cover)) {
                                    $rel_src = $rel_cover;
                                } else {
                                    $rel_src = "https://via.placeholder.com/200x280?text=No+Cover";
                                }
                                ?>
                                <img src="<?= $rel_src; ?>" class="rounded-3 mb-3" style="height: 220px; object-fit: cover;" alt="Cover">
                                <div class="d-flex flex-column flex-grow-1">
                                    <h6 class="fw-bold text-truncate mb-1" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($r['judul']); ?></h6>
                                    <small class="text-muted mb-2"><i class="fa-solid fa-pen-nib me-1"></i><?= htmlspecialchars($r['penulis'] ?? '-'); ?></small>
                                    <div class="fw-bold mb-3 mt-auto" style="color: var(--brand-warm-brown);">
                                        Rp <?= number_format($r['harga'], 0, ",", "."); ?>
                                    </div>
                                    <a href="detail.php?id=<?= $r['id_buku']; ?>" class="btn btn-sm btn-outline-secondary rounded-pill w-100 fw-bold">
                                        Lihat Detail
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- FOOTER -->
    <footer class="text-center">
        <div class="container">
            <h5 class="fw-bold mb-2">SKY Bookstore</h5>
            <p class="small mb-0 opacity-75">&copy; <?= date("Y"); ?> SKY Bookstore. All Rights Reserved.</p>
        </div>
    </footer>

    <!-- SCRIPT QUANTITY CONTROL -->
    <script>
        function increaseQty(maxStok) {
            let input = document.getElementById("qtyInput");
            let val = parseInt(input.value);
            if (val < maxStok) {
                input.value = val + 1;
            }
        }

        function decreaseQty() {
            let input = document.getElementById("qtyInput");
            let val = parseInt(input.value);
            if (val > 1) {
                input.value = val - 1;
            }
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>