<?php
session_start();
include "database.php";

if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

$id_user = (int)$_SESSION['id_user'];

// Ambil data user saat ini
$stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE id_user = ?");
mysqli_stmt_bind_param($stmt, "i", $id_user);
mysqli_stmt_execute($stmt);
$user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (isset($_POST['update_profil'])) {
    $nama   = trim($_POST['nama']);
    $no_hp  = trim($_POST['no_hp']);
    $alamat = trim($_POST['alamat']);
    $foto_lama = $user['foto'];
    $foto_baru = $foto_lama;

    // Cek jika user mengunggah foto profil baru
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($ext, $allowed)) {
            $nama_foto = "user_" . $id_user . "_" . time() . "." . $ext;
            $target = "img/user/" . $nama_foto;

            if (!is_dir("img/user/")) {
                mkdir("img/user/", 0777, true);
            }

            if (move_uploaded_file($_FILES['foto']['tmp_name'], $target)) {
                // Hapus foto lama jika bukan default
                if (!empty($foto_lama) && $foto_lama !== 'default.png' && file_exists("img/user/" . $foto_lama)) {
                    unlink("img/user/" . $foto_lama);
                }
                $foto_baru = $nama_foto;
            }
        }
    }

    // Update data di database
    $stmt_upd = mysqli_prepare($conn, "UPDATE users SET nama = ?, no_hp = ?, alamat = ?, foto = ? WHERE id_user = ?");
    mysqli_stmt_bind_param($stmt_upd, "ssssi", $nama, $no_hp, $alamat, $foto_baru, $id_user);

    if (mysqli_stmt_execute($stmt_upd)) {
        $_SESSION['nama'] = $nama; // Update session
        echo "<script>
            alert('Profil berhasil diperbarui!');
            window.location='edit_profil.php';
        </script>";
        exit;
    } else {
        echo "<script>alert('Gagal memperbarui profil.');</script>";
    }
}

// Cek foto profil saat ini
$foto_path = "img/user/" . $user['foto'];
$img_user = (!empty($user['foto']) && file_exists($foto_path)) ? $foto_path : "https://via.placeholder.com/150?text=User";
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil Saya | SKYBS BookStore</title>

    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --shadow-md: 0 10px 25px rgba(78, 34, 15, 0.08);
            --radius-lg: 20px;
        }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }

        h1, h2, h3, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        /* NAVBAR */
        .navbar-custom {
            background: var(--brand-dark-brown);
            padding: 14px 0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }

        .navbar-brand {
            color: #FFFFFF !important;
            font-weight: 800;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .navbar-brand img {
            max-height: 40px;
            width: auto;
            object-fit: contain;
            border-radius: 6px;
        }

        /* CARD & FORM STYLING */
        .card-custom {
            background: #FFFFFF;
            border: 1px solid rgba(78, 34, 15, 0.08);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
        }

        .profile-avatar {
            width: 130px;
            height: 130px;
            object-fit: cover;
            border-radius: 50%;
            border: 4px solid var(--brand-warm-brown);
            box-shadow: 0 6px 15px rgba(78, 34, 15, 0.15);
        }

        .form-control-custom {
            background: var(--brand-cream-bg);
            border: 1px solid rgba(78, 34, 15, 0.15);
            border-radius: 12px;
            padding: 10px 16px;
            font-size: 14px;
            color: var(--brand-dark-brown);
        }

        .form-control-custom:focus {
            background: #FFFFFF;
            border-color: var(--brand-warm-brown);
            box-shadow: 0 0 0 4px rgba(157, 102, 56, 0.15);
            color: var(--brand-dark-brown);
        }

        .btn-sage {
            background: var(--brand-warm-brown);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 10px 24px;
            font-weight: 700;
            transition: all 0.3s;
        }

        .btn-sage:hover {
            background: var(--brand-dark-brown);
            color: white;
        }

        footer {
            background: var(--brand-dark-brown);
            color: var(--brand-cream-bg);
            padding: 40px 0 25px;
            margin-top: 80px;
            border-top: 4px solid var(--brand-warm-brown);
        }
    </style>
</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-custom sticky-top mb-4">
        <div class="container">
            <!-- LOGO KIRI -->
            <a class="navbar-brand" href="index.php">
                <img src="assets/img/logo.png" alt="SKYBS Logo" onerror="this.style.display='none'; document.getElementById('fallback-icon').style.display='inline-block';">
                <i id="fallback-icon" class="fa-solid fa-book-open text-warning me-1" style="display:none;"></i>
                <span>SKYBS BookStore</span>
            </a>
            <a href="index.php" class="btn btn-sm btn-outline-light rounded-pill px-3">
                <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Beranda
            </a>
        </div>
    </nav>

    <!-- CONTENT CONTAINER -->
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card-custom p-4 p-md-5">

                    <div class="text-center mb-4">
                        <h3 class="font-heading fw-bold mb-1" style="color: var(--brand-dark-brown);">Pengaturan Profil</h3>
                        <p class="text-muted small">Kelola foto profil dan data pribadi akun Anda</p>
                    </div>

                    <form method="POST" enctype="multipart/form-data">

                        <!-- Foto Profil Avatar -->
                        <div class="text-center mb-4">
                            <img src="<?= $img_user; ?>" alt="Foto Profil" id="avatarPreview" class="profile-avatar mb-3 d-block mx-auto">
                            <label class="btn btn-sm btn-outline-secondary rounded-pill px-3">
                                <i class="fa-solid fa-camera me-1"></i> Ubah Foto Profil
                                <input type="file" name="foto" id="fotoInput" accept="image/*" class="d-none" onchange="previewAvatar()">
                            </label>
                        </div>

                        <!-- Form Input Data -->
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">Nama Lengkap</label>
                            <input type="text" name="nama" class="form-control form-control-custom" value="<?= htmlspecialchars($user['nama']); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">Alamat Email (Tidak Dapat Diubah)</label>
                            <input type="email" class="form-control form-control-custom opacity-75" value="<?= htmlspecialchars($user['email']); ?>" style="background-color: rgba(78, 34, 15, 0.05);" readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">No. WhatsApp / HP</label>
                            <input type="text" name="no_hp" class="form-control form-control-custom" value="<?= htmlspecialchars($user['no_hp'] ?? ''); ?>" required>
                        </div>

                        <div class="mb-4">
                            <label class="form-label small fw-bold text-muted">Alamat Utama Pengiriman</label>
                            <textarea name="alamat" class="form-control form-control-custom" rows="3" required><?= htmlspecialchars($user['alamat'] ?? ''); ?></textarea>
                        </div>

                        <div class="d-flex gap-2 pt-2">
                            <button type="submit" name="update_profil" class="btn btn-sage flex-grow-1">
                                <i class="fa-solid fa-floppy-disk me-1"></i> Simpan Perubahan
                            </button>
                            <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4">Batal</a>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <footer class="text-center">
        <div class="container">
            <h5 class="fw-bold mb-2">SKY BookStore</h5>
            <p class="small mb-0 opacity-75">&copy; <?= date("Y"); ?> SKY BookStore. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        function previewAvatar() {
            const input = document.getElementById('fotoInput');
            const preview = document.getElementById('avatarPreview');
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>