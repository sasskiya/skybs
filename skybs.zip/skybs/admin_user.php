<?php
session_start();
include "database.php";

if (!isset($_SESSION['id_admin'])) {
    header("Location: login.php");
    exit;
}

// Nama admin default
$nama_admin = isset($_SESSION['nama']) && !empty($_SESSION['nama'])
    ? $_SESSION['nama']
    : 'Saskiya';

// Hapus User & Berkas Foto Profil
if (isset($_GET['hapus'])) {
    $id_hapus = (int)$_GET['hapus'];
    
    // Ambil data foto user untuk dihapus dari direktori
    $stmt_foto = mysqli_prepare($conn, "SELECT foto FROM users WHERE id_user = ?");
    mysqli_stmt_bind_param($stmt_foto, "i", $id_hapus);
    mysqli_stmt_execute($stmt_foto);
    $res_foto = mysqli_stmt_get_result($stmt_foto);
    if ($u = mysqli_fetch_assoc($res_foto)) {
        if (!empty($u['foto']) && file_exists("img/users/" . $u['foto'])) {
            unlink("img/users/" . $u['foto']);
        }
    }

    $stmt = mysqli_prepare($conn, "DELETE FROM users WHERE id_user = ?");
    mysqli_stmt_bind_param($stmt, "i", $id_hapus);
    mysqli_stmt_execute($stmt);
    
    header("Location: admin_user.php");
    exit;
}

$data = mysqli_query($conn, "SELECT * FROM users ORDER BY id_user DESC");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Data User | SKYBS Admin</title>

    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --brand-card-bg: #FCF9F0;
            --shadow-sm: 0 4px 18px rgba(78, 34, 15, 0.05);
            --shadow-md: 0 15px 35px rgba(78, 34, 15, 0.06);
            --radius-md: 16px;
            --radius-lg: 24px;
        }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }

        h1, h2, h3, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        /* --- SIDEBAR NAVIGATION --- */
        .sidebar {
            width: 270px;
            height: 100vh;
            background: var(--brand-dark-brown);
            position: fixed;
            left: 0;
            top: 0;
            z-index: 100;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            display: flex;
            flex-direction: column;
        }

        .sidebar-brand {
            color: white;
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.12);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-badge {
            background: rgba(176, 186, 153, 0.25);
            border: 1px solid var(--brand-sage-green);
            color: var(--brand-sage-green);
            padding: 2px 8px;
            border-radius: 6px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 700;
        }

        .sidebar-menu {
            padding: 20px 0;
            flex-grow: 1;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            padding: 13px 25px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }

        .sidebar a i {
            width: 32px;
            font-size: 16px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: rgba(255, 255, 255, 0.12);
            color: #ffffff;
            border-left-color: var(--brand-warm-brown);
        }

        .btn-view-website {
            margin: 18px 20px 0;
            padding: 12px 16px !important;
            border-radius: 10px;
            background: var(--brand-sage-green);
            color: var(--brand-dark-brown) !important;
            border: 1px solid var(--brand-sage-green) !important;
            font-weight: 700 !important;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .btn-view-website:hover {
            background: #DCCFC0;
            color: var(--brand-dark-brown) !important;
            transform: translateY(-2px);
        }

        .btn-logout {
            background: rgba(220, 53, 69, 0.15);
            color: #FF6B6B;
            border: 1px solid rgba(220, 53, 69, 0.2);
            width: 100%;
            border-radius: 12px;
            padding: 10px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .btn-logout:hover {
            background: #DC3545;
            color: white;
        }

        /* --- CONTENT WRAPPER --- */
        .content {
            margin-left: 270px;
            padding: 35px 40px;
        }

        .profile-badge {
            background: #ffffff;
            padding: 8px 18px;
            border-radius: 50px;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(78, 34, 15, 0.08);
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        /* --- CARD & TABLE --- */
        .card-custom {
            background: var(--brand-card-bg);
            border: 1px solid rgba(157, 102, 56, 0.15);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
            overflow: hidden;
        }

        .table-custom {
            margin-bottom: 0;
            vertical-align: middle;
            background: transparent;
        }

        .table-custom thead {
            background: var(--brand-dark-brown) !important;
        }

        .table-custom thead th {
            color: #FFFFFF !important;
            font-weight: 700;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            padding: 18px 16px;
            border: none;
            background-color: var(--brand-dark-brown) !important;
        }

        .table-custom tbody td {
            padding: 18px 16px;
            border-bottom: 1px solid #ebdcb8;
            color: var(--brand-dark-brown);
            font-size: 13px;
            background-color: #ffffff;
        }

        .table-custom tbody tr {
            transition: all 0.2s ease-in-out;
        }

        .table-custom tbody tr:hover td {
            background-color: #fcf6e8;
            transform: scale(1.001);
        }

        /* --- COMPONENTS --- */
        .user-avatar {
            width: 44px;
            height: 44px;
            object-fit: cover;
            border-radius: 50%;
            border: 2px solid var(--brand-warm-brown);
            box-shadow: 0 4px 10px rgba(0,0,0,0.08);
        }

        .badge-wa {
            background: #D1E7DD;
            color: #0F5132;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s ease;
            border: 1px solid #BADBCE;
        }

        .badge-wa:hover {
            background: #25D366;
            color: white;
            border-color: #25D366;
        }

        .btn-action-delete {
            background: #F8D7DA;
            color: #842029;
            border: none;
            border-radius: 10px;
            padding: 7px 14px;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        .btn-action-delete:hover {
            background: #F5C2C7;
            color: #842029;
            transform: translateY(-1px);
        }

        footer {
            margin-top: 80px;
            padding: 25px 0;
            font-size: 13px;
        }

        @media (max-width: 992px) {
            .sidebar { width: 100%; height: auto; position: relative; }
            .content { margin-left: 0; padding: 20px; }
        }
    </style>
</head>

<body>

    <!-- SIDEBAR NAVIGATION -->
    <div class="sidebar">
        <div class="sidebar-brand">
            <i class="fa-solid fa-book-open text-warning fs-4"></i>
            <div>
                <h5 class="fw-bold mb-0 text-white">SKYBS Admin</h5>
                <span class="brand-badge">Panel System</span>
            </div>
        </div>

        <div class="sidebar-menu">
            <a href="admin.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
            <a href="admin_kategori.php"><i class="fa-solid fa-tags"></i> Kategori Buku</a>
            <a href="admin_buku.php"><i class="fa-solid fa-book"></i> Data Buku</a>
            <a href="admin_user.php" class="active"><i class="fa-solid fa-users"></i> Data User</a>
            <a href="admin_pesanan.php"><i class="fa-solid fa-cart-shopping"></i> Pesanan</a>
            <a href="admin_war.php"><i class="fa-solid fa-ticket"></i> War Tiket</a>
            <a href="admin_contact.php"><i class="fa-solid fa-comments"></i> Pesan User</a>

            <a href="index.php" target="_blank" class="btn-view-website">
                <i class="fa-solid fa-eye"></i> Buka Full Website
            </a>
        </div>

        <div class="p-3">
            <form action="logout.php" method="POST">
                <button type="submit" class="btn btn-logout d-flex align-items-center justify-content-center gap-2" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <span>Logout</span>
                </button>
            </form>
        </div>
    </div>

    <!-- MAIN CONTENT AREA -->
    <div class="content animate__animated animate__fadeIn">

        <!-- HEADER TOPBAR -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 pb-3 border-bottom border-secondary-subtle">
            <div>
                <h2 class="font-heading fw-bold mb-1" style="color: var(--brand-dark-brown);">Data Pengguna (User)</h2>
                <p class="text-muted small mb-0">Kelola dan lihat akun pelanggan terdaftar di platform SKY Bookstore dengan mudah.</p>
            </div>
            <div>
                <div class="profile-badge">
                    <i class="fa-solid fa-user-gear fs-5" style="color: var(--brand-warm-brown);"></i>
                    <span class="fw-bold fs-6" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($nama_admin); ?> (Admin)</span>
                </div>
            </div>
        </div>

        <!-- TABEL USER -->
        <div class="card-custom p-4 animate__animated animate__fadeInUp">
            <div class="table-responsive">
                <table class="table table-custom">
                    <thead>
                        <tr>
                            <th class="text-center" width="60">No</th>
                            <th class="text-center" width="80">Foto Profil</th>
                            <th>Informasi Pengguna</th>
                            <th>Alamat Email</th>
                            <th>No. WhatsApp / HP</th>
                            <th>Alamat Pengiriman</th>
                            <th class="text-center" width="100">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($data) > 0): ?>
                            <?php 
                            $no = 1;
                            while ($d = mysqli_fetch_assoc($data)): 
                                // Penanganan Foto Avatar
                                $path_foto = "img/users/" . $d['foto'];
                                if (!empty($d['foto']) && file_exists($path_foto)) {
                                    $avatar = $path_foto;
                                } else {
                                    $avatar = "https://ui-avatars.com/api/?name=" . urlencode($d['nama']) . "&background=9D6638&color=fff";
                                }
                            ?>
                                <tr>
                                    <td class="text-center fw-bold text-muted"><?= $no++; ?></td>
                                    <td class="text-center">
                                        <img src="<?= htmlspecialchars($avatar); ?>" alt="Profile <?= htmlspecialchars($d['nama']); ?>" class="user-avatar">
                                    </td>
                                    <td>
                                        <div class="fw-bold fs-6" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($d['nama']); ?></div>
                                        <small class="text-muted" style="font-size: 11px;"><i class="fa-solid fa-id-badge me-1"></i>ID User: #<?= (int)$d['id_user']; ?></small>
                                    </td>
                                    <td>
                                        <a href="mailto:<?= htmlspecialchars($d['email']); ?>" class="text-decoration-none fw-medium" style="color: var(--brand-dark-brown);">
                                            <i class="fa-regular fa-envelope me-1 text-muted"></i><?= htmlspecialchars($d['email']); ?>
                                        </a>
                                    </td>
                                    <td>
                                        <?php if (!empty($d['no_hp'])): ?>
                                            <?php 
                                                // Format nomor WhatsApp (Ubah 08xx jadi 628xx)
                                                $hp = preg_replace('/[^0-9]/', '', $d['no_hp']);
                                                if (substr($hp, 0, 1) === '0') {
                                                    $hp = '62' . substr($hp, 1);
                                                }
                                            ?>
                                            <a href="https://wa.me/<?= $hp; ?>" target="_blank" class="badge-wa shadow-sm" title="Hubungi via WhatsApp">
                                                <i class="fa-brands fa-whatsapp fs-6"></i><?= htmlspecialchars($d['no_hp']); ?>
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted small fst-italic">Belum diisi</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="small text-muted" style="max-width: 250px;">
                                        <?= !empty($d['alamat']) ? htmlspecialchars($d['alamat']) : '<span class="fst-italic">Belum diisi</span>'; ?>
                                    </td>
                                    <td class="text-center">
                                        <a href="?hapus=<?= (int)$d['id_user']; ?>" 
                                           class="btn btn-action-delete shadow-sm" 
                                           onclick="return confirm('Apakah Anda yakin ingin menghapus akun user \'<?= addslashes(htmlspecialchars($d['nama'])); ?>\'?')" 
                                           title="Hapus Akun User">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted">
                                    <i class="fa-solid fa-users-slash fs-1 opacity-50 mb-3 d-block text-warning"></i>
                                    Belum ada data user terdaftar saat ini.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <footer class="mt-5 text-center text-muted small">
            <p class="mb-0">&copy; <?= date('Y') ?> <strong>SKY Bookstore </strong> - Admin Dashboard System.</p>
        </footer>

    </div>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>