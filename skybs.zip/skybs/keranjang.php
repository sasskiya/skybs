<?php
session_start();
include "database.php";

if (!isset($_SESSION['id_user'])) {
    echo "<script>alert('Silakan login terlebih dahulu!'); window.location='login.php';</script>";
    exit;
}

$id_user = (int)$_SESSION['id_user'];
// 1. TAMBAH KE KERANJANG DENGAN JUMLAH (QTY) DINAMIS
if (isset($_GET['id'])) {
    $id_buku = (int)$_GET['id'];
    $tambah_qty = isset($_GET['qty']) ? (int)$_GET['qty'] : 1;
    if ($tambah_qty < 1) $tambah_qty = 1;

    $stmt_cek = mysqli_prepare($conn, "SELECT id_keranjang, jumlah FROM keranjang WHERE id_user = ? AND id_buku = ?");
    if ($stmt_cek) {
        mysqli_stmt_bind_param($stmt_cek, "ii", $id_user, $id_buku);
        mysqli_stmt_execute($stmt_cek);
        $res_cek = mysqli_stmt_get_result($stmt_cek);

        if ($exist = mysqli_fetch_assoc($res_cek)) {
            $stmt_up = mysqli_prepare($conn, "UPDATE keranjang SET jumlah = jumlah + ? WHERE id_keranjang = ?");
            if ($stmt_up) {
                mysqli_stmt_bind_param($stmt_up, "ii", $tambah_qty, $exist['id_keranjang']);
                mysqli_stmt_execute($stmt_up);
            }
        } else {
            $stmt_in = mysqli_prepare($conn, "INSERT INTO keranjang (id_user, id_buku, jumlah) VALUES (?, ?, ?)");
            if ($stmt_in) {
                mysqli_stmt_bind_param($stmt_in, "iii", $id_user, $id_buku, $tambah_qty);
                mysqli_stmt_execute($stmt_in);
            }
        }
    }

    header("Location: keranjang.php");
    exit;
}
// 2. UPDATE JUMLAH ITEM BUKU KETIKA TOMBOL 'PERBARUI JUMLAH' DIKLIK
if (isset($_POST['update'])) {
    if (isset($_POST['jumlah']) && is_array($_POST['jumlah'])) {
        foreach ($_POST['jumlah'] as $id_keranjang => $jumlah) {
            $id_k = (int)$id_keranjang;
            $jml  = (int)$jumlah;
            if ($jml < 1) $jml = 1;

            $stmt_up_jml = mysqli_prepare($conn, "UPDATE keranjang SET jumlah = ? WHERE id_keranjang = ? AND id_user = ?");
            if ($stmt_up_jml) {
                mysqli_stmt_bind_param($stmt_up_jml, "iii", $jml, $id_k, $id_user);
                mysqli_stmt_execute($stmt_up_jml);
            }
        }
    }
    header("Location: keranjang.php");
    exit;
}
// 3. HAPUS ITEM
if (isset($_GET['hapus'])) {
    $hapus_id = (int)$_GET['hapus'];
    $stmt_del = mysqli_prepare($conn, "DELETE FROM keranjang WHERE id_keranjang = ? AND id_user = ?");
    if ($stmt_del) {
        mysqli_stmt_bind_param($stmt_del, "ii", $hapus_id, $id_user);
        mysqli_stmt_execute($stmt_del);
        mysqli_stmt_close($stmt_del);
    }
    header("Location: keranjang.php");
    exit;
}
// 4. AMBIL DATA KERANJANG DAN DATA BUKU
$stmt_cart = mysqli_prepare($conn,
    "SELECT k.id_keranjang, k.id_user, k.id_buku, k.jumlah,
            b.judul, b.cover, b.harga, b.stok
     FROM keranjang k
     INNER JOIN buku b ON k.id_buku = b.id_buku
     WHERE k.id_user = ?
     ORDER BY k.id_keranjang DESC"
);
$data = false;
if ($stmt_cart) {
    mysqli_stmt_bind_param($stmt_cart, "i", $id_user);
    mysqli_stmt_execute($stmt_cart);
    $data = mysqli_stmt_get_result($stmt_cart);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja | SKY Bookstore</title>
    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    
    <style>
        :root {
            --brand-dark-brown: #3C180A;
            --brand-warm-brown: #8D5524;
            --brand-sage-green: #97A97C;
            --brand-cream-bg: #F7F1DE;
            --brand-card-bg: #FCF9F0;
            --shadow-sm: 0 4px 20px rgba(60, 24, 10, 0.05);
            --shadow-md: 0 12px 30px rgba(60, 24, 10, 0.08);
            --radius-lg: 24px;
        }

        body { 
            background-color: var(--brand-cream-bg); 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            color: var(--brand-dark-brown); 
            min-height: 100vh; 
        }

        h1, h2, h3, h4, .font-heading { 
            font-family: 'Playfair Display', serif; 
        }

        /* --- NAVBAR --- */
        .navbar-custom { 
            background: rgba(60, 24, 10, 0.95); 
            backdrop-filter: blur(10px);
            padding: 14px 0; 
            box-shadow: 0 4px 25px rgba(0, 0, 0, 0.1); 
        }

        .navbar-brand { 
            color: #FFFFFF !important; 
            font-weight: 800; 
            font-size: 20px;
            display: flex; 
            align-items: center; 
            gap: 10px; 
            text-decoration: none;
        }

        /* --- CARD & TABLE --- */
        .card-custom { 
            background: var(--brand-card-bg); 
            border-radius: var(--radius-lg); 
            box-shadow: var(--shadow-sm); 
            border: 1px solid rgba(141, 85, 36, 0.12); 
        }

        .table thead th {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            color: var(--brand-warm-brown);
            border-bottom: 2px solid rgba(141, 85, 36, 0.15);
        }

        .table tbody td {
            border-bottom: 1px solid rgba(141, 85, 36, 0.08);
            vertical-align: middle;
        }

        .book-thumb { 
            width: 65px; 
            height: 85px; 
            object-fit: cover; 
            border-radius: 12px; 
            box-shadow: 0 4px 10px rgba(0,0,0,0.08);
        }

        /* --- BUTTONS --- */
        .btn-checkout { 
            background: var(--brand-dark-brown); 
            color: white; 
            border-radius: 50px; 
            padding: 10px 28px; 
            font-weight: 700; 
            font-size: 14px;
            border: none; 
            text-decoration: none; 
            display: inline-block; 
            transition: all 0.2s;
            box-shadow: 0 4px 15px rgba(60, 24, 10, 0.2);
        }

        .btn-checkout:hover { 
            background: var(--brand-warm-brown); 
            color: white; 
            transform: translateY(-2px);
        }

        .btn-update {
            background: #FFFFFF;
            border: 1px solid var(--brand-warm-brown);
            color: var(--brand-dark-brown);
            border-radius: 50px;
            padding: 10px 24px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s;
        }

        .btn-update:hover {
            background: var(--brand-warm-brown);
            color: white;
        }

        footer { 
            background: var(--brand-dark-brown); 
            color: var(--brand-cream-bg); 
            padding: 40px 0 25px; 
            margin-top: 80px; 
            border-top: 4px solid var(--brand-warm-brown);
        }
    </style>
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-custom sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fa-solid fa-book-open text-warning"></i>
                <span>SKY Bookstore</span>
            </a>
            <div class="ms-auto">
                <a href="index.php" class="text-white text-decoration-none fw-semibold small">
                    <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Beranda
                </a>
            </div>
        </div>
    </nav>

    <!-- KONTEN UTAMA -->
    <div class="container py-5 animate__animated animate__fadeIn">
        <h2 class="font-heading fw-bold mb-4" style="color: var(--brand-dark-brown);">
            <i class="fa-solid fa-cart-shopping me-2 text-warning"></i>Keranjang Belanja
        </h2>

        <?php if ($data && mysqli_num_rows($data) > 0): ?>
            <form method="POST">
                <div class="card-custom p-4 mb-4 shadow-sm">
                    <div class="table-responsive">
                        <table class="table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 80px;">Sampul</th>
                                    <th>Informasi Buku</th>
                                    <th>Harga Satuan</th>
                                    <th class="text-center" style="width: 140px;">Jumlah (Qty)</th>
                                    <th class="text-end">Subtotal</th>
                                    <th class="text-center" style="width: 60px;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $total = 0; 
                                while ($d = mysqli_fetch_assoc($data)):
                                    $subtotal = $d['harga'] * $d['jumlah'];
                                    $total += $subtotal;
                                    
                                    $cover_path = "img/buku/" . $d['cover'];
                                    $img_src = (!empty($d['cover']) && file_exists($cover_path)) ? $cover_path : "https://via.placeholder.com/60x80?text=No+Cover";
                                ?>
                                <tr>
                                    <td>
                                        <img src="<?= htmlspecialchars($img_src); ?>" class="book-thumb" alt="Cover Buku">
                                    </td>
                                    <td>
                                        <div class="fw-bold text-dark fs-6"><?= htmlspecialchars($d['judul']); ?></div>
                                        <small class="text-muted" style="font-size: 11px;">Stok tersedia: <?= $d['stok']; ?></small>
                                    </td>
                                    <td class="fw-medium">Rp <?= number_format($d['harga'], 0, ',', '.'); ?></td>
                                    <td class="text-center">
                                        <input type="number" name="jumlah[<?= $d['id_keranjang']; ?>]" value="<?= $d['jumlah']; ?>" min="1" max="<?= $d['stok']; ?>" class="form-control form-control-sm text-center fw-bold mx-auto shadow-sm rounded-3" style="width: 70px;">
                                    </td>
                                    <td class="text-end fw-bold" style="color: var(--brand-warm-brown);">Rp <?= number_format($subtotal, 0, ',', '.'); ?></td>
                                    <td class="text-center">
                                        <a href="?hapus=<?= $d['id_keranjang']; ?>" class="text-danger p-2" title="Hapus Item" onclick="return confirm('Apakah Anda yakin ingin menghapus buku ini dari keranjang?')"><i class="fa-solid fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="d-flex justify-content-end align-items-center mt-4 pt-3 border-top">
                        <div class="text-end">
                            <span class="text-muted small d-block">Total Keseluruhan Tagihan</span>
                            <h3 class="fw-bold mb-0" style="color: var(--brand-dark-brown);">Rp <?= number_format($total, 0, ',', '.'); ?></h3>
                        </div>
                    </div>
                </div>

                <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
                    <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4 py-2.5 w-100 w-md-auto fw-semibold">
                        <i class="fa-solid fa-arrow-left me-2"></i> Lanjut Belanja
                    </a>
                    <div class="d-flex flex-column flex-md-row gap-2 w-100 w-md-auto">
                        <button type="submit" name="update" class="btn btn-update w-100 w-md-auto shadow-sm">
                            <i class="fa-solid fa-rotate me-2"></i> Perbarui Jumlah
                        </button>
                        <a href="checkout.php" class="btn btn-checkout text-center w-100 w-md-auto">
                            <i class="fa-solid fa-lock me-2"></i> Checkout Sekarang
                        </a>
                    </div>
                </div>
            </form>
        <?php else: ?>
            <div class="card-custom p-5 text-center shadow-sm mt-4">
                <div class="mb-3">
                    <i class="fa-solid fa-cart-shopping fs-1 text-warning opacity-75"></i>
                </div>
                <h4 class="fw-bold font-heading mb-2">Keranjang Belanja Anda Kosong</h4>
                <p class="text-muted small mb-4">Belum ada buku yang ditambahkan ke keranjang belanja Anda saat ini.</p>
                <div>
                    <a href="index.php" class="btn btn-checkout px-4 py-2.5 rounded-pill shadow-sm">
                        <i class="fa-solid fa-book-open me-2"></i> Mulai Belanja Sekarang
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- FOOTER -->
    <footer>
        <div class="container text-center">
            <p class="mb-0 small text-white-50">&copy; <?= date("Y"); ?> <strong>SKY Bookstore</strong>. All Rights Reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>