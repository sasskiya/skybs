<?php
session_start();
include "database.php";

// Cek login admin
if (!isset($_SESSION['id_admin'])) {
    echo "<script>
        alert('Silakan login sebagai Admin!');
        window.location='login.php';
    </script>";
    exit;
}

// Nama admin default
$nama_admin = isset($_SESSION['nama']) && !empty($_SESSION['nama'])
    ? $_SESSION['nama']
    : 'Saskiya';

// =========================================
// STATISTIK DASHBOARD
// =========================================

// Total Buku
$total_buku = mysqli_fetch_row(
    mysqli_query($conn, "SELECT COUNT(*) FROM buku")
)[0] ?? 0;

// Total Kategori
$total_kategori = mysqli_fetch_row(
    mysqli_query($conn, "SELECT COUNT(*) FROM kategori")
)[0] ?? 0;

// Total User
$total_user = mysqli_fetch_row(
    mysqli_query($conn, "SELECT COUNT(*) FROM users")
)[0] ?? 0;

// Total Pesanan
$total_pesanan = mysqli_fetch_row(
    mysqli_query($conn, "SELECT COUNT(*) FROM pesanan")
)[0] ?? 0;


// Total Pendapatan (Hanya menghitung pesanan Selesai dan mengabaikan pesanan yang Batal atau Refund)
$pendapatan_query = mysqli_query(
    $conn,
    "SELECT SUM(total_harga) AS total FROM pesanan WHERE status='Selesai' AND status != 'Batal' AND status != 'Refund'"
);

$dataPendapatan = mysqli_fetch_assoc($pendapatan_query);
$total_pendapatan = $dataPendapatan['total'] ?? 0;

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin | SKYBS BookStore</title>

    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --brand-card-bg: #FCF9F0;

            --shadow-sm: 0 4px 18px rgba(78, 34, 15, 0.05);
            --shadow-md: 0 10px 25px rgba(78, 34, 15, 0.1);

            --radius-md: 16px;
            --radius-lg: 20px;
        }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }

        h1, h2, h3, h4, h5, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        /* SIDEBAR NAVIGATION */
        .sidebar {
            width: 270px;
            height: 100vh;
            background: var(--brand-dark-brown);
            position: fixed;
            left: 0;
            top: 0;
            z-index: 1000;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            display: flex;
            flex-direction: column;
            transition: all 0.3s ease;
        }

        .sidebar-brand {
            color: white;
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.12);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-badge {
            background: rgba(176, 186, 153, 0.25);
            border: 1px solid var(--brand-sage-green);
            color: var(--brand-sage-green);
            padding: 2px 8px;
            border-radius: 6px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 700;
        }

        .sidebar-menu {
            padding: 20px 0;
            flex-grow: 1;
            overflow-y: auto;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            padding: 13px 25px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }

        .sidebar a i {
            width: 32px;
            font-size: 16px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: rgba(255, 255, 255, 0.12);
            color: #FFFFFF;
            border-left-color: var(--brand-warm-brown);
        }

        .btn-view-website {
            margin: 18px 20px 0;
            padding: 12px 16px !important;
            border-radius: 10px;
            background: var(--brand-sage-green);
            color: var(--brand-dark-brown) !important;
            border: 1px solid var(--brand-sage-green) !important;
            font-weight: 700 !important;
            justify-content: center;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-view-website:hover {
            background: #DCCFC0;
            transform: translateY(-2px);
        }

        .content {
            margin-left: 270px;
            padding: 35px 40px;
            transition: all 0.3s ease;
        }

        .profile-badge {
            background: #FFFFFF;
            padding: 8px 18px;
            border-radius: 50px;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(78, 34, 15, 0.08);
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .card-stat {
            border: 1px solid rgba(78, 34, 15, 0.08);
            border-radius: var(--radius-lg);
            background: var(--brand-card-bg);
            transition: all 0.3s ease;
            box-shadow: var(--shadow-sm);
            height: 100%;
        }

        .card-stat:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
        }

        .icon-box {
            width: 58px;
            height: 58px;
            border-radius: 16px;
            background: #FFFFFF;
            color: var(--brand-warm-brown);
            border: 1px solid var(--brand-sage-green);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-bottom: 16px;
        }

        .icon-box-success {
            background: rgba(176, 186, 153, 0.3);
            color: var(--brand-dark-brown);
            border-color: var(--brand-sage-green);
        }

        /* LIVE PREVIEW IFRAME STYLING */
        .preview-container {
            background: #FFFFFF;
            border: 1px solid rgba(78, 34, 15, 0.08);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            overflow: hidden;
            margin-bottom: 40px;
        }

        .preview-header {
            padding: 16px 24px;
            background: var(--brand-dark-brown);
            color: #ffffff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .preview-screen {
            width: 100%;
            height: 500px;
            border: none;
            background: #FDFBF7;
        }

        .card-table {
            background: #FFFFFF;
            border: 1px solid rgba(78, 34, 15, 0.08);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            overflow: hidden;
        }

        .table-custom {
            margin-bottom: 0;
            vertical-align: middle;
        }

        .table-custom thead {
            background: var(--brand-dark-brown) !important;
        }

        .table-custom thead th {
            color: #FFFFFF !important;
            font-weight: 700;
            font-size: 13px;
            letter-spacing: 0.8px;
            text-transform: uppercase;
            padding: 16px 20px;
            border: none;
            background-color: var(--brand-dark-brown) !important;
        }

        .table-custom tbody td {
            padding: 16px 20px;
            border-bottom: 1px solid rgba(78, 34, 15, 0.05);
            color: var(--brand-dark-brown);
            font-size: 14px;
        }

        .table-custom tbody tr:hover {
            background-color: rgba(157, 102, 56, 0.03);
        }

        .badge-status {
            padding: 6px 14px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 700;
            display: inline-block;
        }

        .btn-logout {
            background: rgba(220, 53, 69, 0.15);
            color: #FF6B6B;
            border: 1px solid rgba(220, 53, 69, 0.2);
            width: 100%;
            border-radius: 12px;
            padding: 10px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .btn-logout:hover {
            background: #DC3545;
            color: white;
        }

        /* RESPONSIVE LAYOUT BREAKPOINTS */
        @media (max-width: 992px) {
            .sidebar { 
                width: 100%; 
                height: auto; 
                position: relative; 
            }
            .content { 
                margin-left: 0; 
                padding: 20px 15px; 
            }
        }
    </style>
</head>

<body>

    <!-- SIDEBAR NAVIGATION -->
    <div class="sidebar">
        <div class="sidebar-brand">
            <i class="fa-solid fa-book-open text-warning fs-4"></i>
            <div>
                <h5 class="fw-bold mb-0 text-white">SKYBS Admin</h5>
                <span class="brand-badge">Panel System</span>
            </div>
        </div>

        <div class="sidebar-menu">
            <a href="admin.php" class="active"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
            <a href="admin_kategori.php"><i class="fa-solid fa-tags"></i> Kategori Buku</a>
            <a href="admin_buku.php"><i class="fa-solid fa-book"></i> Data Buku</a>
            <a href="admin_user.php"><i class="fa-solid fa-users"></i> Data User</a>
            <a href="admin_pesanan.php"><i class="fa-solid fa-cart-shopping"></i> Pesanan</a>
            <a href="admin_war.php"><i class="fa-solid fa-ticket"></i> War Tiket</a>
            <a href="admin_contact.php"><i class="fa-solid fa-comments"></i> Pesan User</a>

            <a href="index.php" target="_blank" class="btn-view-website">
                <i class="fa-solid fa-eye"></i> Buka Full Website
            </a>
        </div>

        <div class="p-3">
            <form action="logout.php" method="POST">
                <button type="submit" class="btn btn-logout d-flex align-items-center justify-content-center gap-2" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <span>Logout</span>
                </button>
            </form>
        </div>
    </div>

    <!-- MAIN CONTENT AREA -->
    <div class="content animate__animated animate__fadeIn">

        <!-- HEADER TOPBAR -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 pb-3 border-bottom border-secondary-subtle">
            <div>
                <h2 class="font-heading fw-bold mb-1" style="color: var(--brand-dark-brown);">Dashboard Overview</h2>
                <p class="text-muted mb-0">Selamat datang kembali, <strong><?= htmlspecialchars($nama_admin); ?></strong> 👋</p>
            </div>
            <div>
                <div class="profile-badge">
                    <i class="fa-solid fa-user-gear fs-5" style="color: var(--brand-warm-brown);"></i>
                    <span class="fw-bold fs-6" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($nama_admin); ?> (Admin)</span>
                </div>
            </div>
        </div>

        <!-- STATISTIC CARDS -->
        <div class="row g-4 mb-5">
            <div class="col-sm-6 col-xl-4">
                <div class="card card-stat p-4">
                    <div class="icon-box"><i class="fa-solid fa-book"></i></div>
                    <h3 class="fw-bold mb-1" style="color: var(--brand-dark-brown);"><?= number_format($total_buku); ?></h3>
                    <span class="text-muted small fw-semibold">Total Koleksi Buku</span>
                </div>
            </div>
            <div class="col-sm-6 col-xl-4">
                <div class="card card-stat p-4">
                    <div class="icon-box"><i class="fa-solid fa-tags"></i></div>
                    <h3 class="fw-bold mb-1" style="color: var(--brand-dark-brown);"><?= number_format($total_kategori); ?></h3>
                    <span class="text-muted small fw-semibold">Kategori Buku</span>
                </div>
            </div>
            <div class="col-sm-6 col-xl-4">
                <div class="card card-stat p-4">
                    <div class="icon-box"><i class="fa-solid fa-users"></i></div>
                    <h3 class="fw-bold mb-1" style="color: var(--brand-dark-brown);"><?= number_format($total_user); ?></h3>
                    <span class="text-muted small fw-semibold">User Terdaftar</span>
                </div>
            </div>
            <div class="col-sm-6 col-xl-6">
                <div class="card card-stat p-4">
                    <div class="icon-box"><i class="fa-solid fa-cart-shopping"></i></div>
                    <h3 class="fw-bold mb-1" style="color: var(--brand-dark-brown);"><?= number_format($total_pesanan); ?></h3>
                    <span class="text-muted small fw-semibold">Total Transaksi Masuk</span>
                </div>
            </div>
            <div class="col-sm-12 col-xl-6">
                <div class="card card-stat p-4">
                    <div class="icon-box icon-box-success"><i class="fa-solid fa-wallet"></i></div>
                    <h3 class="fw-bold mb-1" style="color: var(--brand-warm-brown);">Rp <?= number_format($total_pendapatan, 0, ",", "."); ?></h3>
                    <span class="text-muted small fw-semibold">Total Pendapatan (Pesanan Selesai)</span>
                </div>
            </div>
        </div>

        <!-- =========================================
             LIVE PREVIEW WEBSITE USER DI DALAM ADMIN
        ========================================= -->
        <div class="preview-container">
            <div class="preview-header">
                <h5 class="font-heading fw-bold mb-0 text-white">
                    <i class="fa-solid fa-desktop me-2 text-warning"></i>Live Preview Tampilan Website User
                </h5>
                <a href="index.php" target="_blank" class="btn btn-sm btn-light fw-bold rounded-pill px-3">
                    <i class="fa-solid fa-up-right-from-square me-1"></i> Buka Fullscreen
                </a>
            </div>
            <div class="card-body p-0">
                <iframe src="index.php" class="preview-screen" title="Live Preview Website"></iframe>
            </div>
        </div>

        <!-- RECENT TRANSACTIONS TABLE -->
        <div class="card-table">
            <div class="p-4 border-bottom d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h5 class="font-heading fw-bold mb-0" style="color: var(--brand-dark-brown);">
                    <i class="fa-solid fa-clock-rotate-left me-2" style="color: var(--brand-warm-brown);"></i>5 Pesanan Terbaru
                </h5>
                <a href="admin_pesanan.php" class="btn btn-sm btn-outline-secondary rounded-pill px-3 fw-semibold">Lihat Semua</a>
            </div>
            <div class="table-responsive">
                <table class="table table-custom">
                    <thead>
                        <tr>
                            <th class="ps-4" width="60">No</th>
                            <th>Nama Customer</th>
                            <th>Total Belanja</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Tanggal Pesan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $pesanan = mysqli_query($conn, "
                            SELECT pesanan.*, users.nama
                            FROM pesanan
                            JOIN users ON pesanan.id_user = users.id_user
                            ORDER BY pesanan.id_pesanan DESC
                            LIMIT 5
                        ");

                        if (mysqli_num_rows($pesanan) > 0) {
                            while ($p = mysqli_fetch_assoc($pesanan)) {
                                $status = $p['status'];
                                $badgeStyle = "background: #EAE3D2; color: #4E220F;";

                                if ($status == "Menunggu Konfirmasi") {
                                    $badgeStyle = "background: #FFF3CD; color: #856404; border: 1px solid #FFEBAA;";
                                } elseif ($status == "Diproses") {
                                    $badgeStyle = "background: #CFF4FC; color: #055160; border: 1px solid #2e5b96;";
                                } elseif ($status == "Dikirim") {
                                    $badgeStyle = "background: #E0CFFC; color: #3D0A91; border: 1px solid #D0BFFF;";
                                } elseif ($status == "Selesai") {
                                    $badgeStyle = "background: #D1E7DD; color: #0F5132; border: 1px solid #073624;";
                                } elseif ($status == "Batal") {
                                    $badgeStyle = "background: #F8D7DA; color: #842029; border: 1px solid #F5C2C7;";
                                } elseif ($status == "Refund") {
                                    $badgeStyle = "background: #cfe2ff; color: #980861; border: 1px solid #961c71;";
                                }
                        ?>
                        <tr>
                            <td class="ps-4 fw-bold text-muted"><?= $no++; ?></td>
                            <td class="fw-bold" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($p['nama']); ?></td>
                            <td class="fw-bold" style="color: var(--brand-warm-brown);">Rp <?= number_format($p['total_harga'], 0, ",", "."); ?></td>
                            <td class="text-center"><span class="badge-status" style="<?= $badgeStyle; ?>"><?= htmlspecialchars($status); ?></span></td>
                            <td class="text-center text-muted small"><?= isset($p['tanggal']) ? date("d M Y, H:i", strtotime($p['tanggal'])) : '-'; ?></td>
                        </tr>
                        <?php
                            }
                        } else {
                        ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="fa-solid fa-box-open fs-1 opacity-50 mb-3 d-block"></i>
                                Belum ada transaksi terbaru.
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <footer class="mt-5 text-center text-muted small">
            <p class="mb-0">&copy; <?= date("Y"); ?> <strong>SKY Bookstore</strong> - Admin Dashboard System.</p>
        </footer>

    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>