
<?php
$host = "127.0.0.1";
$user = "SASE";
$password = "sase1309";
$database = "sys";

$conn = mysqli_connect(
    $host,
    $user,
    $password,
    $database
);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>
