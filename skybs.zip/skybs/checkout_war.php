<?php
session_start();
include "database.php";

// =========================================
// 1. CEK LOGIN USER
// =========================================

if (!isset($_SESSION['id_user'])) {
    echo "<script>
        alert('Silakan login terlebih dahulu!');
        window.location='login.php';
    </script>";
    exit;
}

$id_user = (int)$_SESSION['id_user'];
$id_transaksi = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id_transaksi <= 0) {
    echo "<script>
        alert('Tiket War tidak valid!');
        window.location='myticket.php';
    </script>";
    exit;
}

// =========================================
// 2. AMBIL DATA TRANSAKSI WAR
// =========================================

$stmt_trans = mysqli_prepare($conn, "
    SELECT *
    FROM transaksi
    WHERE id_transaksi = ?
      AND id_user = ?
      AND tipe = 'war'
    LIMIT 1
");

if (!$stmt_trans) {
    die("Gagal menyiapkan query transaksi: " . mysqli_error($conn));
}

mysqli_stmt_bind_param(
    $stmt_trans,
    "ii",
    $id_transaksi,
    $id_user
);

mysqli_stmt_execute($stmt_trans);

$result_trans = mysqli_stmt_get_result($stmt_trans);
$trans_data = mysqli_fetch_assoc($result_trans);

if (!$trans_data) {
    echo "<script>
        alert('Data tiket War tidak ditemukan atau bukan milik Anda!');
        window.location='myticket.php';
    </script>";
    exit;
}

// =========================================
// 3. CEK STATUS TIKET
// =========================================

if (
    isset($trans_data['status']) &&
    $trans_data['status'] === 'Checkout Selesai'
) {
    echo "<script>
        alert('Tiket War ini sudah pernah diproses!');
        window.location='history.php';
    </script>";
    exit;
}

// =========================================
// 4. AMBIL DATA BUKU WAR
// =========================================

$buku_id = (int)$trans_data['id_buku'];

$stmt_buku = mysqli_prepare($conn, "
    SELECT
        id_buku,
        judul,
        penulis,
        cover,
        harga,
        tipe_buku
    FROM buku
    WHERE id_buku = ?
      AND tipe_buku = 'war'
    LIMIT 1
");

if (!$stmt_buku) {
    die("Gagal menyiapkan query buku: " . mysqli_error($conn));
}

mysqli_stmt_bind_param(
    $stmt_buku,
    "i",
    $buku_id
);

mysqli_stmt_execute($stmt_buku);

$result_buku = mysqli_stmt_get_result($stmt_buku);
$buku_info = mysqli_fetch_assoc($result_buku);

if (!$buku_info) {
    echo "<script>
        alert('Data buku War tidak ditemukan!');
        window.location='myticket.php';
    </script>";
    exit;
}

// =========================================
// 5. DATA HARGA DAN KODE TIKET (DENGAN PENGAMAN KELIPATAN RIBUAN)
// =========================================

$harga_buku = (int)$trans_data['total_harga'];
if ($harga_buku < 1000 && $harga_buku > 0) {
    $harga_buku = $harga_buku * 1000; // Memperbaiki nilai yang terpotong (misal 89 menjadi 89000)
}

$kode_tiket = "SKYBS-WAR-" .
    str_pad($trans_data['id_transaksi'], 5, "0", STR_PAD_LEFT);

// =========================================
// 6. AMBIL DATA USER
// =========================================

$stmt_user = mysqli_prepare($conn, "
    SELECT nama, no_hp, alamat
    FROM users
    WHERE id_user = ?
    LIMIT 1
");

if (!$stmt_user) {
    die("Gagal menyiapkan query user: " . mysqli_error($conn));
}

mysqli_stmt_bind_param(
    $stmt_user,
    "i",
    $id_user
);

mysqli_stmt_execute($stmt_user);

$result_user = mysqli_stmt_get_result($stmt_user);
$data_user = mysqli_fetch_assoc($result_user);

$sudah_pernah_pakai = false;

// =========================================
// 7. PROSES CHECKOUT WAR
// =========================================

if (isset($_POST['checkout_war'])) {

    $metode = trim($_POST['metode'] ?? '');
    $kota_tujuan = trim($_POST['kota_tujuan'] ?? '');
    $alamat_pengiriman = trim($_POST['alamat_pengiriman'] ?? '');
    $no_hp = trim($_POST['no_hp'] ?? '');
    $kode_voucher = trim($_POST['kode_voucher'] ?? '');

    if (
        empty($metode) ||
        empty($kota_tujuan) ||
        empty($alamat_pengiriman) ||
        empty($no_hp)
    ) {
        echo "<script>
            alert('Harap lengkapi seluruh data pengiriman dan metode pembayaran!');
        </script>";
    } else {

        $is_jakarta = (
            strpos(strtolower($kota_tujuan), 'jakarta') !== false &&
            strpos(strtolower($kota_tujuan), 'luar') === false
        );

        $ongkir = $is_jakarta ? 10000 : 25000;
        
        $diskon = 0;
        if (!empty($kode_voucher) && strtoupper($kode_voucher) === 'SKYBSHEBAT') {
            $diskon = 0.30 * $harga_buku;
        }

        $total_final = ($harga_buku - $diskon) + $ongkir;

        $bukti = '';

        if ($metode === 'COD') {
            $status_pesanan = 'Diproses';
            $status_pembayaran = 'COD';
        } else {
            $status_pesanan = 'Menunggu Konfirmasi';
            $status_pembayaran = 'Menunggu Verifikasi';

            if (
                !isset($_FILES['bukti']) ||
                $_FILES['bukti']['error'] !== UPLOAD_ERR_OK
            ) {
                echo "<script>
                    alert('Silakan upload bukti transfer terlebih dahulu!');
                </script>";
                exit;
            }

            $allowed_ext = ['jpg', 'jpeg', 'png', 'webp'];
            $ext = strtolower(
                pathinfo(
                    $_FILES['bukti']['name'],
                    PATHINFO_EXTENSION
                )
            );

            if (!in_array($ext, $allowed_ext)) {
                echo "<script>
                    alert('Format bukti transfer harus JPG, JPEG, PNG, atau WEBP!');
                </script>";
                exit;
            }

            if ($_FILES['bukti']['size'] > 5 * 1024 * 1024) {
                echo "<script>
                    alert('Ukuran bukti transfer maksimal 5 MB!');
                </script>";
                exit;
            }

            if (!is_dir("img/bukti")) {
                mkdir("img/bukti", 0777, true);
            }

            $bukti = "bukti_war_" .
                time() . "_" .
                rand(1000, 9999) . "." . $ext;

            $upload_path = "img/bukti/" . $bukti;

            if (!move_uploaded_file(
                $_FILES['bukti']['tmp_name'],
                $upload_path
            )) {
                echo "<script>
                    alert('Bukti transfer gagal diupload!');
                </script>";
                exit;
            }
        }

        $kode_pesanan = "SKYBS-WARORD-" .
            date("Ymd") . "-" .
            rand(1000, 9999);

        mysqli_begin_transaction($conn);

        try {
            $full_address =
                "[War Tiket: $kode_tiket] " .
                "[Kota: $kota_tujuan] " .
                $alamat_pengiriman;

            $stmt_ins_p = mysqli_prepare($conn, "
                INSERT INTO pesanan
                (
                    kode_pesanan,
                    id_user,
                    total_harga,
                    metode_pembayaran,
                    status,
                    alamat_pengiriman,
                    tanggal
                )
                VALUES (?, ?, ?, ?, ?, ?, NOW())
            ");

            if (!$stmt_ins_p) {
                throw new Exception("Gagal menyiapkan pesanan: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param(
                $stmt_ins_p,
                "sidsss",
                $kode_pesanan,
                $id_user,
                $total_final,
                $metode,
                $status_pesanan,
                $full_address
            );

            if (!mysqli_stmt_execute($stmt_ins_p)) {
                throw new Exception("Gagal menyimpan pesanan: " . mysqli_stmt_error($stmt_ins_p));
            }

            $id_pesanan = mysqli_insert_id($conn);

            $stmt_det = mysqli_prepare($conn, "
                INSERT INTO detail_pesanan
                (
                    id_pesanan,
                    id_buku,
                    jumlah,
                    harga,
                    subtotal
                )
                VALUES (?, ?, 1, ?, ?)
            ");

            if (!$stmt_det) {
                throw new Exception("Gagal menyiapkan detail pesanan: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param(
                $stmt_det,
                "iidd",
                $id_pesanan,
                $buku_id,
                $harga_buku,
                $harga_buku
            );

            if (!mysqli_stmt_execute($stmt_det)) {
                throw new Exception("Gagal menyimpan detail pesanan: " . mysqli_stmt_error($stmt_det));
            }

            $stmt_pay = mysqli_prepare($conn, "
                INSERT INTO pembayaran
                (
                    id_pesanan,
                    metode,
                    bukti,
                    status
                )
                VALUES (?, ?, ?, ?)
            ");

            if (!$stmt_pay) {
                throw new Exception("Gagal menyiapkan pembayaran: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param(
                $stmt_pay,
                "isss",
                $id_pesanan,
                $metode,
                $bukti,
                $status_pembayaran
            );

            if (!mysqli_stmt_execute($stmt_pay)) {
                throw new Exception("Gagal menyimpan pembayaran: " . mysqli_stmt_error($stmt_pay));
            }

            $pesan_notif =
                "Pesanan War Tiket " .
                $kode_pesanan .
                " (" .
                $buku_info['judul'] .
                ") berhasil dibuat. Silakan tunggu konfirmasi admin.";

            $stmt_notif = mysqli_prepare($conn, "
                INSERT INTO notifikasi
                (
                    id_user,
                    pesan,
                    status
                )
                VALUES (?, ?, 'Belum Dibaca')
            ");

            if (!$stmt_notif) {
                throw new Exception("Gagal menyiapkan notifikasi: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param(
                $stmt_notif,
                "is",
                $id_user,
                $pesan_notif
            );

            if (!mysqli_stmt_execute($stmt_notif)) {
                throw new Exception("Gagal menyimpan notifikasi: " . mysqli_stmt_error($stmt_notif));
            }

            $cek_kolom_status = mysqli_query(
                $conn,
                "SHOW COLUMNS FROM transaksi LIKE 'status'"
            );

            if (
                $cek_kolom_status &&
                mysqli_num_rows($cek_kolom_status) > 0
            ) {
                $stmt_status = mysqli_prepare($conn, "
                    UPDATE transaksi
                    SET status = 'Checkout Selesai'
                    WHERE id_transaksi = ?
                      AND id_user = ?
                ");

                if ($stmt_status) {
                    mysqli_stmt_bind_param(
                        $stmt_status,
                        "ii",
                        $id_transaksi,
                        $id_user
                    );

                    if (!mysqli_stmt_execute($stmt_status)) {
                        throw new Exception("Gagal memperbarui status tiket: " . mysqli_stmt_error($stmt_status));
                    }
                }
            }

            mysqli_commit($conn);

            echo "<script>
                alert('Pembayaran War Tiket berhasil diproses! Kode Pesanan: " .
                addslashes($kode_pesanan) . "');
                window.location='history.php';
            </script>";

            exit;

        } catch (Exception $e) {
            mysqli_rollback($conn);

            echo "<script>
                alert('Checkout gagal: " .
                addslashes($e->getMessage()) . "');
            </script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout War Tiket | SKY BookStore</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --shadow-md: 0 10px 25px rgba(78, 34, 15, 0.08);
            --radius-lg: 20px;
        }

        * { box-sizing: border-box; }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }

        h1, h2, h3, h4, h5, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        .navbar-custom {
            background: var(--brand-dark-brown);
            padding: 14px 0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }

        .navbar-brand {
            color: #FFFFFF !important;
            font-weight: 800;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .navbar-brand i { color: #FFC107; }

        .card-custom {
            background: #FFFFFF;
            border: 1px solid rgba(78, 34, 15, 0.08);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
        }

        .book-cover {
            width: 70px;
            height: 95px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            background: #eee;
        }

        .form-control-custom, .form-select-custom {
            background: var(--brand-cream-bg);
            border: 1px solid rgba(78, 34, 15, 0.15);
            border-radius: 12px;
            padding: 10px 16px;
            font-size: 14px;
            color: var(--brand-dark-brown);
        }

        .form-control-custom:focus, .form-select-custom:focus {
            background: #FFFFFF;
            border-color: var(--brand-warm-brown);
            box-shadow: 0 0 0 4px rgba(157, 102, 56, 0.15);
            color: var(--brand-dark-brown);
        }

        .btn-checkout {
            background: var(--brand-warm-brown);
            color: #FFFFFF;
            border: none;
            border-radius: 50px;
            padding: 14px;
            font-weight: 700;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .btn-checkout:hover {
            background: var(--brand-dark-brown);
            color: #FFFFFF;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(78, 34, 15, 0.2);
        }

        footer {
            background: var(--brand-dark-brown);
            color: var(--brand-cream-bg);
            padding: 30px 0;
            margin-top: 80px;
            border-top: 4px solid var(--brand-warm-brown);
        }

        .price-box {
            background: #FCFAF3;
            border-radius: 14px;
            padding: 16px;
        }

        .badge-war {
            background: var(--brand-dark-brown);
            color: #FFC107;
            font-size: 11px;
            letter-spacing: .4px;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-custom sticky-top">
        <div class="container d-flex justify-content-between align-items-center">
            <a href="index.php" class="navbar-brand text-decoration-none">
                <i class="fa-solid fa-book-open me-1"></i>
                <span>SKY Bookstore</span>
            </a>
            <a href="myticket.php" class="btn btn-sm btn-outline-light rounded-pill px-3">
                <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Tiket Saya
            </a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="mb-4">
            <h2 class="font-heading fw-bold mb-1">
                <i class="fa-solid fa-bolt text-warning me-2"></i>Checkout Edisi War Tiket
            </h2>
            <p class="text-muted">Selesaikan pembayaran untuk mengamankan buku eksklusif hasil kemenangan War Tiket Anda.</p>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <div class="row g-4">
                <div class="col-lg-7">
                    <div class="card-custom p-4 mb-4">
                        <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3">
                            <h5 class="font-heading fw-bold m-0">
                                <i class="fa-solid fa-ticket me-2 text-warning"></i>Detail Tiket Eksklusif
                            </h5>
                            <span class="badge badge-war fw-bold px-3 py-2">
                                <?= htmlspecialchars($kode_tiket); ?>
                            </span>
                        </div>

                        <div class="d-flex align-items-center gap-3 mb-4">
                            <?php
                            $cover_buku_war = "img/war/" . ltrim($buku_info['cover'] ?? '', '/');
                            if (empty($buku_info['cover']) || !file_exists($cover_buku_war)) {$cover_buku_war = "https://via.placeholder.com/70x95?text=No+Cover";
                            }
                            ?>
                            <img src="<?= htmlspecialchars($cover_buku_war); ?>" alt="Cover Buku" class="book-cover" onerror="this.src='https://via.placeholder.com/70x95?text=No+Cover'">
                            <div>
                                <span class="badge bg-warning text-dark mb-1" style="font-size: 10px;">Eksklusif War</span>
                                <h4 class="fw-bold mb-1"><?= htmlspecialchars($buku_info['judul']); ?></h4>
                                <small class="text-muted">
                                    <i class="fa-solid fa-pen-nib me-1"></i><?= htmlspecialchars($buku_info['penulis']); ?>
                                </small>
                            </div>
                        </div>

                        <div class="price-box border-top pt-3">
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted">Harga Buku War</span>
                                <span class="fw-bold">Rp <?= number_format($harga_buku, 0, ",", "."); ?></span>
                            </div>

                            <div class="d-flex justify-content-between mb-2" id="rowDiskon" style="display: none !important;">
                                <span class="text-success fw-bold">Diskon Voucher (30%)</span>
                                <span class="fw-bold text-success" id="textDiskon">- Rp 0</span>
                            </div>

                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted">Ongkos Kirim (Dikirim dari Jakarta)</span>
                                <span class="fw-bold text-primary" id="textOngkir">Pilih Wilayah...</span>
                            </div>

                            <hr>

                            <div class="d-flex justify-content-between align-items-center">
                                <span class="font-heading fw-bold fs-5">Total Pembayaran</span>
                                <span class="fw-bold fs-4 text-danger" id="textTotal">Rp <?= number_format($harga_buku, 0, ",", "."); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-5">
                    <div class="card-custom p-4">
                        <h5 class="font-heading fw-bold mb-3 border-bottom pb-2">
                            <i class="fa-solid fa-truck-fast me-2" style="color: var(--brand-warm-brown);"></i>Informasi Pengiriman
                        </h5>

                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">No. WhatsApp / HP</label>
                            <input type="text" name="no_hp" class="form-control form-control-custom" value="<?= htmlspecialchars($data_user['no_hp'] ?? ''); ?>" placeholder="Contoh: 081234567890" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">Kota / Wilayah Tujuan</label>
                            <select name="kota_tujuan" id="selectKota" class="form-select form-select-custom" onchange="hitungTotal()" required>
                                <option value="">-- Pilih Kota Tujuan --</option>
                                <option value="Jakarta Pusat">Jakarta Pusat (Flat Rp 10.000)</option>
                                <option value="Jakarta Selatan">Jakarta Selatan (Flat Rp 10.000)</option>
                                <option value="Jakarta Barat">Jakarta Barat (Flat Rp 10.000)</option>
                                <option value="Jakarta Timur">Jakarta Timur (Flat Rp 10.000)</option>
                                <option value="Jakarta Utara">Jakarta Utara (Flat Rp 10.000)</option>
                                <option value="Luar Jakarta">Luar Jakarta / Lainnya (Rp 25.000)</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">Alamat Lengkap Pengiriman</label>
                            <textarea name="alamat_pengiriman" class="form-control form-control-custom" rows="3" placeholder="Masukkan jalan, RT/RW, kecamatan, dan kode pos" required><?= htmlspecialchars($data_user['alamat'] ?? ''); ?></textarea>
                        </div>

                        <div class="mt-4 pt-3 border-top">
                            <label class="form-label small fw-bold text-muted">Punya Kode Voucher / Ingin Tantangan Diskon?</label>
                            <?php if ($sudah_pernah_pakai): ?>
                                <div class="alert alert-warning py-2 small mb-0">
                                    <i class="fa-solid fa-circle-exclamation me-1"></i> Voucher tidak dapat digunakan lagi.
                                </div>
                            <?php else: ?>
                                <div class="input-group mb-2">
                                    <input type="text" id="inputVoucherCode" name="kode_voucher" class="form-control form-control-custom" placeholder="Masukkan kode voucher...">
                                    <button type="button" onclick="prosesVoucher()" class="btn btn-dark px-4 fw-bold" style="background: var(--brand-dark-brown);">Gunakan</button>
                                </div>
                                <div class="form-text text-muted" style="font-size: 11px;">
                                    💡 Coba masukkan <strong class="text-dark">`SKYBSHEBAT`</strong> untuk diskon 30%!
                                </div>
                            <?php endif; ?>
                        </div>

                        <h5 class="font-heading fw-bold my-3 border-bottom pb-2">
                            <i class="fa-solid fa-wallet me-2" style="color: var(--brand-warm-brown);"></i>Metode Pembayaran
                        </h5>

                        <div class="mb-3">
                            <select name="metode" class="form-select form-select-custom" required>
                                <option value="">-- Pilih Metode Pembayaran --</option>
                                <optgroup label="Transfer Bank">
                                    <option value="BCA">Bank BCA (123-456-7890 a/n SKYBS)</option>
                                    <option value="BRI">Bank BRI (099-745-4321 a/n SKYBS)</option>
                                    <option value="Mandiri">Bank Mandiri (112-000-888 a/n SKYBS)</option>
                                </optgroup>
                                <optgroup label="E-Wallet & QRIS">
                                    <option value="DANA">DANA (085891403949)</option>
                                    <option value="GoPay">GoPay (085891403949)</option>
                                    <option value="QRIS">QRIS All Payment</option>
                                </optgroup>
                                <optgroup label="Lainnya">
                                    <option value="COD">COD (Bayar di Tempat)</option>
                                </optgroup>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label class="form-label small fw-bold text-muted">Upload Bukti Transfer</label>
                            <input type="file" name="bukti" class="form-control form-control-custom" accept="image/*">
                            <div class="form-text text-muted small" style="font-size: 11px;">*Wajib untuk pembayaran selain COD.</div>
                        </div>

                        <button type="submit" name="checkout_war" class="btn btn-checkout w-100 shadow-sm">
                            <i class="fa-solid fa-paper-plane me-2"></i> Selesaikan Pembayaran War
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <footer>
        <div class="container text-center">
            <small>&copy; <?= date('Y'); ?> SKY Bookstore. All Rights Reserved.</small>
        </div>
    </footer>

    <script>
        const hargaBuku = <?= (int)$harga_buku; ?>;
        let diskonVoucher = 0;

        function prosesVoucher() {
            const kode = document.getElementById("inputVoucherCode").value.trim().toUpperCase();
            if (kode === "SKYBSHEBAT") {
                diskonVoucher = hargaBuku * 0.30;
                alert("Voucher berhasil digunakan! Anda mendapatkan diskon 30%.");
                document.getElementById("rowDiskon").style.display = "flex";
                document.getElementById("textDiskon").innerText = "- Rp " + diskonVoucher.toLocaleString("id-ID");
            } else {
                diskonVoucher = 0;
                alert("Kode voucher tidak valid atau sudah kadaluarsa!");
                document.getElementById("rowDiskon").style.display = "none";
            }
            hitungTotal();
        }

        function hitungTotal() {
            const selectKota = document.getElementById("selectKota").value;
            const textOngkir = document.getElementById("textOngkir");
            const textTotal = document.getElementById("textTotal");
            let ongkir = 0;

            if (selectKota === "") {
                textOngkir.innerText = "Pilih Wilayah...";
                ongkir = 0;
            } else if (
                selectKota.toLowerCase().includes("jakarta") &&
                !selectKota.toLowerCase().includes("luar")
            ) {
                ongkir = 10000;
                textOngkir.innerText = "Rp 10.000 (Flat Jakarta)";
            } else {
                ongkir = 25000;
                textOngkir.innerText = "Rp 25.000 (Luar Jakarta)";
            }

            const totalFinal = (hargaBuku - diskonVoucher) + ongkir;
            textTotal.innerText = "Rp " + totalFinal.toLocaleString("id-ID");
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>