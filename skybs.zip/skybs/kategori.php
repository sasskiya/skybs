<?php
session_start();
include "database.php";

$cari = isset($_GET['cari']) ? trim(mysqli_real_escape_string($conn, $_GET['cari'])) : "";
$id   = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    $stmt_kat = mysqli_prepare($conn, "SELECT nama_kategori FROM kategori WHERE id_kategori = ?");
    mysqli_stmt_bind_param($stmt_kat, "i", $id);
    mysqli_stmt_execute($stmt_kat);
    $res_kat = mysqli_stmt_get_result($stmt_kat);
    $kategori = mysqli_fetch_assoc($res_kat);

    $judul = $kategori ? "Kategori: " . htmlspecialchars($kategori['nama_kategori']) : "Kategori Tidak Ditemukan";

    $stmt_buku = mysqli_prepare($conn, "
        SELECT buku.*, kategori.nama_kategori 
        FROM buku 
        LEFT JOIN kategori ON buku.id_kategori = kategori.id_kategori 
        WHERE buku.id_kategori = ? 
        ORDER BY buku.judul ASC
    ");
    mysqli_stmt_bind_param($stmt_buku, "i", $id);
    mysqli_stmt_execute($stmt_buku);
    $buku = mysqli_stmt_get_result($stmt_buku);

} else {
    $judul = !empty($cari) ? "Hasil Pencarian: \"" . htmlspecialchars($cari) . "\"" : "Semua Koleksi Buku";

    $stmt_buku = mysqli_prepare($conn, "
        SELECT buku.*, kategori.nama_kategori 
        FROM buku 
        LEFT JOIN kategori ON buku.id_kategori = kategori.id_kategori 
        WHERE buku.judul LIKE ? 
           OR buku.penulis LIKE ? 
           OR buku.deskripsi LIKE ? 
           OR kategori.nama_kategori LIKE ? 
           OR buku.badge LIKE ? 
        ORDER BY buku.judul ASC
    ");
    $searchTerm = "%" . $cari . "%";
    mysqli_stmt_bind_param($stmt_buku, "sssss", $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm);
    mysqli_stmt_execute($stmt_buku);
    $buku = mysqli_stmt_get_result($stmt_buku);
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= filter_var($judul, FILTER_SANITIZE_FULL_SPECIAL_CHARS); ?> | SKY BookStore</title>

    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --shadow-sm: 0 4px 18px rgba(78, 34, 15, 0.04);
            --shadow-md: 0 10px 25px rgba(78, 34, 15, 0.08);
            --radius-md: 16px;
            --radius-lg: 20px;
        }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }

        h1, h2, h3, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        /* --- NAVBAR --- */
        .navbar-custom {
            background: var(--brand-dark-brown);
            padding: 14px 0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }

        .navbar-brand {
            color: #FFFFFF !important;
            font-weight: 800;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .navbar-brand img {
            max-height: 40px;
            width: auto;
            object-fit: contain;
            border-radius: 6px;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.85) !important;
            margin: 0 8px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.2s ease;
        }

        .nav-link:hover, .nav-link.active {
            color: #FFFFFF !important;
        }

        .search-box {
            border-radius: 50px 0 0 50px;
            border: 1px solid rgba(78, 34, 15, 0.15);
            border-right: none;
            padding: 8px 18px;
            font-size: 14px;
            background: #FFFFFF;
            color: var(--brand-dark-brown);
        }

        .search-box:focus {
            outline: none;
            box-shadow: none;
        }

        .search-btn {
            border-radius: 0 50px 50px 0;
            border: none;
            background: var(--brand-warm-brown);
            color: white;
            padding: 0 20px;
            transition: background 0.2s ease;
        }

        .search-btn:hover {
            background: var(--brand-dark-brown);
            color: white;
        }

        /* --- BOOK CARDS --- */
        .book-card {
            background: #FFFFFF;
            border: 1px solid rgba(78, 34, 15, 0.08);
            border-radius: var(--radius-lg);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .book-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-md);
        }

        .book-cover-container {
            position: relative;
            height: 280px;
            overflow: hidden;
            background: var(--brand-cream-bg);
        }

        .book-cover-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .book-card:hover .book-cover-container img {
            transform: scale(1.05);
        }

        .badge-book {
            position: absolute;
            top: 12px;
            left: 12px;
            padding: 6px 14px;
            border-radius: 50px;
            font-size: 11px;
            font-weight: 700;
            background: var(--brand-warm-brown);
            color: white;
            box-shadow: 0 4px 10px rgba(78, 34, 15, 0.15);
        }

        .price-text {
            font-size: 18px;
            font-weight: 800;
            color: var(--brand-warm-brown);
        }

        .rating-stars {
            color: #FFB800;
            font-size: 13px;
        }

        .btn-action-primary {
            background: var(--brand-warm-brown);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 8px 16px;
            font-size: 13px;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        .btn-action-primary:hover {
            background: var(--brand-dark-brown);
            color: white;
        }

        /* --- FOOTER --- */
        footer {
            background: var(--brand-dark-brown);
            color: var(--brand-cream-bg);
            padding: 40px 0 25px;
            margin-top: 80px;
            border-top: 4px solid var(--brand-warm-brown);
        }
    </style>
</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-custom sticky-top">
        <div class="container">
            <!-- LOGO KIRI -->
            <a class="navbar-brand" href="index.php">
                <img src="assets/img/logo.png" alt="SKYBS Logo" onerror="this.style.display='none'; document.getElementById('fallback-icon').style.display='inline-block';">
                <i id="fallback-icon" class="fa-solid fa-book-open text-warning me-1" style="display:none;"></i>
                <span>SKYBS BookStore</span>
            </a>

            <button class="navbar-toggler border-0 text-white shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
                <i class="fa-solid fa-bars-staggered"></i>
            </button>

            <div class="collapse navbar-collapse" id="menu">
                <ul class="navbar-nav ms-auto align-items-lg-center">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link active" href="kategori.php">Kategori</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>

                    <li class="nav-item ms-lg-2">
                        <a class="nav-link" href="wishlist.php" title="Wishlist Saya">
                            <i class="fa-regular fa-heart fs-5"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="keranjang.php" title="Keranjang Belanja">
                            <i class="fa-solid fa-cart-shopping fs-5"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="history.php" title="Riwayat Pesanan">
                            <i class="fa-solid fa-clock-rotate-left fs-5"></i>
                        </a>
                    </li>
                </ul>

                <!-- FORM PENCARIAN -->
                <form class="d-flex ms-lg-3 mt-3 mt-lg-0" method="GET" action="kategori.php">
                    <input type="search" name="cari" class="form-control search-box" placeholder="Cari buku..." value="<?= htmlspecialchars($cari); ?>" required>
                    <button class="btn search-btn" type="submit">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </form>
            </div>
        </div>
    </nav>

    <!-- CONTENT CONTAINER -->
    <div class="container py-5">

        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <h2 class="font-heading fw-bold mb-1" style="color: var(--brand-dark-brown);"><?= filter_var($judul, FILTER_SANITIZE_FULL_SPECIAL_CHARS); ?></h2>
                <p class="text-muted mb-0">Menampilkan daftar koleksi buku terkonfirmasi yang tersedia di SKYBS</p>
            </div>
            <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4 btn-sm fw-semibold">
                <i class="fa-solid fa-arrow-left me-2"></i>Kembali ke Beranda
            </a>
        </div>

        <div class="row g-4">
            <?php if (mysqli_num_rows($buku) > 0): ?>
                <?php while ($bk = mysqli_fetch_assoc($buku)): ?>
                    <?php
                    $path_cover = "img/buku/" . $bk['cover'];
                    $img_src = (!empty($bk['cover']) && file_exists($path_cover)) ? $path_cover : "https://via.placeholder.com/280x380?text=No+Cover";
                    ?>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="book-card">
                            <div class="book-cover-container">
                                <?php if (!empty($bk['badge'])): ?>
                                    <span class="badge badge-book"><?= htmlspecialchars($bk['badge']); ?></span>
                                <?php endif; ?>
                                <img src="<?= $img_src; ?>" alt="<?= htmlspecialchars($bk['judul']); ?>">
                            </div>

                            <div class="p-3 d-flex flex-column flex-grow-1">
                                <small class="text-muted fw-bold mb-1 text-uppercase" style="font-size: 11px;">
                                    <?= htmlspecialchars($bk['nama_kategori'] ?? 'Umum'); ?>
                                </small>
                                <h6 class="fw-bold text-truncate mb-1" title="<?= htmlspecialchars($bk['judul']); ?>" style="color: var(--brand-dark-brown);">
                                    <?= htmlspecialchars($bk['judul']); ?>
                                </h6>
                                <small class="text-muted mb-2 text-truncate">
                                    <i class="fa-solid fa-pen-nib me-1" style="color: var(--brand-warm-brown);"></i><?= htmlspecialchars($bk['penulis'] ?? 'Anonim'); ?>
                                </small>

                                <div class="rating-stars mb-2">
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star-half-stroke"></i>
                                    <span class="small ms-1 fw-bold" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($bk['rating'] ?? '5.0'); ?></span>
                                </div>

                                <div class="price-text mb-3 mt-auto">
                                    Rp <?= number_format($bk['harga'], 0, ",", "."); ?>
                                </div>

                                <div class="d-flex gap-2">
                                    <a href="detail.php?id=<?= $bk['id_buku']; ?>" class="btn btn-action-primary flex-grow-1 text-center">
                                        Detail
                                    </a>
                                    <a href="wishlist.php?id=<?= $bk['id_buku']; ?>" class="btn btn-outline-danger rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;" title="Tambah Wishlist">
                                        <i class="fa-regular fa-heart"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 text-center py-5">
                    <i class="fa-solid fa-book-open fs-1 text-muted opacity-50 mb-3 d-block"></i>
                    <h5 class="font-heading fw-bold mb-1" style="color: var(--brand-dark-brown);">Buku Tidak Ditemukan</h5>
                    <p class="text-muted small mb-4">Maaf, kami tidak menemukan buku pada kategori atau kata kunci pencarian tersebut.</p>
                    <a href="index.php" class="btn btn-sm btn-sage rounded-pill px-4" style="background: var(--brand-warm-brown); color: white;">Lihat Semua Buku</a>
                </div>
            <?php endif; ?>
        </div>

    </div>

    <!-- FOOTER -->
    <footer class="text-center">
        <div class="container">
            <h5 class="fw-bold mb-2">SKYBS BookStore</h5>
            <p class="small mb-0 opacity-75">&copy; <?= date("Y"); ?> SKY BookStore. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>