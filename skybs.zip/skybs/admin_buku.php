<?php
session_start();
include "database.php";

// =========================================
// 1. CEK HAK AKSES ADMIN
// =========================================
if (!isset($_SESSION['id_admin'])) {
    echo "<script>
        alert('Akses ditolak! Silakan login sebagai admin.');
        window.location='login.php';
    </script>";
    exit;
}

// Nama admin default
$nama_admin = isset($_SESSION['nama']) && !empty($_SESSION['nama'])
    ? $_SESSION['nama']
    : 'Saskiya';


// =========================================
// 2. PROSES HAPUS BUKU
// =========================================
if (isset($_GET['hapus'])) {

    $id_hapus = (int) $_GET['hapus'];

    // Pastikan hanya menghapus buku biasa (bukan war)
    $stmt_hapus = mysqli_prepare($conn, "
        DELETE FROM buku
        WHERE id_buku = ?
        AND (tipe_buku != 'war' OR tipe_buku IS NULL)
    ");

    mysqli_stmt_bind_param($stmt_hapus, "i", $id_hapus);

    if (mysqli_stmt_execute($stmt_hapus)) {

        echo "<script>
            alert('Buku berhasil dihapus!');
            window.location='admin_buku.php';
        </script>";
        exit;

    } else {

        echo "<script>
            alert('Gagal menghapus buku!');
            window.location='admin_buku.php';
        </script>";
        exit;
    }
}


// =========================================
// 3. PROSES UPDATE BUKU
// =========================================
if (isset($_POST['update_buku'])) {

    $id_buku   = (int) $_POST['id_buku'];
    $id_kategori = (int) $_POST['id_kategori'];
    $judul     = trim($_POST['judul']);
    $penulis   = trim($_POST['penulis']);
    $harga     = (double) $_POST['harga'];
    $rating    = trim($_POST['rating']);
    $stok      = (int) $_POST['stok'];
    $badge     = trim($_POST['badge']);
    $deskripsi = trim($_POST['deskripsi']);

    // Pastikan buku yang diedit adalah buku biasa (bukan war)
    $cek_buku = mysqli_query(
        $conn,
        "SELECT id_buku FROM buku
         WHERE id_buku = $id_buku
         AND (tipe_buku != 'war' OR tipe_buku IS NULL)"
    );

    if (mysqli_num_rows($cek_buku) == 0) {

        echo "<script>
            alert('Buku tidak ditemukan atau bukan buku biasa!');
            window.location='admin_buku.php';
        </script>";
        exit;
    }


    // Ambil cover lama
    $query_cover = mysqli_query(
        $conn,
        "SELECT cover FROM buku WHERE id_buku = $id_buku"
    );

    $data_cover = mysqli_fetch_assoc($query_cover);

    $cover = $data_cover['cover'] ?? 'default.png';

    // =========================================
    // UPLOAD COVER BARU (OPSIONAL)
    // =========================================
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {

        $ext = strtolower(pathinfo($_FILES['cover']['name'], PATHINFO_EXTENSION));

        $allowed = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($ext, $allowed)) {

            $cover_baru = time() . "_" . rand(100, 999) . "." . $ext;

            $target_folder = "img/buku/";

            if (!is_dir($target_folder)) {
                mkdir($target_folder, 0777, true);
            }

            if (move_uploaded_file(
                $_FILES['cover']['tmp_name'],
                $target_folder . $cover_baru
            )) {

                $cover = $cover_baru;
            }
        }
    }

    // =========================================
    // UPDATE DATABASE
    // =========================================
    $cek_kolom_rating = mysqli_query($conn, "SHOW COLUMNS FROM buku LIKE 'rating'");
    if (mysqli_num_rows($cek_kolom_rating) > 0) {
        $stmt_update = mysqli_prepare($conn, "
            UPDATE buku SET
                id_kategori = ?,
                judul = ?,
                penulis = ?,
                harga = ?,
                rating = ?,
                stok = ?,
                badge = ?,
                cover = ?,
                deskripsi = ?
            WHERE id_buku = ?
            AND (tipe_buku != 'war' OR tipe_buku IS NULL)
        ");

        mysqli_stmt_bind_param(
            $stmt_update,
            "issdissssi",
            $id_kategori,
            $judul,
            $penulis,
            $harga,
            $rating,
            $stok,
            $badge,
            $cover,
            $deskripsi,
            $id_buku
        );
    } else {
        $stmt_update = mysqli_prepare($conn, "
            UPDATE buku SET
                id_kategori = ?,
                judul = ?,
                penulis = ?,
                harga = ?,
                stok = ?,
                badge = ?,
                cover = ?,
                deskripsi = ?
            WHERE id_buku = ?
            AND (tipe_buku != 'war' OR tipe_buku IS NULL)
        ");

        mysqli_stmt_bind_param(
            $stmt_update,
            "issdisssi",
            $id_kategori,
            $judul,
            $penulis,
            $harga,
            $stok,
            $badge,
            $cover,
            $deskripsi,
            $id_buku
        );
    }


    if (mysqli_stmt_execute($stmt_update)) {

        echo "<script>
            alert('Data buku berhasil diperbarui!');
            window.location='admin_buku.php';
        </script>";
        exit;

    } else {

        echo "<script>
            alert('Gagal memperbarui data buku!');
        </script>";
    }
}

// =========================================
// 4. FITUR PENCARIAN
// =========================================
$cari = "";

if (isset($_GET['cari'])) {
    $cari = trim($_GET['cari']);
}

// =========================================
// 5. QUERY HANYA BUKU BIASA (KECUALIKAN TIPE 'war')
// =========================================
if (!empty($cari)) {

    $stmt_cari = mysqli_prepare($conn, "
        SELECT buku.*, kategori.nama_kategori
        FROM buku
        LEFT JOIN kategori
            ON buku.id_kategori = kategori.id_kategori
        WHERE (buku.tipe_buku != 'war' OR buku.tipe_buku IS NULL)
        AND (
            buku.judul LIKE ?
            OR buku.penulis LIKE ?
            OR kategori.nama_kategori LIKE ?
        )
        ORDER BY buku.id_buku DESC
    ");

    $keyword = "%" . $cari . "%";

    mysqli_stmt_bind_param(
        $stmt_cari,
        "sss",
        $keyword,
        $keyword,
        $keyword
    );

    mysqli_stmt_execute($stmt_cari);

    $data = mysqli_stmt_get_result($stmt_cari);

} else {

   
$data = mysqli_query($conn, "
    SELECT buku.*, kategori.nama_kategori
    FROM buku
    LEFT JOIN kategori
        ON buku.id_kategori = kategori.id_kategori
    WHERE (buku.tipe_buku != 'war' OR buku.tipe_buku IS NULL)
    ORDER BY buku.id_buku DESC
");

if (!$data) {
    die("Gagal mengambil data buku: " . mysqli_error($conn));
}

}

// =========================================
// 6. AMBIL KATEGORI UNTUK MODAL EDIT
// =========================================
$kategori = mysqli_query(
    $conn,
    "SELECT * FROM kategori ORDER BY nama_kategori ASC"
);

$kategori_edit = [];

while ($k = mysqli_fetch_assoc($kategori)) {
    $kategori_edit[] = $k;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Data Buku | SKYBS Admin</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">


    <style>

        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --shadow-sm: 0 4px 18px rgba(78, 34, 15, 0.05);
            --radius-lg: 20px;
        }


        * {
            box-sizing: border-box;
        }


        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }


        h1, h2, h3, h4, h5, .font-heading {
            font-family: 'Playfair Display', serif;
        }


        /* --- SIDEBAR STYLING (Disamakan dengan admin.php) --- */
        .sidebar {
            width: 270px;
            height: 100vh;
            background: var(--brand-dark-brown);
            position: fixed;
            left: 0;
            top: 0;
            z-index: 100;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            display: flex;
            flex-direction: column;
        }


        .sidebar-brand {
            color: white;
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.12);
            display: flex;
            align-items: center;
            gap: 12px;
        }


        .brand-badge {
            background: rgba(176, 186, 153, 0.25);
            border: 1px solid var(--brand-sage-green);
            color: var(--brand-sage-green);
            padding: 2px 8px;
            border-radius: 6px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 700;
        }


        .sidebar-menu {
            padding: 20px 0;
            flex-grow: 1;
        }


        .sidebar a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            padding: 13px 25px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }


        .sidebar a i {
            width: 32px;
            font-size: 16px;
        }


        .sidebar a:hover,
        .sidebar a.active {
            background: rgba(255, 255, 255, 0.12);
            color: #FFFFFF;
            border-left-color: var(--brand-warm-brown);
        }


        .btn-view-website {
            margin: 18px 20px 0;
            padding: 12px 16px !important;
            border-radius: 10px;
            background: var(--brand-sage-green);
            color: var(--brand-dark-brown) !important;
            border: 1px solid var(--brand-sage-green) !important;
            font-weight: 700 !important;
            justify-content: center;
            transition: all 0.3s ease;
        }


        .btn-view-website:hover {
            background: #DCCFC0;
            color: var(--brand-dark-brown) !important;
            transform: translateY(-2px);
        }


        .btn-logout {
            background: rgba(220, 53, 69, 0.15);
            color: #FF6B6B;
            border: 1px solid rgba(220, 53, 69, 0.2);
            width: 100%;
            border-radius: 12px;
            padding: 10px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
        }


        .btn-logout:hover {
            background: #DC3545;
            color: white;
        }


        .content {
            margin-left: 270px;
            padding: 35px 40px;
        }


        .profile-badge {
            background: #FFFFFF;
            padding: 8px 18px;
            border-radius: 50px;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(78, 34, 15, 0.08);
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }


        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }


        .card-custom {
            background: #FFFFFF;
            border: none;
            border-radius: var(--radius-lg);
            box-shadow: 0 10px 25px rgba(78,34,15,0.07);
            overflow: hidden;
        }


        .card-header-custom {
            padding: 22px 25px;
            border-bottom: 1px solid #F0E8DF;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }


        .search-box {
            max-width: 400px;
        }


        .search-box .form-control {
            border-radius: 50px 0 0 50px;
            border: 1px solid #E5D8CC;
            padding: 12px 18px;
        }


        .search-box .btn {
            border-radius: 0 50px 50px 0;
            background: var(--brand-dark-brown);
            color: white;
            border: none;
            padding: 0 20px;
        }


        .table thead {
            background: var(--brand-dark-brown);
            color: white;
        }


        .table thead th {
            font-size: 12px;
            text-transform: uppercase;
            font-weight: 700;
            letter-spacing: 0.5px;
            padding: 17px 15px;
            white-space: nowrap;
        }


        .table tbody td {
            padding: 16px 15px;
            vertical-align: middle;
            border-bottom: 1px solid #F4EEE8;
        }


        .table tbody tr:hover {
            background: #FFFDF9;
        }


        .book-cover {
            width: 58px;
            height: 82px;
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 3px 8px rgba(0,0,0,0.12);
        }


        .badge-custom {
            background: #EED9C5;
            color: var(--brand-dark-brown);
            border-radius: 20px;
            padding: 6px 10px;
            font-size: 11px;
            font-weight: 700;
        }


        .btn-add {
            background: var(--brand-warm-brown);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 11px 20px;
            font-weight: 700;
        }


        .btn-add:hover {
            background: var(--brand-dark-brown);
            color: white;
        }


        .btn-edit {
            background: #F4E6B7;
            color: #72551A;
            border: none;
        }


        .btn-edit:hover {
            background: #E9D695;
            color: #5D4312;
        }


        .modal-content {
            border: none;
            border-radius: 20px;
            overflow: hidden;
        }


        .modal-header {
            background: var(--brand-dark-brown);
            color: white;
        }


        .modal-header .btn-close {
            filter: brightness(0) invert(1);
        }


        .form-control,
        .form-select {
            border-radius: 10px;
            padding: 10px 12px;
            border: 1px solid #E6DCD1;
        }


        .form-control:focus,
        .form-select:focus {
            border-color: var(--brand-warm-brown);
            box-shadow: 0 0 0 3px rgba(157,102,56,0.12);
        }


        @media (max-width: 992px) {

            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .content {
                margin-left: 0;
                padding: 20px;
            }

            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

        }

    </style>

</head>


<body>
<!-- =========================================
     SIDEBAR NAVIGATION (Disamakan dengan admin.php)
========================================= -->
<div class="sidebar">
    <div class="sidebar-brand">
        <i class="fa-solid fa-book-open text-warning fs-4"></i>
        <div>
            <h5 class="fw-bold mb-0 text-white">SKYBS Admin</h5>
            <span class="brand-badge">Panel System</span>
        </div>
    </div>

    <div class="sidebar-menu">
        <a href="admin.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
        <a href="admin_kategori.php"><i class="fa-solid fa-tags"></i> Kategori Buku</a>
        <a href="admin_buku.php" class="active"><i class="fa-solid fa-book"></i> Data Buku</a>
        <a href="admin_user.php"><i class="fa-solid fa-users"></i> Data User</a>
        <a href="admin_pesanan.php"><i class="fa-solid fa-cart-shopping"></i> Pesanan</a>
        <a href="admin_war.php"><i class="fa-solid fa-ticket"></i> War Tiket</a>
        <a href="admin_contact.php"><i class="fa-solid fa-comments"></i> Pesan User</a>

        <a href="index.php" target="_blank" class="btn-view-website">
            <i class="fa-solid fa-eye"></i> Buka Full Website
        </a>
    </div>

    <div class="p-3">
        <form action="logout.php" method="POST">
            <button type="submit" class="btn btn-logout d-flex align-items-center justify-content-center gap-2" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
            </button>
        </form>
    </div>
</div>

<!-- =========================================
     CONTENT AREA
========================================= -->
<div class="content">

    <!-- HEADER TOPBAR -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 pb-3 border-bottom border-secondary-subtle">
        <div>
            <h2 class="font-heading fw-bold mb-1">Data Buku Biasa</h2>
            <p class="text-muted mb-0">Kelola seluruh koleksi buku reguler SKY Bookstore</p>
        </div>
        <div>
            <div class="profile-badge">
                <i class="fa-solid fa-user-gear fs-5" style="color: var(--brand-warm-brown);"></i>
                <span class="fw-bold fs-6" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($nama_admin); ?> (Admin)</span>
            </div>
        </div>
    </div>

    <!-- PAGE HEADER BUTTON -->
    <div class="page-header">
        <div>
            <h5 class="text-muted mb-0">Pencarian & Kelola Buku</h5>
        </div>
        <a href="tambah_buku.php" class="btn btn-add">
            <i class="fa-solid fa-plus me-2"></i>Tambah Buku
        </a>
    </div>


    <!-- SEARCH -->
    <div class="card-custom mb-4">
        <div class="p-4">
            <form method="GET" class="d-flex search-box">
                <input type="text"
                       name="cari"
                       class="form-control"
                       placeholder="Cari judul, penulis, atau kategori..."
                       value="<?= htmlspecialchars($cari); ?>">
                <button type="submit" class="btn">
                    <i class="fa-solid fa-search"></i>
                </button>
            </form>
        </div>
    </div>


    <!-- TABLE DATA BUKU -->
    <div class="card-custom">
        <div class="card-header-custom">
            <div>
                <h5 class="fw-bold mb-1">Koleksi Buku Biasa</h5>
                <small class="text-muted">Buku War Eksklusif tidak ditampilkan di halaman ini.</small>
            </div>
            <span class="badge bg-success rounded-pill px-3 py-2">
                REGULER
            </span>
        </div>


        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead>
                    <tr>
                        <th class="ps-4">No</th>
                        <th>Cover</th>
                        <th>Informasi Buku</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Badge</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($data && mysqli_num_rows($data) > 0): ?>
                        <?php
                        $no = 1;
                        while ($buku = mysqli_fetch_assoc($data)):
                        ?>
                            <tr>
                                <!-- NOMOR -->
                                <td class="ps-4 fw-bold text-muted">
                                    <?= $no++; ?>
                                </td>

                                <!-- COVER -->
                                <td>
                                    <img src="img/buku/<?= htmlspecialchars($buku['cover']); ?>"
                                         class="book-cover"
                                         alt="<?= htmlspecialchars($buku['judul']); ?>"
                                         onerror="this.src='img/buku/default.png'">
                                </td>

                                <!-- INFORMASI -->
                                <td>
                                    <div class="fw-bold mb-1">
                                        <?= htmlspecialchars($buku['judul']); ?>
                                    </div>
                                    <small class="text-muted">
                                        <?= htmlspecialchars($buku['penulis']); ?>
                                    </small>
                                    <br>
                                    <small class="text-muted">
                                        Rating:
                                        <span class="text-warning">
                                            <i class="fa-solid fa-star"></i>
                                        </span>
                                        <?= htmlspecialchars($buku['rating'] ?? '4.5'); ?>
                                    </small>
                                </td>

                                <!-- KATEGORI -->
                                <td>
                                    <span class="badge-custom">
                                        <?= htmlspecialchars($buku['nama_kategori'] ?? 'Tanpa Kategori'); ?>
                                    </span>
                                </td>

                                <!-- HARGA -->
                                <td class="fw-bold text-success">
                                    Rp <?= number_format($buku['harga'], 0, ',', '.'); ?>
                                </td>

                                <!-- STOK -->
                                <td>
                                    <?php if ($buku['stok'] > 0): ?>
                                        <span class="badge bg-success-subtle text-success">
                                            <?= $buku['stok']; ?> tersedia
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger">
                                            Habis
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <!-- BADGE -->
                                <td>
                                    <?php if (!empty($buku['badge'])): ?>
                                        <span class="badge bg-warning-subtle text-dark">
                                            <?= htmlspecialchars($buku['badge']); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted small">-</span>
                                    <?php endif; ?>
                                </td>

                                <!-- AKSI -->
                                <td class="text-center">
                                    <div class="d-flex justify-content-center gap-2">
                                        <!-- EDIT -->
                                        <button type="button"
                                                class="btn btn-sm btn-edit rounded-pill px-3"
                                                data-bs-toggle="modal"
                                                data-bs-target="#editModal<?= $buku['id_buku']; ?>">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </button>

                                        <!-- HAPUS -->
                                        <a href="admin_buku.php?hapus=<?= $buku['id_buku']; ?>"
                                           class="btn btn-sm btn-outline-danger rounded-pill px-3"
                                           onclick="return confirm('Yakin ingin menghapus buku ini?')">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>



                            <!-- =========================================
                                 MODAL EDIT
                            ========================================= -->
                            <div class="modal fade"
                                 id="editModal<?= $buku['id_buku']; ?>"
                                 tabindex="-1"
                                 aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <form method="POST" enctype="multipart/form-data">
                                            <div class="modal-header">
                                                <h5 class="modal-title fw-bold">
                                                    <i class="fa-solid fa-pen-to-square me-2"></i>Edit Buku Biasa
                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>

                                            <div class="modal-body">
                                                <input type="hidden" name="id_buku" value="<?= $buku['id_buku']; ?>">

                                                <div class="row g-3">
                                                    <!-- KATEGORI -->
                                                    <div class="col-md-6">
                                                        <label class="form-label fw-semibold">Kategori</label>
                                                        <select name="id_kategori" class="form-select" required>
                                                            <?php foreach ($kategori_edit as $k): ?>
                                                                <option value="<?= $k['id_kategori']; ?>"
                                                                    <?= $buku['id_kategori'] == $k['id_kategori'] ? 'selected' : ''; ?>>
                                                                    <?= htmlspecialchars($k['nama_kategori']); ?>
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>

                                                    <!-- JUDUL -->
                                                    <div class="col-md-6">
                                                        <label class="form-label fw-semibold">Judul Buku</label>
                                                        <input type="text" name="judul" class="form-control" value="<?= htmlspecialchars($buku['judul']); ?>" required>
                                                    </div>

                                                    <!-- PENULIS -->
                                                    <div class="col-md-6">
                                                        <label class="form-label fw-semibold">Penulis</label>
                                                        <input type="text" name="penulis" class="form-control" value="<?= htmlspecialchars($buku['penulis']); ?>" required>
                                                    </div>

                                                    <!-- HARGA -->
                                                    <div class="col-md-3">
                                                        <label class="form-label fw-semibold">Harga</label>
                                                        <input type="number" name="harga" class="form-control" value="<?= (int)$buku['harga']; ?>" min="0" required>
                                                    </div>

                                                    <!-- STOK -->
                                                    <div class="col-md-3">
                                                        <label class="form-label fw-semibold">Stok</label>
                                                        <input type="number" name="stok" class="form-control" value="<?= $buku['stok']; ?>" min="0" required>
                                                    </div>

                                                    <!-- RATING -->
                                                    <div class="col-md-6">
                                                        <label class="form-label fw-semibold">Rating</label>
                                                        <input type="text" name="rating" class="form-control" value="<?= htmlspecialchars($buku['rating'] ?? '4.5'); ?>">
                                                    </div>

                                                    <!-- BADGE -->
                                                    <div class="col-md-6">
                                                        <label class="form-label fw-semibold">Badge</label>
                                                        <select name="badge" class="form-select">
                                                            <option value="" <?= empty($buku['badge']) ? 'selected' : ''; ?>>Tidak ada badge</option>
                                                            <option value="Bestseller" <?= $buku['badge'] === 'Bestseller' ? 'selected' : ''; ?>>Bestseller</option>
                                                            <option value="Baru" <?= $buku['badge'] === 'Baru' ? 'selected' : ''; ?>>Baru</option>
                                                            <option value="Pilihan Editor" <?= $buku['badge'] === 'Pilihan Editor' ? 'selected' : ''; ?>>Pilihan Editor</option>
                                                        </select>
                                                    </div>

                                                    <!-- COVER -->
                                                    <div class="col-md-12">
                                                        <label class="form-label fw-semibold">Ganti Cover (Opsional)</label>
                                                        <input type="file" name="cover" class="form-control" accept=".jpg,.jpeg,.png,.webp">
                                                        <small class="text-muted">Kosongkan jika tidak ingin mengganti cover.</small>
                                                    </div>

                                                    <!-- DESKRIPSI -->
                                                    <div class="col-md-12">
                                                        <label class="form-label fw-semibold">Deskripsi</label>
                                                        <textarea name="deskripsi" class="form-control" rows="4" required><?= htmlspecialchars($buku['deskripsi'] ?? ''); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" name="update_buku" class="btn btn-add rounded-pill px-4">
                                                    <i class="fa-solid fa-save me-2"></i>Simpan Perubahan
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-5">
                                <i class="fa-solid fa-book-open fs-1 text-muted mb-3 d-block opacity-50"></i>
                                <h5 class="fw-bold"><?= !empty($cari) ? 'Buku tidak ditemukan' : 'Belum ada buku biasa'; ?></h5>
                                <p class="text-muted">
                                    <?= !empty($cari) ? 'Coba gunakan kata kunci pencarian lain.' : 'Silakan tambahkan koleksi buku reguler baru.'; ?>
                                </p>
                                <?php if (empty($cari)): ?>
                                    <a href="tambah_buku.php" class="btn btn-add rounded-pill">
                                        <i class="fa-solid fa-plus me-2"></i>Tambah Buku
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <footer class="mt-5 text-center text-muted small">
        <p class="mb-0">&copy; <?= date("Y"); ?> <strong>SKY Bookstore</strong> - Admin Dashboard System.</p>
    </footer>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>