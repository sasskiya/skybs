<?php
session_start();
require_once "database.php";

// Cek Login Admin
if (!isset($_SESSION['id_admin'])) {
    header("Location: login.php");
    exit;
}

// Nama admin default
$nama_admin = isset($_SESSION['nama']) && !empty($_SESSION['nama'])
    ? $_SESSION['nama']
    : 'Saskiya';

// Proses Update Status Pesanan / Refund
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $id = (int) ($_POST['id_pesanan'] ?? 0);
    $status = trim($_POST['status'] ?? '');

    $status_valid = ["Menunggu Konfirmasi", "Diproses", "Dikirim", "Selesai", "Batal", "Refund"];

    if ($id <= 0 || !in_array($status, $status_valid, true)) {
        echo "<script>alert('Status tidak valid.'); location.href='admin_pesanan.php';</script>";
        exit;
    }

    $stmt = mysqli_prepare($conn, "UPDATE pesanan SET status = ? WHERE id_pesanan = ?");
    mysqli_stmt_bind_param($stmt, "si", $status, $id);

    if (mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        echo "<script>alert('Status pesanan berhasil diperbarui!'); location.href='admin_pesanan.php';</script>";
    } else {
        mysqli_stmt_close($stmt);
        echo "<script>alert('Gagal memperbarui status.'); location.href='admin_pesanan.php';</script>";
    }
    exit;
}

// Ambil Data Pesanan, Judul Buku, serta Join ke Tabel Pembayaran
$query = "
    SELECT
        p.*,
        u.nama,
        pay.metode AS metode_pembayaran,
        pay.bukti AS bukti_pembayaran,
        (
            SELECT GROUP_CONCAT(DISTINCT b.judul ORDER BY b.judul SEPARATOR ', ')
            FROM detail_pesanan dp
            INNER JOIN buku b ON b.id_buku = dp.id_buku
            WHERE dp.id_pesanan = p.id_pesanan
        ) AS daftar_buku
    FROM pesanan p
    INNER JOIN users u ON p.id_user = u.id_user
    LEFT JOIN pembayaran pay ON p.id_pesanan = pay.id_pesanan
    ORDER BY p.id_pesanan DESC
";
$data = mysqli_query($conn, $query);

function e($value) {
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pesanan Customer | SKYBS Admin</title>
    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    
    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --brand-card-bg: #FCF9F0;
            --shadow-sm: 0 4px 18px rgba(78, 34, 15, 0.05);
        }
        body { 
            background-color: var(--brand-cream-bg); 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            color: var(--brand-dark-brown); 
            min-height: 100vh; 
        }
        h2, .font-heading { font-family: 'Playfair Display', serif; }
        
        /* --- SIDEBAR NAVIGATION --- */
        .sidebar {
            width: 270px;
            height: 100vh;
            background: var(--brand-dark-brown);
            position: fixed;
            left: 0;
            top: 0;
            z-index: 100;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            display: flex;
            flex-direction: column;
        }

        .sidebar-brand {
            color: white;
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.12);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-badge {
            background: rgba(176, 186, 153, 0.25);
            border: 1px solid var(--brand-sage-green);
            color: var(--brand-sage-green);
            padding: 2px 8px;
            border-radius: 6px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 700;
        }

        .sidebar-menu {
            padding: 20px 0;
            flex-grow: 1;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            padding: 13px 25px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }

        .sidebar a i {
            width: 32px;
            font-size: 16px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: rgba(255, 255, 255, 0.12);
            color: #FFFFFF;
            border-left-color: var(--brand-warm-brown);
        }

        .btn-view-website {
            margin: 18px 20px 0;
            padding: 12px 16px !important;
            border-radius: 10px;
            background: var(--brand-sage-green);
            color: var(--brand-dark-brown) !important;
            border: 1px solid var(--brand-sage-green) !important;
            font-weight: 700 !important;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .btn-view-website:hover {
            background: #DCCFC0;
            color: var(--brand-dark-brown) !important;
            transform: translateY(-2px);
        }

        .btn-logout {
            background: rgba(220, 53, 69, 0.15);
            color: #FF6B6B;
            border: 1px solid rgba(220, 53, 69, 0.2);
            width: 100%;
            border-radius: 12px;
            padding: 10px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .btn-logout:hover {
            background: #DC3545;
            color: white;
        }

        /* --- CONTENT AREA WRAPPER --- */
        .content {
            margin-left: 270px;
            padding: 35px 40px;
        }

        .profile-badge {
            background: #FFFFFF;
            padding: 8px 18px;
            border-radius: 50px;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(78, 34, 15, 0.08);
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        /* Card Container */
        .card-custom { 
            background: var(--brand-card-bg); 
            border-radius: 24px; 
            box-shadow: 0 15px 35px rgba(78, 34, 15, 0.06); 
            border: 1px solid rgba(157, 102, 56, 0.15);
            overflow: hidden; 
        }

        /* Tabel Styling & Header */
        .table { background: transparent; margin-bottom: 0; }
        .table thead { 
            background: var(--brand-dark-brown) !important; 
        }
        .table thead th { 
            color: #ffffff !important; 
            font-size: 11px; 
            letter-spacing: 0.8px; 
            text-transform: uppercase; 
            padding: 18px 16px; 
            border: none; 
            font-weight: 700;
            background-color: var(--brand-dark-brown) !important;
        }
        .table tbody td { 
            padding: 18px 16px; 
            font-size: 13px; 
            vertical-align: middle; 
            border-bottom: 1px solid #ebdcb8;
            background-color: #ffffff; 
        }
        .table tbody tr {
            transition: all 0.2s ease-in-out;
        }
        .table tbody tr:hover td {
            background-color: #fcf6e8;
            transform: scale(1.001);
        }

        /* Badge Status Interaktif */
        .badge-status {
            padding: 6px 12px;
            font-weight: 600;
            border-radius: 50px;
            font-size: 11px;
            letter-spacing: 0.3px;
        }

        /* Tombol & Aksi */
        .btn-save { 
            background: var(--brand-warm-brown); 
            color: #fff; 
            border: none; 
            border-radius: 10px; 
            padding: 7px 14px; 
            font-size: 12px; 
            transition: all 0.2s;
        }
        .btn-save:hover { 
            background: var(--brand-dark-brown); 
            color: #fff; 
            transform: translateY(-1px);
            box-shadow: 0 4px 10px rgba(78, 34, 15, 0.2);
        }
        .btn-refund-done {
            background: #0d6efd;
            color: #fff;
            border: none;
            border-radius: 10px;
            padding: 7px 12px;
            font-size: 11px;
            font-weight: 600;
            transition: all 0.2s;
        }
        .btn-refund-done:hover {
            background: #0b5ed7;
            color: #fff;
        }
        .btn-bukti {
            background: #fff;
            border: 1px solid var(--brand-dark-brown);
            color: var(--brand-dark-brown);
            border-radius: 50px;
            padding: 6px 14px;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.2s;
        }
        .btn-bukti:hover {
            background: var(--brand-dark-brown);
            color: #fff;
        }
        .form-select-sm {
            border-radius: 10px;
            border-color: #d1c2a5;
            padding: 6px 10px;
            font-size: 12px;
        }
        .form-select-sm:focus {
            border-color: var(--brand-warm-brown);
            box-shadow: 0 0 0 0.2rem rgba(157, 102, 56, 0.15);
        }
        
        .mobile-label {
            display: none;
            font-weight: 700;
            font-size: 10px;
            text-transform: uppercase;
            color: var(--brand-warm-brown);
            margin-bottom: 2px;
        }
        @media (max-width: 992px) {
            .sidebar { width: 100%; height: auto; position: relative; }
            .content { margin-left: 0; padding: 20px; }
        }
        @media (max-width: 768px) {
            .mobile-label { display: block; }
        }
    </style>
</head>
<body>

<!-- SIDEBAR NAVIGATION -->
<div class="sidebar">
    <div class="sidebar-brand">
        <i class="fa-solid fa-book-open text-warning fs-4"></i>
        <div>
            <h5 class="fw-bold mb-0 text-white">SKYBS Admin</h5>
            <span class="brand-badge">Panel System</span>
        </div>
    </div>

    <div class="sidebar-menu">
        <a href="admin.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
        <a href="admin_kategori.php"><i class="fa-solid fa-tags"></i> Kategori Buku</a>
        <a href="admin_buku.php"><i class="fa-solid fa-book"></i> Data Buku</a>
        <a href="admin_user.php"><i class="fa-solid fa-users"></i> Data User</a>
        <a href="admin_pesanan.php" class="active"><i class="fa-solid fa-cart-shopping"></i> Pesanan</a>
        <a href="admin_war.php"><i class="fa-solid fa-ticket"></i> War Tiket</a>
        <a href="admin_contact.php"><i class="fa-solid fa-comments"></i> Pesan User</a>

        <a href="index.php" target="_blank" class="btn-view-website">
            <i class="fa-solid fa-eye"></i> Buka Full Website
        </a>
    </div>

    <div class="p-3">
        <form action="logout.php" method="POST">
            <button type="submit" class="btn btn-logout d-flex align-items-center justify-content-center gap-2" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
            </button>
        </form>
    </div>
</div>

<!-- Konten Utama -->
<div class="content animate__animated animate__fadeIn">
    <!-- HEADER TOPBAR -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 pb-3 border-bottom border-secondary-subtle">
        <div>
            <h2 class="font-heading fw-bold mb-1">Kelola Pesanan</h2>
            <p class="text-muted small mb-0">Verifikasi pembayaran dan perbarui status pesanan pelanggan dengan cepat.</p>
        </div>
        <div>
            <div class="profile-badge">
                <i class="fa-solid fa-user-gear fs-5" style="color: var(--brand-warm-brown);"></i>
                <span class="fw-bold fs-6" style="color: var(--brand-dark-brown);"><?= e($nama_admin); ?> (Admin)</span>
            </div>
        </div>
    </div>

    <div class="card-custom p-4 animate__animated animate__fadeInUp">
        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th class="text-center">ID Pesanan</th>
                        <th>Informasi Customer</th>
                        <th>Buku Dipesan</th>
                        <th>Total Tagihan</th>
                        <th class="text-center">Bukti Bayar</th>
                        <th class="text-center">Status Pesanan</th>
                        <th class="text-center">Waktu Transaksi</th>
                        <th class="text-center" style="width: 250px;">Aksi Cepat</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($data && mysqli_num_rows($data) > 0): ?>
                    <?php while ($d = mysqli_fetch_assoc($data)): ?>
                        <?php
                        $status = $d['status'] ?? 'Menunggu Konfirmasi';
                        $judulBuku = trim((string) ($d['daftar_buku'] ?? '-'));
                        $total = $d['total_harga'] ?? $d['total'] ?? 0;
                        $tanggal = !empty($d['tanggal']) ? date('d M Y, H:i', strtotime($d['tanggal'])) : '-';
                        $metode = trim($d['metode_pembayaran'] ?? '');
                        $bukti = trim($d['bukti_pembayaran'] ?? '');
                        
                        // Warna badge berdasarkan status
                        $badgeBg = 'bg-secondary';
                        if ($status === 'Menunggu Konfirmasi') $badgeBg = 'bg-warning text-dark';
                        elseif ($status === 'Diproses') $badgeBg = 'bg-info text-dark';
                        elseif ($status === 'Dikirim') $badgeBg = 'bg-primary';
                        elseif ($status === 'Selesai') $badgeBg = 'bg-success';
                        elseif ($status === 'Batal') $badgeBg = 'bg-danger';
                        elseif ($status === 'Refund') $badgeBg = 'bg-primary text-white';
                        ?>
                        <tr>
                            <td class="text-center fw-bold text-muted">
                                <span class="mobile-label">ID Pesanan</span>
                                #<?= (int) $d['id_pesanan']; ?>
                            </td>
                            <td>
                                <span class="mobile-label">Customer</span>
                                <div class="fw-bold text-dark"><?= e($d['nama']); ?></div>
                                <small class="text-muted" style="font-size: 11px;">ID: #<?= (int) $d['id_user']; ?></small>
                            </td>
                            <td>
                                <span class="mobile-label">Buku</span>
                                <span class="d-inline-block text-truncate" style="max-width: 200px;" title="<?= e($judulBuku); ?>">
                                    <?= e($judulBuku); ?>
                                </span>
                            </td>
                            <td>
                                <span class="mobile-label">Total</span>
                                <span class="fw-bold" style="color: #9D6638;">Rp <?= number_format((float) $total, 0, ',', '.'); ?></span>
                            </td>
                            
                            <td class="text-center">
                                <span class="mobile-label">Bukti Bayar</span>
                                <?php if (strtoupper($metode) === 'COD'): ?>
                                    <span class="badge bg-light text-muted border px-2 py-1" style="font-size: 10px;">COD (Tunai)</span>
                                <?php elseif (!empty($bukti)): ?>
                                    <a href="bukti.php?id=<?= (int) $d['id_pesanan']; ?>" class="btn-bukti shadow-sm">
                                        <i class="fa-solid fa-image text-warning me-1"></i> Lihat
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted" style="font-size: 11px; font-style: italic;">Belum upload</span>
                                <?php endif; ?>
                            </td>

                            <td class="text-center">
                                <span class="mobile-label">Status</span>
                                <div><span class="badge badge-status <?= $badgeBg; ?> shadow-sm"><?= e($status); ?></span></div>
                            </td>
                            
                            <td class="text-center text-muted" style="font-size: 12px;">
                                <span class="mobile-label">Tanggal</span>
                                <?= e($tanggal); ?>
                            </td>
                            
                            <td>
                                <span class="mobile-label">Aksi Cepat</span>
                                <div class="d-flex flex-column gap-2 align-items-center">
                                    <!-- Tombol Khusus Cepat: Jika Status Batal & Non-COD, Tampilkan Tombol Tandai Sudah Direfund -->
                                    <?php if ($status === 'Batal' && strtoupper($metode) !== 'COD'): ?>
                                        <form method="POST" onsubmit="return confirm('Apakah Anda sudah mentransfer pengembalian dana ke customer? Status akan diubah menjadi Refund.');">
                                            <input type="hidden" name="id_pesanan" value="<?= (int) $d['id_pesanan']; ?>">
                                            <input type="hidden" name="status" value="Refund">
                                            <button type="submit" name="update" value="1" class="btn-refund-done shadow-sm w-100">
                                                <i class="fa-solid fa-circle-check me-1"></i> Tandai  Sudah Direfund
                                            </button>
                                        </form>
                                    <?php endif; ?>

                                    <!-- Form Ubah Status Manual -->
                                    <form method="POST" class="d-flex gap-2 align-items-center justify-content-center w-100">
                                        <input type="hidden" name="id_pesanan" value="<?= (int) $d['id_pesanan']; ?>">
                                        <select name="status" class="form-select form-select-sm shadow-sm" required>
                                            <?php foreach (['Menunggu Konfirmasi', 'Diproses', 'Dikirim', 'Selesai', 'Batal', 'Refund'] as $opt): ?>
                                                <option value="<?= e($opt); ?>" <?= ($status === $opt) ? 'selected' : ''; ?>><?= e($opt); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <button type="submit" name="update" value="1" class="btn-save shadow-sm" title="Simpan Perubahan">
                                            <i class="fa-solid fa-check"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center py-5 text-muted">
                            <i class="fa-solid fa-box-open fs-2 mb-2 d-block text-warning"></i>
                            Belum ada data transaksi pesanan saat ini.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <footer class="mt-5 text-center text-muted small">
        <p class="mb-0">&copy; <?= date('Y'); ?> <strong>SKY Bookstore</strong> - Admin Dashboard System.</p>
    </footer>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>