<?php
session_start();
include "database.php";

if (!isset($_SESSION['id_user'])) {
    echo "<script>alert('Silakan login terlebih dahulu untuk mengirim pesan!'); window.location='login.php';</script>";
    exit;
}

$id_user = (int)$_SESSION['id_user'];
$nama = $_SESSION['nama'] ?? 'User';

// Pastikan tabel chat memiliki struktur lengkap termasuk kolom gambar
mysqli_query($conn, "
    CREATE TABLE IF NOT EXISTS chat (
        id_chat INT AUTO_INCREMENT PRIMARY KEY,
        id_user INT NOT NULL,
        pengirim ENUM('user', 'admin') NOT NULL,
        pesan TEXT DEFAULT NULL,
        gambar VARCHAR(255) DEFAULT NULL,
        waktu TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
");

// Proses kirim pesan & foto oleh user
if (isset($_POST['kirim_pesan']) || isset($_POST['kirim'])) {
    $pesan = trim($_POST['pesan'] ?? '');
    $nama_gambar = NULL;

    // Cek apakah user mengupload gambar
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['gambar']['tmp_name'];
        $file_name = $_FILES['gambar']['name'];
        $ekstensi = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $ekstensi_boleh = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (in_array($ekstensi, $ekstensi_boleh)) {
            $nama_gambar = "chat_user_" . time() . "_" . rand(100, 999) . "." . $ekstensi;
            $folder_tujuan = __DIR__ . "/img/chat/";

            if (!is_dir($folder_tujuan)) {
                mkdir($folder_tujuan, 0777, true);
            }

            move_uploaded_file($file_tmp, $folder_tujuan . $nama_gambar);
        }
    }

    // Pastikan pesan atau gambar tidak kosong sebelum disimpan ke database
    if (!empty($pesan) || !empty($nama_gambar)) {
        $stmt_kirim = mysqli_prepare($conn, "INSERT INTO chat (id_user, pengirim, pesan, gambar, waktu) VALUES (?, 'user', ?, ?, NOW())");
        if ($stmt_kirim) {
            mysqli_stmt_bind_param($stmt_kirim, "iss", $id_user, $pesan, $nama_gambar);
            mysqli_stmt_execute($stmt_kirim);
            mysqli_stmt_close($stmt_kirim);
        } else {
            // Debugging jika query gagal (bisa dihapus jika sudah normal)
            echo "Error prepare: " . mysqli_error($conn);
            exit;
        }
    }
    
    header("Location: contact.php");
    exit;
}

// Ambil riwayat pesan
$chat_history = false;
$stmt_chat = mysqli_prepare($conn, "SELECT * FROM chat WHERE id_user = ? ORDER BY waktu ASC");
if ($stmt_chat) {
    mysqli_stmt_bind_param($stmt_chat, "i", $id_user);
    mysqli_stmt_execute($stmt_chat);
    $chat_history = mysqli_stmt_get_result($stmt_chat);
    mysqli_stmt_close($stmt_chat);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesan / Kontak Admin | SKY Bookstore</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        :root {
            --brand-dark-brown: #3C180A;
            --brand-warm-brown: #8D5524;
            --brand-cream-bg: #FDFBF7;
        }
        body { background-color: var(--brand-cream-bg); font-family: 'Plus Jakarta Sans', sans-serif; color: var(--brand-dark-brown); }
        .chat-container { background: #FFFFFF; border-radius: 20px; box-shadow: 0 10px 30px rgba(60, 24, 10, 0.08); overflow: hidden; border: 1px solid rgba(141, 85, 36, 0.1); }
        .chat-box { height: 400px; overflow-y: auto; background: #FCF9F5; padding: 20px; }
        .chat-bubble { max-width: 70%; padding: 12px 16px; border-radius: 15px; margin-bottom: 15px; font-size: 14px; word-wrap: break-word; }
        .chat-user { background: var(--brand-dark-brown); color: white; margin-left: auto; border-bottom-right-radius: 4px; }
        .chat-admin { background: #EEDCC5; color: var(--brand-dark-brown); margin-right: auto; border-bottom-left-radius: 4px; }
        .chat-img { max-width: 200px; border-radius: 10px; margin-bottom: 6px; display: block; cursor: pointer; }
        .navbar-custom { background: var(--brand-dark-brown); padding: 14px 0; }
        .btn-attachment {
            background: #FDFBF7;
            border: 1px solid rgba(141, 85, 36, 0.3);
            color: var(--brand-dark-brown);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s ease;
            flex-shrink: 0;
        }
        .btn-attachment:hover {
            background: var(--brand-warm-brown);
            color: white;
            border-color: var(--brand-warm-brown);
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-custom sticky-top">
        <div class="container">
            <a class="navbar-brand text-white fw-bold" href="index.php"><i class="fa-solid fa-book-open text-warning me-2"></i>SKY Bookstore</a>
            <a href="index.php" class="btn btn-sm btn-outline-light rounded-pill px-3">Kembali ke Beranda</a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="chat-container">
                    <div class="p-3 bg-white border-bottom d-flex align-items-center gap-3">
                        <div class="rounded-circle bg-warning text-dark d-flex align-items-center justify-content-center fw-bold" style="width: 45px; height: 45px;">
                            <i class="fa-solid fa-headset fs-5"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold mb-0">Pusat Bantuan & Kontak Admin</h5>
                            <small class="text-muted">Tanyakan ketersediaan buku, kendala pesanan, atau kirim bukti foto secara real-time</small>
                        </div>
                    </div>

                    <div class="chat-box" id="chatBox">
                        <?php if ($chat_history && mysqli_num_rows($chat_history) > 0): ?>
                            <?php while ($c = mysqli_fetch_assoc($chat_history)): ?>
                                <?php $pengirim = $c['pengirim'] ?? 'user'; ?>
                                <?php if ($pengirim == 'user'): ?>
                                    <div class="chat-bubble chat-user shadow-sm">
                                        <?php if (!empty($c['gambar'])): ?>
                                            <a href="img/chat/<?= htmlspecialchars($c['gambar']); ?>" target="_blank">
                                                <img src="img/chat/<?= htmlspecialchars($c['gambar']); ?>" alt="Lampiran" class="chat-img">
                                            </a>
                                        <?php endif; ?>
                                        <?php if (!empty($c['pesan'])): ?>
                                            <?= nl2br(htmlspecialchars($c['pesan'])); ?>
                                        <?php endif; ?>
                                        <div class="text-end text-white-50" style="font-size: 10px;"><?= $c['waktu'] ?? ''; ?></div>
                                    </div>
                                <?php else: ?>
                                    <div class="chat-bubble chat-admin shadow-sm">
                                        <strong>Admin:</strong><br>
                                        <?php if (!empty($c['gambar'])): ?>
                                            <a href="img/chat/<?= htmlspecialchars($c['gambar']); ?>" target="_blank">
                                                <img src="img/chat/<?= htmlspecialchars($c['gambar']); ?>" alt="Lampiran" class="chat-img">
                                            </a>
                                        <?php endif; ?>
                                        <?php if (!empty($c['pesan'])): ?>
                                            <?= nl2br(htmlspecialchars($c['pesan'])); ?>
                                        <?php endif; ?>
                                        <div class="text-end text-muted" style="font-size: 10px;"><?= $c['waktu'] ?? ''; ?></div>
                                    </div>
                                <?php endif; ?>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="text-center text-muted my-auto py-5">
                                <i class="fa-regular fa-comments fs-1 mb-2 opacity-50"></i>
                                <p class="small">Belum ada percakapan. Mulai kirim pesan atau foto untuk bertanya kepada admin!</p>
                            </div>
                        <?php endif; ?>
                    </div>

                    <form method="POST" enctype="multipart/form-data" class="p-3 bg-white border-top d-flex align-items-center gap-2">
                        <!-- Input File Tersembunyi -->
                        <input type="file" name="gambar" id="fileInput" accept="image/*" class="d-none" onchange="previewFileName()">
                        <button type="button" class="btn-attachment" onclick="document.getElementById('fileInput').click()" title="Kirim Foto">
                            <i class="fa-solid fa-image"></i>
                        </button>

                        <input type="text" name="pesan" class="form-control rounded-pill px-3 flex-grow-1" placeholder="Ketik pesan Anda ke admin atau pilih foto..." autocomplete="off">
                        
                        <button type="submit" name="kirim_pesan" class="btn btn-dark rounded-pill px-4" style="background: var(--brand-dark-brown);">
                            <i class="fa-solid fa-paper-plane"></i>
                        </button>
                    </form>
                    <div id="fileInfo" class="px-3 pb-2 text-muted small" style="font-size: 11px; background: #fff;"></div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const chatBox = document.getElementById('chatBox');
        if(chatBox) { chatBox.scrollTop = chatBox.scrollHeight; }

        function previewFileName() {
            const fileInput = document.getElementById('fileInput');
            const fileInfo = document.getElementById('fileInfo');
            if (fileInput.files.length > 0) {
                fileInfo.textContent = "Foto terpilih: " + fileInput.files[0].name;
            } else {
                fileInfo.textContent = "";
            }
        }
    </script>
</body>
</html>