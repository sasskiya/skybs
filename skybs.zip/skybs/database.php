<?php
// ==========================================
// KONEKSI DATABASE SKYBS BOOKSTORE
// ==========================================

$host     = "localhost";
$username = "root";
$password = "";
$database = "skybs";

// Inisialisasi Koneksi MySQLi
$conn = mysqli_connect($host, $username, $password, $database);

// Validasi & Pengamanan Koneksi Database
if (!$conn) {
    die("<div style='font-family: sans-serif; padding: 20px; background: #F8D7DA; color: #842029; border-radius: 8px;'>
            <strong>Koneksi Database Gagal:</strong> " . mysqli_connect_error() . "
         </div>");
}

// Set Character Encoding UTF-8 (Mendukung Karakter Khusus & Emoji)
mysqli_set_charset($conn, "utf8mb4");

// Set Zona Waktu Default Sistem (WIB / Asia/Jakarta)
date_default_timezone_set("Asia/Jakarta");
?>