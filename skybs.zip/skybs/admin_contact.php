<?php
session_start();
include "database.php";

if (!isset($_SESSION['id_admin'])) {
    header("Location: login.php");
    exit;
}

// Nama admin default
$nama_admin = isset($_SESSION['nama']) && !empty($_SESSION['nama'])
    ? $_SESSION['nama']
    : 'Saskiya';

// Pastikan tabel chat memiliki kolom untuk gambar jika belum ada (opsional / otomatis)
mysqli_query($conn, "
    CREATE TABLE IF NOT EXISTS chat (
        id_chat INT AUTO_INCREMENT PRIMARY KEY,
        id_user INT NOT NULL,
        pengirim ENUM('user', 'admin') NOT NULL,
        pesan TEXT DEFAULT NULL,
        gambar VARCHAR(255) DEFAULT NULL,
        waktu TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
");

// FETCH USER YANG PERNAH BERINTERAKSI/CHAT
$query_users = "
SELECT 
    users.id_user,
    users.nama,
    users.email,
    MAX(chat.waktu) AS terakhir
FROM chat
JOIN users ON chat.id_user = users.id_user
GROUP BY users.id_user
ORDER BY terakhir DESC
";
$data = mysqli_query($conn, $query_users);

// TERIMA ID USER DARI URL
$id_user = isset($_GET['id_user']) ? (int)$_GET['id_user'] : 0;

// FITUR KIRIM PESAN & FOTO OLEH ADMIN
if (isset($_POST['kirim'])) {
    $id = (int)$_POST['id_user'];
    $pesan = trim(mysqli_real_escape_string($conn, $_POST['pesan']));
    $nama_gambar = NULL;

    // Cek apakah admin mengupload gambar
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['gambar']['tmp_name'];
        $file_name = $_FILES['gambar']['name'];
        $ekstensi = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $ekstensi_boleh = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (in_array($ekstensi, $ekstensi_boleh)) {
            $nama_gambar = "chat_admin_" . time() . "_" . rand(100, 999) . "." . $ekstensi;
            $folder_tujuan = "img/chat/";

            if (!is_dir($folder_tujuan)) {
                mkdir($folder_tujuan, 0777, true);
            }

            move_uploaded_file($file_tmp, $folder_tujuan . $nama_gambar);
        }
    }

    // Simpan ke database jika pesan teks ATAU gambar tidak kosong
    if (!empty($pesan) || !empty($nama_gambar)) {
        $stmt = mysqli_prepare($conn, "INSERT INTO chat (id_user, pengirim, pesan, gambar) VALUES (?, 'admin', ?, ?)");
        mysqli_stmt_bind_param($stmt, "iss", $id, $pesan, $nama_gambar);
        mysqli_stmt_execute($stmt);
    }

    header("Location: admin_contact.php?id_user=$id");
    exit;
}

$chat = null;
$nama_user = "";
$email_user = "";

if ($id_user > 0) {
    $user_query = mysqli_query($conn, "SELECT * FROM users WHERE id_user='$id_user'");
    $user = mysqli_fetch_assoc($user_query);

    if ($user) {
        $nama_user = $user['nama'];
        $email_user = $user['email'];
    }

    $chat = mysqli_query($conn, "
        SELECT * FROM chat
        WHERE id_user='$id_user'
        ORDER BY id_chat ASC
    ");
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Chat Customer | SKYBS Admin</title>

    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --chat-bg-user: #EFE8DC;
            --chat-bg-admin: #4E220F;
            --shadow-sm: 0 4px 18px rgba(78, 34, 15, 0.05);
            --shadow-md: 0 10px 30px rgba(78, 34, 15, 0.1);
            --radius-lg: 20px;
        }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            height: 100vh;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        /* --- SIDEBAR NAVIGATION --- */
        .sidebar {
            width: 270px;
            height: 100vh;
            background: var(--brand-dark-brown);
            position: fixed;
            left: 0;
            top: 0;
            z-index: 1000;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            display: flex;
            flex-direction: column;
        }

        .sidebar-brand {
            color: white;
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.12);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-badge {
            background: rgba(176, 186, 153, 0.25);
            border: 1px solid var(--brand-sage-green);
            color: var(--brand-sage-green);
            padding: 2px 8px;
            border-radius: 6px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 700;
        }

        .sidebar-menu {
            padding: 20px 0;
            flex-grow: 1;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            padding: 13px 25px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }

        .sidebar a i {
            width: 32px;
            font-size: 16px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: rgba(255, 255, 255, 0.12);
            color: #FFFFFF;
            border-left-color: var(--brand-warm-brown);
        }

        .btn-view-website {
            margin: 18px 20px 0;
            padding: 12px 16px !important;
            border-radius: 10px;
            background: var(--brand-sage-green);
            color: var(--brand-dark-brown) !important;
            border: 1px solid var(--brand-sage-green) !important;
            font-weight: 700 !important;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .btn-view-website:hover {
            background: #DCCFC0;
            color: var(--brand-dark-brown) !important;
            transform: translateY(-2px);
        }

        .btn-logout {
            background: rgba(220, 53, 69, 0.15);
            color: #FF6B6B;
            border: 1px solid rgba(220, 53, 69, 0.2);
            width: 100%;
            border-radius: 12px;
            padding: 10px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .btn-logout:hover {
            background: #DC3545;
            color: white;
        }

        /* --- CONTENT AREA WRAPPER --- */
        .main-chat-wrapper {
            margin-left: 270px;
            flex: 1;
            padding: 20px 30px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .chat-card {
            background: #FFFFFF;
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
            border: 1px solid rgba(78, 34, 15, 0.08);
            height: calc(100vh - 100px);
            overflow: hidden;
        }

        /* SIDEBAR USER LIST */
        .sidebar-header {
            padding: 20px;
            background: var(--brand-cream-bg);
            border-bottom: 1px solid rgba(78, 34, 15, 0.1);
        }

        .user-list {
            height: calc(100% - 75px);
            overflow-y: auto;
        }

        .user-item {
            padding: 16px 20px;
            border-bottom: 1px solid rgba(78, 34, 15, 0.05);
            text-decoration: none;
            color: var(--brand-dark-brown);
            display: flex;
            align-items: center;
            gap: 14px;
            transition: all 0.2s ease;
        }

        .user-item:hover {
            background-color: var(--brand-cream-bg);
        }

        .user-item.active-user {
            background-color: #E8E0CE;
            border-left: 4px solid var(--brand-warm-brown);
        }

        .avatar {
            width: 46px;
            height: 46px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--brand-warm-brown), var(--brand-dark-brown));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 18px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            flex-shrink: 0;
        }

        /* AREA CHAT UTAMA */
        .chat-area {
            height: 100%;
            display: flex;
            flex-direction: column;
            background: #FAF8F5;
        }

        .chat-header {
            background: #FFFFFF;
            padding: 16px 24px;
            border-bottom: 1px solid rgba(78, 34, 15, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
        }

        .chat-body {
            flex: 1;
            padding: 24px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 14px;
        }

        /* CHAT BUBBLES */
        .message-row {
            display: flex;
            flex-direction: column;
            max-width: 68%;
        }

        .message-row.user-side {
            align-self: flex-start;
        }

        .message-row.admin-side {
            align-self: flex-end;
        }

        .message-bubble {
            padding: 12px 18px;
            border-radius: 18px;
            font-size: 14px;
            line-height: 1.5;
            position: relative;
            word-wrap: break-word;
            box-shadow: 0 2px 8px rgba(0,0,0,0.03);
        }

        .user-side .message-bubble {
            background: var(--chat-bg-user);
            color: var(--brand-dark-brown);
            border-bottom-left-radius: 4px;
        }

        .admin-side .message-bubble {
            background: var(--chat-bg-admin);
            color: #FFFFFF;
            border-bottom-right-radius: 4px;
        }

        .chat-img {
            max-width: 220px;
            border-radius: 10px;
            margin-bottom: 6px;
            cursor: pointer;
            display: block;
        }

        .time-stamp {
            font-size: 10px;
            margin-top: 4px;
            opacity: 0.75;
        }

        .user-side .time-stamp {
            text-align: left;
            color: var(--brand-dark-brown);
        }

        .admin-side .time-stamp {
            text-align: right;
            color: rgba(255, 255, 255, 0.85);
        }

        /* CHAT FOOTER */
        .chat-footer {
            background: #FFFFFF;
            padding: 16px 20px;
            border-top: 1px solid rgba(78, 34, 15, 0.1);
        }

        .input-chat {
            border-radius: 50px;
            padding: 10px 20px;
            border: 1px solid rgba(78, 34, 15, 0.2);
            background: var(--brand-cream-bg);
            font-size: 14px;
        }

        .input-chat:focus {
            background: #FFFFFF;
            border-color: var(--brand-warm-brown);
            box-shadow: none;
        }

        .btn-send {
            background: var(--brand-warm-brown);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 0 24px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-send:hover {
            background: var(--brand-dark-brown);
            color: white;
        }

        .btn-attachment {
            background: var(--brand-cream-bg);
            border: 1px solid rgba(78, 34, 15, 0.2);
            color: var(--brand-dark-brown);
            border-radius: 50%;
            width: 42px;
            height: 42px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            flex-shrink: 0;
        }

        .btn-attachment:hover {
            background: var(--brand-warm-brown);
            color: white;
            border-color: var(--brand-warm-brown);
        }

        .empty-state {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            text-align: center;
            color: var(--brand-dark-brown);
            padding: 30px;
        }

        .empty-icon-wrapper {
            width: 90px;
            height: 90px;
            background: var(--brand-cream-bg);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            color: var(--brand-warm-brown);
        }

        .profile-badge {
            background: #FFFFFF;
            padding: 6px 16px;
            border-radius: 50px;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(78, 34, 15, 0.08);
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        footer {
            margin-top: 80px;
            padding: 25px 0;
            font-size: 13px;
        }

        @media (max-width: 992px) {
            .sidebar { width: 100%; height: auto; position: relative; }
            .main-chat-wrapper { margin-left: 0; padding: 15px; height: auto; overflow: visible; }
            .chat-card { height: 80vh; }
        }
    </style>
</head>

<body>

    <!-- SIDEBAR NAVIGATION -->
    <div class="sidebar">
        <div class="sidebar-brand">
            <i class="fa-solid fa-book-open text-warning fs-4"></i>
            <div>
                <h5 class="fw-bold mb-0 text-white">SKYBS Admin</h5>
                <span class="brand-badge">Panel System</span>
            </div>
        </div>

        <div class="sidebar-menu">
            <a href="admin.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
            <a href="admin_kategori.php"><i class="fa-solid fa-tags"></i> Kategori Buku</a>
            <a href="admin_buku.php"><i class="fa-solid fa-book"></i> Data Buku</a>
            <a href="admin_user.php"><i class="fa-solid fa-users"></i> Data User</a>
            <a href="admin_pesanan.php"><i class="fa-solid fa-cart-shopping"></i> Pesanan</a>
            <a href="admin_war.php"><i class="fa-solid fa-ticket"></i> War Tiket</a>
            <a href="admin_contact.php" class="active"><i class="fa-solid fa-comments"></i> Pesan User</a>

            <a href="index.php" target="_blank" class="btn-view-website">
                <i class="fa-solid fa-eye"></i> Buka Full Website
            </a>
        </div>

        <div class="p-3">
            <form action="logout.php" method="POST">
                <button type="submit" class="btn btn-logout d-flex align-items-center justify-content-center gap-2" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <span>Logout</span>
                </button>
            </form>
        </div>
    </div>

    <!-- MAIN CHAT CONTAINER -->
    <div class="main-chat-wrapper">
        <div class="container-fluid px-0 h-100">
            <div class="chat-card">
                <div class="row g-0 h-100">

                    <!-- SIDEBAR DAFTAR KONSUMEN -->
                    <div class="col-md-4 col-lg-3 border-end h-100 d-flex flex-column">
                        <div class="sidebar-header">
                            <h6 class="fw-bold mb-0" style="color: var(--brand-dark-brown);">
                                <i class="fa-solid fa-comments me-2" style="color: var(--brand-warm-brown);"></i>Pesan Pelanggan
                            </h6>
                        </div>

                        <div class="user-list">
                            <?php if (mysqli_num_rows($data) > 0): ?>
                                <?php while ($u = mysqli_fetch_assoc($data)): ?>
                                    <a href="admin_contact.php?id_user=<?= $u['id_user']; ?>" 
                                       class="user-item <?= ($id_user == $u['id_user']) ? 'active-user' : ''; ?>">
                                        <div class="avatar">
                                            <?= strtoupper(substr(htmlspecialchars($u['nama']), 0, 1)); ?>
                                        </div>
                                        <div class="overflow-hidden">
                                            <div class="fw-bold text-truncate" style="font-size: 15px;">
                                                <?= htmlspecialchars($u['nama']); ?>
                                            </div>
                                            <small class="text-muted d-block text-truncate" style="font-size: 12px;">
                                                <?= htmlspecialchars($u['email']); ?>
                                            </small>
                                        </div>
                                    </a>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div class="text-center py-5 text-muted small">
                                    <i class="fa-regular fa-comment-dots fs-3 mb-2 d-block opacity-50"></i>
                                    Belum ada obrolan masuk.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- DISPLAY CHAT AREA -->
                    <div class="col-md-8 col-lg-9 h-100">
                        <div class="chat-area">
                            <?php if ($id_user > 0 && $chat): ?>
                                
                                <!-- HEADER CHAT USER -->
                                <div class="chat-header">
                                    <div class="d-flex align-items-center gap-3">
                                        <div class="avatar" style="width:40px; height:40px; font-size:16px;">
                                            <?= strtoupper(substr(htmlspecialchars($nama_user), 0, 1)); ?>
                                        </div>
                                        <div>
                                            <h6 class="fw-bold mb-0" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($nama_user); ?></h6>
                                            <small class="text-muted" style="font-size: 12px;"><?= htmlspecialchars($email_user); ?></small>
                                        </div>
                                    </div>
                                    <div class="profile-badge">
                                        <i class="fa-solid fa-user-gear fs-6" style="color: var(--brand-warm-brown);"></i>
                                        <span class="fw-bold small" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($nama_admin); ?> (Admin)</span>
                                    </div>
                                </div>

                                <!-- BODY PERCAKAPAN -->
                                <div class="chat-body" id="chatBody">
                                    <?php if (mysqli_num_rows($chat) > 0): ?>
                                        <?php while ($c = mysqli_fetch_assoc($chat)): ?>
                                            <?php $isAdmin = ($c['pengirim'] === 'admin'); ?>
                                            
                                            <div class="message-row <?= $isAdmin ? 'admin-side' : 'user-side'; ?>">
                                                <div class="message-bubble">
                                                    <?php if (!empty($c['gambar'])): ?>
                                                        <a href="img/chat/<?= htmlspecialchars($c['gambar']); ?>" target="_blank">
                                                            <img src="img/chat/<?= htmlspecialchars($c['gambar']); ?>" alt="Lampiran Foto" class="chat-img">
                                                        </a>
                                                    <?php endif; ?>
                                                    
                                                    <?php if (!empty($c['pesan'])): ?>
                                                        <?= nl2br(htmlspecialchars($c['pesan'])); ?>
                                                    <?php endif; ?>

                                                    <div class="time-stamp">
                                                        <?= date('H:i, d M', strtotime($c['waktu'])); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <div class="text-center my-auto text-muted small">
                                            Mulailah percakapan pertama Anda dengan pelanggan ini.
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- FORM INPUT BALAS PESAN & UPLOAD FOTO -->
                                <div class="chat-footer">
                                    <form method="POST" enctype="multipart/form-data" class="d-flex align-items-center gap-2">
                                        <input type="hidden" name="id_user" value="<?= $id_user; ?>">
                                        
                                        <!-- Tombol Pilih File Foto -->
                                        <input type="file" name="gambar" id="fileInput" accept="image/*" class="d-none" onchange="previewFileName()">
                                        <button type="button" class="btn-btn btn-attachment" onclick="document.getElementById('fileInput').click()" title="Kirim Foto">
                                            <i class="fa-solid fa-image"></i>
                                        </button>

                                        <input type="text" 
                                               name="pesan" 
                                               id="pesanInput"
                                               class="form-control input-chat flex-grow-1" 
                                               placeholder="Tulis balasan pesan atau pilih foto..." 
                                               autocomplete="off">
                                               
                                        <button type="submit" name="kirim" class="btn btn-send d-flex align-items-center gap-2">
                                            <span>Kirim</span>
                                            <i class="fa-solid fa-paper-plane"></i>
                                        </button>
                                    </form>
                                    <div id="fileInfo" class="text-muted small mt-1 px-2" style="font-size: 11px;"></div>
                                </div>

                            <?php else: ?>
                                
                                <!-- EMPTY STATE JIKA BELUM PILIH USER -->
                                <div class="empty-state">
                                    <div class="empty-icon-wrapper">
                                        <i class="fa-solid fa-comments fs-1"></i>
                                    </div>
                                    <h5 class="fw-bold" style="color: var(--brand-dark-brown);">Pilih Percakapan Pelanggan</h5>
                                    <p class="text-muted small" style="max-width: 360px;">
                                        Silakan pilih salah satu nama pelanggan di sebelah kiri untuk membaca dan membalas pesan secara real-time.
                                    </p>
                                </div>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- SCRIPT TAMBAHAN -->
    <script>
        // Auto-scroll ke chat terbaru
        document.addEventListener("DOMContentLoaded", function() {
            var chatBody = document.getElementById("chatBody");
            if (chatBody) {
                chatBody.scrollTop = chatBody.scrollHeight;
            }
        });

        // Menampilkan nama file foto yang dipilih di sebelah tombol
        function previewFileName() {
            const fileInput = document.getElementById('fileInput');
            const fileInfo = document.getElementById('fileInfo');
            if (fileInput.files.length > 0) {
                fileInfo.textContent = "Lampiran terpilih: " + fileInput.files[0].name;
            } else {
                fileInfo.textContent = "";
            }
        }
    </script>
</body>

</html>