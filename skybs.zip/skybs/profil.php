<?php
session_start();
include "database.php";

// 1. Cek Autentikasi User
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

$id = (int)$_SESSION['id_user'];

// 2. Ambil Data User Saat Ini (Prepared Statement)
$stmt_user = mysqli_prepare($conn, "SELECT * FROM users WHERE id_user = ?");
mysqli_stmt_bind_param($stmt_user, "i", $id);
mysqli_stmt_execute($stmt_user);
$user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_user));

if (!$user) {
    header("Location: login.php");
    exit;
}

// 3. Proses Simpan Perubahan Profil
if (isset($_POST['simpan'])) {
    $nama   = trim($_POST['nama']);
    $email  = trim($_POST['email']);
    $no_hp  = trim($_POST['no_hp']);
    $alamat = trim($_POST['alamat']);

    $foto_lama = $user['foto'];
    $foto_baru = $foto_lama;

    // Cek Jika Ada Upload Foto Profil Baru
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($ext, $allowed)) {
            $nama_foto = "user_" . time() . "_" . rand(100, 999) . "." . $ext;
            $target_dir = "img/users/";

            // Buat folder jika belum ada
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0777, true);
            }

            // Upload Foto Baru & Hapus Foto Lama
            if (move_uploaded_file($_FILES['foto']['tmp_name'], $target_dir . $nama_foto)) {
                if (!empty($foto_lama) && file_exists($target_dir . $foto_lama)) {
                    unlink($target_dir . $foto_lama);
                }
                $foto_baru = $nama_foto;
            }
        }
    }

    // Update Data ke Database
    $stmt_up = mysqli_prepare($conn, "
        UPDATE users SET 
            nama = ?, 
            email = ?, 
            no_hp = ?, 
            alamat = ?, 
            foto = ? 
        WHERE id_user = ?
    ");
    mysqli_stmt_bind_param($stmt_up, "sssssi", $nama, $email, $no_hp, $alamat, $foto_baru, $id);

    if (mysqli_stmt_execute($stmt_up)) {
        $_SESSION['nama'] = $nama;
        $_SESSION['foto'] = $foto_baru;

        echo "<script>
            alert('Profil Anda berhasil diperbarui!');
            window.location='profil.php';
        </script>";
        exit;
    } else {
        echo "<script>alert('Gagal memperbarui profil.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya | SKY Bookstore</title>
    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --shadow-md: 0 10px 25px rgba(78, 34, 15, 0.08);
            --radius-lg: 20px;
        }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }

        h1, h2, h3, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        /* NAVBAR */
        .navbar-custom {
            background: var(--brand-dark-brown);
            padding: 14px 0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }

        .navbar-brand {
            color: #FFFFFF !important;
            font-weight: 800;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.85) !important;
            margin: 0 8px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.2s ease;
        }

        .nav-link:hover, .nav-link.active {
            color: #FFFFFF !important;
        }

        /* CARD & AVATAR STYLING */
        .card-custom {
            background: #FFFFFF;
            border: 1px solid rgba(78, 34, 15, 0.08);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
        }

        .user-avatar-preview {
            width: 130px;
            height: 130px;
            object-fit: cover;
            border-radius: 50%;
            border: 4px solid var(--brand-warm-brown);
            box-shadow: 0 8px 20px rgba(78, 34, 15, 0.12);
        }

        .form-control-custom {
            background: #FCF9F2;
            border: 1px solid #E6DCD1;
            border-radius: 12px;
            padding: 12px 16px;
            font-size: 14px;
            color: var(--brand-dark-brown);
        }

        .form-control-custom:focus {
            background: #FFFFFF;
            border-color: var(--brand-warm-brown);
            box-shadow: 0 0 0 4px rgba(157, 102, 56, 0.1);
        }

        .btn-save {
            background: var(--brand-warm-brown);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 12px;
            font-weight: 700;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .btn-save:hover {
            background: var(--brand-dark-brown);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(78, 34, 15, 0.2);
        }

        footer {
            background: var(--brand-dark-brown);
            color: var(--brand-cream-bg);
            padding: 40px 0 25px;
            margin-top: 80px;
            border-top: 4px solid var(--brand-warm-brown);
        }
    </style>
</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-custom sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fa-solid fa-book-open text-warning"></i>
                <span>SKY Bookstore</span>
            </a>

            <button class="navbar-toggler border-0 text-white shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
                <i class="fa-solid fa-bars-staggered"></i>
            </button>

            <div class="collapse navbar-collapse" id="menu">
                <ul class="navbar-nav ms-auto align-items-lg-center">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="kategori.php">Kategori</a></li>
                    <li class="nav-item"><a class="nav-link" href="wishlist.php"><i class="fa-regular fa-heart me-1"></i> Wishlist</a></li>
                    <li class="nav-item"><a class="nav-link" href="keranjang.php"><i class="fa-solid fa-cart-shopping me-1"></i> Keranjang</a></li>
                    <li class="nav-item"><a class="nav-link" href="history.php"><i class="fa-solid fa-clock-rotate-left me-1"></i> Riwayat</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- MAIN CONTENT CONTAINER -->
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-7 col-md-9">
                <div class="card-custom p-4 p-md-5">

                    <!-- HEADER TITLE -->
                    <div class="text-center mb-4">
                        <h3 class="font-heading fw-bold mb-1" style="color: var(--brand-dark-brown);">Pengaturan Profil Saya</h3>
                        <p class="text-muted small">Kelola informasi diri dan alamat pengiriman pesanan Anda</p>
                    </div>

                    <!-- PREVIEW AVATAR -->
                    <div class="text-center mb-4">
                        <?php 
                        $path_foto = "img/users/" . $user['foto'];
                        if (!empty($user['foto']) && file_exists($path_foto)) {
                            $avatar_src = $path_foto;
                        } else {
                            $avatar_src = "https://ui-avatars.com/api/?name=" . urlencode($user['nama']) . "&background=9D6638&color=fff&size=130";
                        }
                        ?>
                        <img src="<?= $avatar_src; ?>" alt="Foto Profil" id="avatarPreview" class="user-avatar-preview">
                    </div>

                    <!-- FORM EDIT PROFIL -->
                    <form method="POST" enctype="multipart/form-data">

                        <!-- Nama Lengkap -->
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">Nama Lengkap</label>
                            <input type="text" name="nama" class="form-control form-control-custom" value="<?= htmlspecialchars($user['nama']); ?>" required>
                        </div>

                        <!-- Email -->
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">Alamat Email</label>
                            <input type="email" name="email" class="form-control form-control-custom" value="<?= htmlspecialchars($user['email']); ?>" required>
                        </div>

                        <!-- No HP / WhatsApp -->
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">No. WhatsApp / HP</label>
                            <input type="text" name="no_hp" class="form-control form-control-custom" value="<?= htmlspecialchars($user['no_hp'] ?? ''); ?>" placeholder="Contoh: 081234567890">
                        </div>

                        <!-- Alamat Pengiriman -->
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted">Alamat Pengiriman Utama</label>
                            <textarea name="alamat" class="form-control form-control-custom" rows="3" placeholder="Masukkan alamat jalan, RT/RW, kecamatan, dan kota"><?= htmlspecialchars($user['alamat'] ?? ''); ?></textarea>
                        </div>

                        <!-- Upload Foto Profil -->
                        <div class="mb-4">
                            <label class="form-label small fw-bold text-muted">Ganti Foto Profil</label>
                            <input type="file" name="foto" id="fotoInput" class="form-control form-control-custom" accept="image/*" onchange="previewAvatar()">
                            <div class="form-text text-muted small" style="font-size: 11px;">
                                *Format gambar yang diperbolehkan: JPG, PNG, WEBP.
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <button type="submit" name="simpan" class="btn btn-save w-100 mb-2">
                            <i class="fa-solid fa-floppy-disk me-2"></i> Simpan Perubahan
                        </button>

                        <a href="index.php" class="btn btn-outline-secondary rounded-pill w-100 py-2 fw-semibold">
                            <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Beranda
                        </a>

                    </form>

                </div>
            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <footer class="text-center">
        <div class="container">
            <h5 class="fw-bold mb-2">SKY Bookstore</h5>
            <p class="small mb-0 opacity-75">&copy; <?= date("Y"); ?> SKY Bookstore. All Rights Reserved.</p>
        </div>
    </footer>

    <!-- SCRIPT INSTANT AVATAR PREVIEW -->
    <script>
        function previewAvatar() {
            const input = document.getElementById('fotoInput');
            const preview = document.getElementById('avatarPreview');

            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>