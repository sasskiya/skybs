<?php
session_start();
include "database.php";

// 1. Cek Hak Akses Admin
if (!isset($_SESSION['id_admin'])) {
    echo "<script>
        alert('Akses ditolak! Silakan login sebagai admin terlebih dahulu.');
        window.location='login.php';
    </script>";
    exit;
}

// 2. Validasi Parameter ID
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = (int)$_GET['id'];

// 3. Ambil Nama File Cover Sebelum Menghapus Data
    $stmt_cover = mysqli_prepare($conn, "SELECT cover FROM buku WHERE id_buku = ?");
    mysqli_stmt_bind_param($stmt_cover, "i", $id);
    mysqli_stmt_execute($stmt_cover);
    $res_cover = mysqli_stmt_get_result($stmt_cover);

    if ($data = mysqli_fetch_assoc($res_cover)) {
        
        // A. Hapus Relasi di Tabel Keranjang (Mencegah Constraint Error)
        $stmt_del_cart = mysqli_prepare($conn, "DELETE FROM keranjang WHERE id_buku = ?");
        mysqli_stmt_bind_param($stmt_del_cart, "i", $id);
        mysqli_stmt_execute($stmt_del_cart);

        // B. Hapus Relasi di Tabel Wishlist
        $stmt_del_wish = mysqli_prepare($conn, "DELETE FROM wishlist WHERE id_buku = ?");
        mysqli_stmt_bind_param($stmt_del_wish, "i", $id);
        mysqli_stmt_execute($stmt_del_wish);

        // C. Hapus Gambar Cover dari Folder jika Ada
        if (!empty($data['cover'])) {
            $file_cover = "img/buku/" . $data['cover'];
            if (file_exists($file_cover)) {
                unlink($file_cover);
            }
        }

        // D. Hapus Data Buku Utama dari Database
        $stmt_del = mysqli_prepare($conn, "DELETE FROM buku WHERE id_buku = ?");
        mysqli_stmt_bind_param($stmt_del, "i", $id);

        if (mysqli_stmt_execute($stmt_del)) {
            echo "<script>
                alert('Data buku berhasil dihapus secara permanen!');
                window.location='admin_buku.php';
            </script>";
            exit;
        } else {
            echo "<script>
                alert('Gagal menghapus data buku dari database.');
                window.location='admin_buku.php';
            </script>";
            exit;
        }
    } else {
        echo "<script>
            alert('Data buku tidak ditemukan!');
            window.location='admin_buku.php';
        </script>";
        exit;
    }
} else {
    header("Location: admin_buku.php");
    exit;
}
?>