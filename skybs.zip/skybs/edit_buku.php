<?php
session_start();
include "database.php";

// 1. Cek Autentikasi Admin
if (!isset($_SESSION['id_admin'])) {
    header("Location: login.php");
    exit;
}

// 2. Validasi Parameter ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: admin_buku.php");
    exit;
}

$id = (int)$_GET['id'];

// 3. Ambil Data Buku Berdasarkan ID
$stmt = mysqli_prepare($conn, "SELECT * FROM buku WHERE id_buku = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$data) {
    echo "<script>
        alert('Data buku tidak ditemukan!');
        window.location='admin_buku.php';
    </script>";
    exit;
}

// 4. Ambil Daftar Kategori untuk Option Select
$kategori = mysqli_query($conn, "SELECT * FROM kategori ORDER BY nama_kategori ASC");

// 5. Eksekusi Proses Update
if (isset($_POST['update'])) {
    $id_kategori = (int)$_POST['id_kategori'];
    $judul       = trim($_POST['judul']);
    $penulis     = trim($_POST['penulis']);
    $harga       = (double)$_POST['harga'];
    $rating      = trim($_POST['rating']);
    $stok        = (int)$_POST['stok'];
    $badge       = trim($_POST['badge']);
    $deskripsi   = trim($_POST['deskripsi']);

    $cover = $data['cover']; // Default menggunakan cover lama

    // Cek Jika Ada Upload Cover Baru
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['cover']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($ext, $allowed)) {
            $cover_baru = time() . "_" . rand(100, 999) . "." . $ext;
            $target_folder = "img/buku/";

            // Buat folder jika belum ada
            if (!is_dir($target_folder)) {
                mkdir($target_folder, 0777, true);
            }

            // Upload File Baru
            if (move_uploaded_file($_FILES['cover']['tmp_name'], $target_folder . $cover_baru)) {
                // Hapus Cover Lama Jika Ada
                if (!empty($data['cover']) && file_exists($target_folder . $data['cover'])) {
                    unlink($target_folder . $data['cover']);
                }
                $cover = $cover_baru;
            }
        }
    }

    // Eksekusi Query UPDATE ke Database
    $query_update = "UPDATE buku SET 
                        id_kategori = ?, 
                        judul = ?, 
                        penulis = ?, 
                        harga = ?, 
                        rating = ?, 
                        stok = ?, 
                        badge = ?, 
                        cover = ?, 
                        deskripsi = ? 
                     WHERE id_buku = ?";

    $stmt_up = mysqli_prepare($conn, $query_update);
    mysqli_stmt_bind_param(
        $stmt_up, 
        "issdissssi", 
        $id_kategori, 
        $judul, 
        $penulis, 
        $harga, 
        $rating, 
        $stok, 
        $badge, 
        $cover, 
        $deskripsi, 
        $id
    );

    if (mysqli_stmt_execute($stmt_up)) {
        echo "<script>
            alert('Data buku berhasil diperbarui!');
            window.location='admin_buku.php';
        </script>";
        exit;
    } else {
        echo "<script>alert('Gagal mengupdate data buku.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Buku | SKYBS Admin</title>

    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --shadow-md: 0 10px 25px rgba(78, 34, 15, 0.08);
            --radius-lg: 20px;
        }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }

        h1, h2, h3, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        /* --- NAVBAR --- */
        .navbar-custom {
            background: var(--brand-dark-brown);
            padding: 14px 0;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }

        .navbar-brand {
            color: #FFFFFF !important;
            font-weight: 800;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .navbar-brand img {
            max-height: 40px;
            width: auto;
            object-fit: contain;
            border-radius: 6px;
        }

        .brand-badge {
            background: rgba(176, 186, 153, 0.25);
            border: 1px solid var(--brand-sage-green);
            color: var(--brand-sage-green);
            padding: 4px 10px;
            border-radius: 8px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 700;
        }

        /* --- CARD & FORM STYLING --- */
        .card-custom {
            background: #FFFFFF;
            border: 1px solid rgba(78, 34, 15, 0.08);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
        }

        .form-control-custom, .form-select-custom {
            background: var(--brand-cream-bg);
            border: 1px solid rgba(78, 34, 15, 0.15);
            border-radius: 12px;
            padding: 10px 16px;
            font-size: 14px;
            color: var(--brand-dark-brown);
        }

        .form-control-custom:focus, .form-select-custom:focus {
            background: #FFFFFF;
            border-color: var(--brand-warm-brown);
            box-shadow: 0 0 0 4px rgba(157, 102, 56, 0.15);
            color: var(--brand-dark-brown);
        }

        .preview-cover {
            width: 110px;
            height: 155px;
            object-fit: cover;
            border-radius: 12px;
            border: 2px solid var(--brand-warm-brown);
            box-shadow: 0 4px 12px rgba(78, 34, 15, 0.15);
        }

        .btn-save {
            background: var(--brand-warm-brown);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 10px 24px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-save:hover {
            background: var(--brand-dark-brown);
            color: white;
            transform: translateY(-2px);
        }

        footer {
            background: var(--brand-dark-brown);
            color: var(--brand-cream-bg);
            margin-top: 80px;
            padding: 25px 0;
            font-size: 13px;
            border-top: 4px solid var(--brand-warm-brown);
        }
    </style>
</head>

<body>

    <!-- NAVBAR ADMIN -->
    <nav class="navbar navbar-custom sticky-top">
        <div class="container">
            <!-- LOGO KIRI -->
            <a href="admin.php" class="navbar-brand">
                <img src="assets/img/logo.png" alt="SKYBS Logo" onerror="this.style.display='none'; document.getElementById('fallback-icon').style.display='inline-block';">
                <i id="fallback-icon" class="fa-solid fa-book-open text-warning me-1" style="display:none;"></i>
                <span>SKYBS Admin</span>
                <span class="brand-badge ms-1">Panel</span>
            </a>
            <a href="admin_buku.php" class="btn btn-sm btn-outline-light rounded-pill px-3">
                <i class="fa-solid fa-book me-1"></i> Data Buku
            </a>
        </div>
    </nav>

    <!-- CONTENT CONTAINER -->
    <div class="container py-5">

        <!-- HEADER TITLE -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <h2 class="font-heading fw-bold mb-1" style="color: var(--brand-dark-brown);">Edit Data Buku</h2>
                <p class="text-muted mb-0">Perbarui rincian informasi, harga, dan stok katalog buku SKYBS</p>
            </div>
            <a href="admin_buku.php" class="btn btn-outline-secondary rounded-pill px-4 btn-sm fw-semibold">
                <i class="fa-solid fa-arrow-left me-2"></i>Kembali
            </a>
        </div>

        <!-- FORM CARD -->
        <div class="card-custom p-4 p-md-5">
            <form method="POST" enctype="multipart/form-data">
                <div class="row g-4">
                    
                    <!-- Kategori Buku -->
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-muted">Kategori Buku</label>
                        <select name="id_kategori" class="form-select form-select-custom" required>
                            <option value="">-- Pilih Kategori --</option>
                            <?php while ($k = mysqli_fetch_assoc($kategori)): ?>
                                <option value="<?= $k['id_kategori']; ?>" <?= ($data['id_kategori'] == $k['id_kategori']) ? 'selected' : ''; ?>>
                                    <?= htmlspecialchars($k['nama_kategori']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <!-- Judul Buku -->
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-muted">Judul Buku</label>
                        <input type="text" name="judul" value="<?= htmlspecialchars($data['judul']); ?>" class="form-control form-control-custom" required>
                    </div>

                    <!-- Penulis -->
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-muted">Penulis</label>
                        <input type="text" name="penulis" value="<?= htmlspecialchars($data['penulis']); ?>" class="form-control form-control-custom" required>
                    </div>

                    <!-- Harga -->
                    <div class="col-md-3">
                        <label class="form-label small fw-bold text-muted">Harga (Rp)</label>
                        <input type="number" name="harga" value="<?= $data['harga']; ?>" class="form-control form-control-custom" step="1000" required>
                    </div>

                    <!-- Stok -->
                    <div class="col-md-3">
                        <label class="form-label small fw-bold text-muted">Stok Buku</label>
                        <input type="number" name="stok" value="<?= $data['stok']; ?>" class="form-control form-control-custom" min="0" required>
                    </div>

                    <!-- Rating -->
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-muted">Rating (Contoh: 4.8)</label>
                        <input type="text" name="rating" value="<?= htmlspecialchars($data['rating']); ?>" class="form-control form-control-custom" placeholder="4.5">
                    </div>

                    <!-- Badge Label -->
                    <div class="col-md-6">
                        <label class="form-label small fw-bold text-muted">Badge Label (Contoh: Best Seller / Promo)</label>
                        <input type="text" name="badge" value="<?= htmlspecialchars($data['badge']); ?>" class="form-control form-control-custom" placeholder="Misal: Best Seller">
                    </div>

                    <!-- Preview & Upload Cover Buku -->
                    <div class="col-md-12">
                        <label class="form-label small fw-bold text-muted">Cover Buku</label>
                        <div class="d-flex flex-column flex-sm-row align-items-sm-center gap-3">
                            <?php 
                            $path_cover = "img/buku/" . $data['cover'];
                            if (!empty($data['cover']) && file_exists($path_cover)) {
                                $img_src = $path_cover;
                            } else {
                                $img_src = "https://via.placeholder.com/110x155?text=No+Cover";
                            }
                            ?>
                            <img src="<?= $img_src; ?>" alt="Cover Saat Ini" id="imgPreview" class="preview-cover">
                            <div>
                                <input type="file" name="cover" id="coverInput" class="form-control form-control-custom mb-1" accept="image/*" onchange="previewImage()">
                                <small class="text-muted d-block" style="font-size: 12px;">
                                    *Pilih berkas gambar baru (JPG, PNG, WEBP) jika ingin mengganti sampul.
                                </small>
                            </div>
                        </div>
                    </div>

                    <!-- Deskripsi Buku -->
                    <div class="col-md-12">
                        <label class="form-label small fw-bold text-muted">Deskripsi Buku / Sinopsis</label>
                        <textarea name="deskripsi" class="form-control form-control-custom" rows="5" required><?= htmlspecialchars($data['deskripsi']); ?></textarea>
                    </div>

                    <!-- Action Buttons -->
                    <div class="col-md-12 d-flex gap-2 pt-3">
                        <button type="submit" name="update" class="btn btn-save">
                            <i class="fa-solid fa-floppy-disk me-1"></i> Simpan Perubahan
                        </button>
                        <a href="admin_buku.php" class="btn btn-outline-secondary rounded-pill px-4 fw-semibold">Batal</a>
                    </div>

                </div>
            </form>
        </div>

    </div>

    <!-- FOOTER -->
    <footer class="text-center">
        <div class="container">
            <p class="mb-0">&copy; <?= date('Y') ?> SKY BookStore. Admin Dashboard System.</p>
        </div>
    </footer>

    <!-- PREVIEW IMAGE JS -->
    <script>
        function previewImage() {
            const input = document.getElementById('coverInput');
            const preview = document.getElementById('imgPreview');
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>