<?php
session_start();
include "database.php";

// =========================================
// CEK LOGIN ADMIN
// =========================================
if (!isset($_SESSION['id_admin'])) {
    echo "<script>
        alert('Silakan login sebagai Admin!');
        window.location='login.php';
    </script>";
    exit;
}

// Nama admin default
$nama_admin = isset($_SESSION['nama']) && !empty($_SESSION['nama'])
    ? $_SESSION['nama']
    : 'Saskiya';

$pesan = "";

// Buat tabel war_books jika belum ada
mysqli_query($conn, "
    CREATE TABLE IF NOT EXISTS war_books (
        id_war_book INT AUTO_INCREMENT PRIMARY KEY,
        id_buku INT NOT NULL,
        status_war VARCHAR(20) DEFAULT 'Ditutup'
    )
");

// =========================================
// 1. PROSES UPDATE JADWAL EVENT WAR
// =========================================
if (isset($_POST['simpan_jadwal'])) {
    $nama_event = trim($_POST['nama_event']);
    $mulai = $_POST['waktu_mulai'];
    $selesai = $_POST['waktu_selesai'];

    if (strtotime($selesai) <= strtotime($mulai)) {
        $pesan = "❌ Waktu selesai harus lebih besar dari waktu mulai!";
    } else {
        $stmt_check = mysqli_query($conn, "SELECT id FROM pengaturan_war WHERE id = 1");

        if (mysqli_num_rows($stmt_check) == 0) {
            $stmt = mysqli_prepare($conn, "INSERT INTO pengaturan_war (id, nama_event, waktu_mulai, waktu_selesai) VALUES (1, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "sss", $nama_event, $mulai, $selesai);
            mysqli_stmt_execute($stmt);
        } else {
            $stmt = mysqli_prepare($conn, "UPDATE pengaturan_war SET nama_event = ?, waktu_mulai = ?, waktu_selesai = ? WHERE id = 1");
            mysqli_stmt_bind_param($stmt, "sss", $nama_event, $mulai, $selesai);
            mysqli_stmt_execute($stmt);
        }
        $pesan = "✅ Jadwal event War berhasil diperbarui!";
    }
}

// =========================================
// 2. PROSES TAMBAH BUKU WAR EKSKLUSIF
// =========================================
if (isset($_POST['tambah_buku_war'])) {
    $judul = trim($_POST['judul_war']);
    $penulis = trim($_POST['penulis_war']);
    $harga = (float)$_POST['harga_war'];
    $stok = (int)$_POST['stok_war'];
    $deskripsi = trim($_POST['deskripsi_war']);
    $id_kategori = 1; // Kategori default fiksi/umum

    if (empty($judul) || empty($_FILES['cover_war']['name'])) {
        $pesan = "❌ Judul dan Cover buku wajib diisi!";
    } else {
        $nama_file = $_FILES['cover_war']['name'];
        $tmp_name = $_FILES['cover_war']['tmp_name'];
        $ekstensi = strtolower(pathinfo($nama_file, PATHINFO_EXTENSION));
        $nama_baru = "war_" . time() . "_" . rand(100, 999) . "." . $ekstensi;

        if (!is_dir("img/war")) {
            mkdir("img/war", 0777, true);
        }

        if (move_uploaded_file($tmp_name, "img/war/" . $nama_baru)) {
            $stmt = mysqli_prepare($conn, "INSERT INTO buku (id_kategori, judul, penulis, harga, stok, deskripsi, cover, tipe_buku) VALUES (?, ?, ?, ?, ?, ?, ?, 'war')");
            mysqli_stmt_bind_param($stmt, "issdiss", $id_kategori, $judul, $penulis, $harga, $stok, $deskripsi, $nama_baru);
            mysqli_stmt_execute($stmt);
            $id_buku_baru = mysqli_insert_id($conn);

            $stmt_war = mysqli_prepare($conn, "INSERT INTO war_books (id_buku, status_war) VALUES (?, 'Ditutup')");
            mysqli_stmt_bind_param($stmt_war, "i", $id_buku_baru);
            mysqli_stmt_execute($stmt_war);

            $pesan = "✅ Buku War berhasil ditambahkan ke zona eksklusif!";
        } else {
            $pesan = "❌ Gagal mengupload cover buku war.";
        }
    }
}

// =========================================
// 3. PROSES EDIT BUKU WAR
// =========================================
if (isset($_POST['update_buku_war'])) {
    $id_buku = (int)$_POST['id_buku'];
    $judul = trim($_POST['judul']);
    $penulis = trim($_POST['penulis']);
    $harga = (float)$_POST['harga'];
    $stok = (int)$_POST['stok'];
    $deskripsi = trim($_POST['deskripsi']);

    if (!empty($_FILES['cover']['name'])) {
        $nama_file = $_FILES['cover']['name'];
        $tmp_name = $_FILES['cover']['tmp_name'];
        $ekstensi = strtolower(pathinfo($nama_file, PATHINFO_EXTENSION));
        $nama_baru = "war_" . time() . "_" . rand(100, 999) . "." . $ekstensi;

        if (move_uploaded_file($tmp_name, "img/war/" . $nama_baru)) {
            $stmt = mysqli_prepare($conn, "UPDATE buku SET judul = ?, penulis = ?, harga = ?, stok = ?, deskripsi = ?, cover = ? WHERE id_buku = ?");
            mysqli_stmt_bind_param($stmt, "ssdsssi", $judul, $penulis, $harga, $stok, $deskripsi, $nama_baru, $id_buku);
            mysqli_stmt_execute($stmt);
        }
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE buku SET judul = ?, penulis = ?, harga = ?, stok = ?, deskripsi = ? WHERE id_buku = ?");
        mysqli_stmt_bind_param($stmt, "ssdssi", $judul, $penulis, $harga, $stok, $deskripsi, $id_buku);
        mysqli_stmt_execute($stmt);
    }
    $pesan = "✅ Buku War berhasil diperbarui!";
}

// =========================================
// 3.B. HAPUS BUKU WAR
// =========================================
if (isset($_GET['hapus_war'])) {
    $id_hapus = (int)$_GET['hapus_war'];
    mysqli_query($conn, "DELETE FROM war_books WHERE id_buku = $id_hapus");
    mysqli_query($conn, "DELETE FROM buku WHERE id_buku = $id_hapus AND tipe_buku = 'war'");
    $pesan = "✅ Buku War berhasil dihapus dari sistem.";
}

// =========================================
// 4. PROSES UBAH STATUS SESI WAR
// =========================================
if (isset($_GET['ubah_status']) && isset($_GET['id'])) {
    $id_buku_status = (int)$_GET['id'];
    $status_baru = $_GET['ubah_status'];

    if (in_array($status_baru, ['Dibuka', 'Ditutup'])) {
        $stmt_status = mysqli_prepare($conn, "UPDATE war_books SET status_war = ? WHERE id_buku = ?");
        mysqli_stmt_bind_param($stmt_status, "si", $status_baru, $id_buku_status);
        mysqli_stmt_execute($stmt_status);
        $pesan = "✅ Status sesi War berhasil diperbarui menjadi $status_baru!";
    }
}

// =========================================
// 5. AMBIL JADWAL & DATA BUKU WAR
// =========================================
$query_jadwal = mysqli_query($conn, "SELECT * FROM pengaturan_war WHERE id = 1");
$jadwal = mysqli_fetch_assoc($query_jadwal);

$nama_event_val = $jadwal['nama_event'] ?? 'War Tiket Eksklusif';
$waktu_mulai_val = isset($jadwal['waktu_mulai']) ? date('Y-m-d\TH:i', strtotime($jadwal['waktu_mulai'])) : date('Y-m-d\TH:i');
$waktu_selesai_val = isset($jadwal['waktu_selesai']) ? date('Y-m-d\TH:i', strtotime($jadwal['waktu_selesai'])) : date('Y-m-d\TH:i', strtotime('+3 days'));

$query_buku_war = mysqli_query($conn, "
    SELECT buku.*, war_books.status_war 
    FROM war_books
    JOIN buku ON buku.id_buku = war_books.id_buku
    ORDER BY buku.id_buku DESC
");

$query_peserta_war = mysqli_query($conn, "
    SELECT transaksi.*, users.nama, users.email, users.no_hp
    FROM transaksi
    JOIN users ON transaksi.id_user = users.id_user
    WHERE transaksi.tipe = 'war'
    ORDER BY transaksi.id_transaksi DESC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen War Tiket | SKYBS Admin</title>

    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

    <style>
        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --brand-card-bg: #FCF9F0;
            --shadow-sm: 0 4px 18px rgba(78, 34, 15, 0.05);
            --shadow-md: 0 10px 25px rgba(78, 34, 15, 0.1);
            --radius-lg: 20px;
        }

        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }

        h1, h2, h3, h4, h5, .font-heading {
            font-family: 'Playfair Display', serif;
        }

        /* --- SIDEBAR NAVIGATION --- */
        .sidebar {
            width: 270px;
            height: 100vh;
            background: var(--brand-dark-brown);
            position: fixed;
            left: 0;
            top: 0;
            z-index: 1000;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            display: flex;
            flex-direction: column;
        }

        .sidebar-brand {
            color: white;
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.12);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-badge {
            background: rgba(176, 186, 153, 0.25);
            border: 1px solid var(--brand-sage-green);
            color: var(--brand-sage-green);
            padding: 2px 8px;
            border-radius: 6px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 700;
        }

        .sidebar-menu {
            padding: 20px 0;
            flex-grow: 1;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            padding: 13px 25px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }

        .sidebar a i {
            width: 32px;
            font-size: 16px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: rgba(255, 255, 255, 0.12);
            color: #FFFFFF;
            border-left-color: var(--brand-warm-brown);
        }

        .btn-view-website {
            margin: 18px 20px 0;
            padding: 12px 16px !important;
            border-radius: 10px;
            background: var(--brand-sage-green);
            color: var(--brand-dark-brown) !important;
            border: 1px solid var(--brand-sage-green) !important;
            font-weight: 700 !important;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .btn-view-website:hover {
            background: #DCCFC0;
            color: var(--brand-dark-brown) !important;
            transform: translateY(-2px);
        }

        .btn-logout {
            background: rgba(220, 53, 69, 0.15);
            color: #FF6B6B;
            border: 1px solid rgba(220, 53, 69, 0.2);
            width: 100%;
            border-radius: 12px;
            padding: 10px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .btn-logout:hover {
            background: #DC3545;
            color: white;
        }

        /* --- CONTENT AREA --- */
        .content {
            margin-left: 270px;
            padding: 35px 40px;
        }

        .card-custom {
            background: var(--brand-card-bg);
            border: 1px solid rgba(78, 34, 15, 0.08);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            overflow: hidden;
            margin-bottom: 30px;
            transition: all 0.3s ease;
        }

        .card-custom:hover {
            box-shadow: var(--shadow-md);
        }

        /* TABEL STYLING */
        .table-custom {
            margin-bottom: 0;
            vertical-align: middle;
            background: #ffffff;
        }

        .table-custom thead {
            background: var(--brand-dark-brown) !important;
        }

        .table-custom thead th {
            color: #ffffff !important;
            font-weight: 700;
            font-size: 12px;
            letter-spacing: 0.8px;
            text-transform: uppercase;
            padding: 16px 20px;
            border: none;
            background-color: var(--brand-dark-brown) !important;
        }

        .table-custom tbody td {
            padding: 16px 20px;
            border-bottom: 1px solid rgba(78, 34, 15, 0.06);
            font-size: 14px;
            color: var(--brand-dark-brown);
        }

        /* FORM & INPUT */
        .form-control, .form-select {
            border-radius: 12px;
            border-color: #d1c2a5;
            padding: 10px 15px;
            font-size: 14px;
            background-color: #fff;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--brand-warm-brown);
            box-shadow: 0 0 0 0.2rem rgba(157, 102, 56, 0.15);
        }

        .form-label {
            font-weight: 600;
            font-size: 13px;
            color: var(--brand-dark-brown);
            margin-bottom: 6px;
        }

        /* TOMBOL CUSTOM */
        .btn-dark-custom {
            background: var(--brand-dark-brown);
            border: none;
            color: white;
            border-radius: 12px;
            padding: 10px 20px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-dark-custom:hover {
            background: #351507;
            color: white;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(78, 34, 15, 0.2);
        }

        .book-cover {
            width: 50px;
            height: 70px;
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(78, 34, 15, 0.1);
        }

        .profile-badge {
            background: #FFFFFF;
            padding: 8px 18px;
            border-radius: 50px;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(78, 34, 15, 0.08);
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        @media (max-width: 992px) {
            .sidebar { width: 100%; height: auto; position: relative; }
            .content { margin-left: 0; padding: 20px; }
        }
    </style>
</head>

<body>

    <!-- SIDEBAR NAVIGATION -->
    <div class="sidebar">
        <div class="sidebar-brand">
            <i class="fa-solid fa-book-open text-warning fs-4"></i>
            <div>
                <h5 class="fw-bold mb-0 text-white">SKYBS Admin</h5>
                <span class="brand-badge">Panel System</span>
            </div>
        </div>

        <div class="sidebar-menu">
            <a href="admin.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
            <a href="admin_kategori.php"><i class="fa-solid fa-tags"></i> Kategori Buku</a>
            <a href="admin_buku.php"><i class="fa-solid fa-book"></i> Data Buku</a>
            <a href="admin_user.php"><i class="fa-solid fa-users"></i> Data User</a>
            <a href="admin_pesanan.php"><i class="fa-solid fa-cart-shopping"></i> Pesanan</a>
            <a href="admin_war.php" class="active"><i class="fa-solid fa-ticket"></i> War Tiket</a>
            <a href="admin_contact.php"><i class="fa-solid fa-comments"></i> Pesan User</a>

            <a href="index.php" target="_blank" class="btn-view-website">
                <i class="fa-solid fa-eye"></i> Buka Full Website
            </a>
        </div>

        <div class="p-3">
            <form action="logout.php" method="POST">
                <button type="submit" class="btn btn-logout d-flex align-items-center justify-content-center gap-2" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <span>Logout</span>
                </button>
            </form>
        </div>
    </div>

    <!-- MAIN CONTENT AREA -->
    <div class="content">

        <!-- HEADER TOPBAR -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 pb-3 border-bottom border-secondary-subtle">
            <div>
                <h2 class="font-heading fw-bold mb-1">Manajemen War Tiket</h2>
                <p class="text-muted small mb-0">Atur jadwal event countdown, tambah buku eksklusif war secara dinamis, kontrol status sesi, dan pantau pemenang.</p>
            </div>
            <div>
                <div class="profile-badge">
                    <i class="fa-solid fa-user-gear fs-5" style="color: var(--brand-warm-brown);"></i>
                    <span class="fw-bold fs-6" style="color: var(--brand-dark-brown);"><?= htmlspecialchars($nama_admin); ?> (Admin)</span>
                </div>
            </div>
        </div>

        <?php if (!empty($pesan)): ?>
            <div class="alert alert-warning alert-dismissible fade show rounded-4 mb-4 shadow-sm" role="alert">
                <?= htmlspecialchars($pesan); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- 1. PANEL JADWAL -->
        <div class="card-custom p-4">
            <h4 class="font-heading fw-bold mb-3" style="color: var(--brand-dark-brown);">
                <i class="fa-solid fa-stopwatch text-warning me-2"></i>Atur Waktu & Jadwal Countdown Event War
            </h4>
            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Nama Event / Edisi War</label>
                        <input type="text" name="nama_event" class="form-control" value="<?= htmlspecialchars($nama_event_val); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Waktu Mulai</label>
                        <input type="datetime-local" name="waktu_mulai" class="form-control" value="<?= $waktu_mulai_val; ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Waktu Selesai (Batas Timer)</label>
                        <input type="datetime-local" name="waktu_selesai" class="form-control" value="<?= $waktu_selesai_val; ?>" required>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" name="simpan_jadwal" class="btn btn-dark-custom w-100 py-2">
                            <i class="fa-solid fa-floppy-disk me-1"></i> Simpan
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- 2. PANEL TAMBAH BUKU WAR -->
        <div class="card-custom p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="font-heading fw-bold mb-0" style="color: var(--brand-dark-brown);">
                    <i class="fa-solid fa-plus-circle text-warning me-2"></i>Tambah Buku War Eksklusif
                </h4>
                <span class="badge bg-danger rounded-pill px-3 py-2">Khusus War Ticket</span>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Judul Buku</label>
                        <input type="text" name="judul_war" class="form-control" placeholder="Masukkan judul buku War" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Penulis</label>
                        <input type="text" name="penulis_war" class="form-control" placeholder="Masukkan nama penulis" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Harga (Contoh: 90000)</label>
                        <input type="number" name="harga_war" class="form-control" min="0" placeholder="Rp" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Stok</label>
                        <input type="number" name="stok_war" class="form-control" min="0" placeholder="Jumlah stok" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Cover Buku</label>
                        <input type="file" name="cover_war" class="form-control" accept="image/*" required>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label">Deskripsi / Sinopsis</label>
                        <textarea name="deskripsi_war" class="form-control" rows="3" placeholder="Masukkan sinopsis buku..." required></textarea>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" name="tambah_buku_war" class="btn btn-dark-custom px-4">
                            <i class="fa-solid fa-plus me-2"></i> Tambahkan ke Buku War
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- 3. DAFTAR BUKU WAR -->
        <div class="card-custom p-4">
            <h4 class="font-heading fw-bold mb-3" style="color: var(--brand-dark-brown);">
                <i class="fa-solid fa-book-bookmark text-warning me-2"></i>Daftar Buku War & Kontrol Status Sesi
            </h4>
            <div class="table-responsive">
                <table class="table table-custom align-middle">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 70px;">Cover</th>
                            <th>Judul Buku War</th>
                            <th>Penulis</th>
                            <th>Harga & Stok</th>
                            <th class="text-center">Status Sesi War</th>
                            <th class="text-center" style="width: 280px;">Aksi / Ubah Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($query_buku_war && mysqli_num_rows($query_buku_war) > 0): ?>
                            <?php while ($bw = mysqli_fetch_assoc($query_buku_war)): ?>
                                <?php $status_sekarang = $bw['status_war'] ?? 'Ditutup'; ?>
                                <tr>
                                    <td class="text-center">
                                        <img src="img/war/<?= htmlspecialchars($bw['cover']); ?>" alt="Cover" class="book-cover" onerror="this.src='img/buku/<?= htmlspecialchars($bw['cover']); ?>'">
                                    </td>
                                    <td class="fw-bold">
                                        <?= htmlspecialchars($bw['judul']); ?><br>
                                        <small class="text-muted fw-normal">ID Buku: <?= $bw['id_buku']; ?></small>
                                    </td>
                                    <td><?= htmlspecialchars($bw['penulis']); ?></td>
                                    <td>
                                        <div class="text-success fw-bold">Rp <?= number_format($bw['harga'], 0, ',', '.'); ?></div>
                                        <small class="text-muted">Stok: <?= $bw['stok']; ?></small>
                                    </td>
                                    <td class="text-center">
                                        <?php if ($status_sekarang === 'Dibuka'): ?>
                                            <span class="badge bg-success rounded-pill px-3 py-2">War Dibuka</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary rounded-pill px-3 py-2">War Ditutup</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="d-flex justify-content-center gap-1 flex-wrap">
                                            <button type="button" class="btn btn-sm btn-outline-warning py-1 px-2 fw-semibold rounded-pill" data-bs-toggle="modal" data-bs-target="#editBukuModal<?= $bw['id_buku']; ?>">
                                                <i class="fa-solid fa-pen-to-square"></i> Edit
                                            </button>
                                            <?php if ($status_sekarang === 'Dibuka'): ?>
                                                <a href="admin_war.php?ubah_status=Ditutup&id=<?= $bw['id_buku']; ?>" class="btn btn-sm btn-outline-secondary py-1 px-2 fw-semibold rounded-pill" onclick="return confirm('Tutup sesi War buku ini?')">
                                                    <i class="fa-solid fa-ban"></i> Tutup
                                                </a>
                                            <?php else: ?>
                                                <a href="admin_war.php?ubah_status=Dibuka&id=<?= $bw['id_buku']; ?>" class="btn btn-sm btn-danger py-1 px-2 fw-semibold rounded-pill" onclick="return confirm('Buka sesi War buku ini?')">
                                                    <i class="fa-solid fa-bolt"></i> Buka
                                                </a>
                                            <?php endif; ?>
                                            <a href="admin_war.php?hapus_war=<?= $bw['id_buku']; ?>" class="btn btn-sm btn-outline-danger py-1 px-2 fw-semibold rounded-pill" onclick="return confirm('Hapus buku ini dari daftar war?')">
                                                <i class="fa-solid fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>

                                <!-- MODAL EDIT BUKU WAR -->
                                <div class="modal fade" id="editBukuModal<?= $bw['id_buku']; ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content rounded-4 border-0 shadow">
                                            <form method="POST" enctype="multipart/form-data">
                                                <div class="modal-header border-0 pb-0 pt-4 px-4">
                                                    <h5 class="modal-title font-heading fw-bold">Edit Buku War</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body text-start px-4">
                                                    <input type="hidden" name="id_buku" value="<?= $bw['id_buku']; ?>">
                                                    <div class="mb-3">
                                                        <label class="form-label">Judul Buku</label>
                                                        <input type="text" name="judul" class="form-control" value="<?= htmlspecialchars($bw['judul']); ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Penulis</label>
                                                        <input type="text" name="penulis" class="form-control" value="<?= htmlspecialchars($bw['penulis']); ?>" required>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <label class="form-label">Harga (Rp)</label>
                                                            <input type="number" name="harga" class="form-control" value="<?= (int)$bw['harga']; ?>" min="0" required>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label class="form-label">Stok</label>
                                                            <input type="number" name="stok" class="form-control" value="<?= $bw['stok']; ?>" min="0" required>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Deskripsi / Sinopsis</label>
                                                        <textarea name="deskripsi" class="form-control" rows="3" required><?= htmlspecialchars($bw['deskripsi']); ?></textarea>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Ganti Cover (Opsional)</label>
                                                        <input type="file" name="cover" class="form-control" accept="image/*">
                                                    </div>
                                                </div>
                                                <div class="modal-footer border-0 pt-0 pb-4 px-4">
                                                    <button type="button" class="btn btn-secondary rounded-pill px-3" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" name="update_buku_war" class="btn btn-dark-custom rounded-pill px-4">Simpan Perubahan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    <i class="fa-solid fa-book-open fs-1 opacity-50 mb-3 d-block"></i>
                                    Belum ada buku War. Silakan tambahkan buku eksklusif melalui form di atas.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- 4. DAFTAR PEMENANG WAR -->
        <div class="card-custom">
            <div class="p-4 border-bottom bg-white d-flex justify-content-between align-items-center">
                <h5 class="font-heading fw-bold m-0" style="color: var(--brand-dark-brown);">
                    <i class="fa-solid fa-trophy text-warning me-2"></i>Daftar Pemenang War Tiket
                </h5>
                <span class="badge bg-danger rounded-pill px-3 py-2">Live Data</span>
            </div>
            <div class="table-responsive">
                <table class="table table-custom align-middle">
                    <thead>
                        <tr>
                            <th class="ps-4">No. Tiket</th>
                            <th>Nama User</th>
                            <th>Kontak</th>
                            <th>Buku War yang Didapat</th>
                            <th>Total Harga</th>
                            <th class="text-center">Waktu War</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($query_peserta_war && mysqli_num_rows($query_peserta_war) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($query_peserta_war)): ?>
                                <?php
                                    $buku_id = (int)$row['id_buku'];
                                    $q_buku_info = mysqli_query($conn, "SELECT judul FROM buku WHERE id_buku = $buku_id");
                                    $d_buku_info = mysqli_fetch_assoc($q_buku_info);
                                    $info_buku = $d_buku_info['judul'] ?? 'Buku Eksklusif War #' . $buku_id;
                                    $kode_tiket = "SKYBS-WAR-" . str_pad($row['id_transaksi'], 5, "0", STR_PAD_LEFT);
                                ?>
                                <tr>
                                    <td class="ps-4"><span class="badge bg-danger rounded-pill px-2 py-1"><?= $kode_tiket; ?></span></td>
                                    <td class="fw-bold"><?= htmlspecialchars($row['nama']); ?></td>
                                    <td>
                                        <small class="d-block text-muted"><?= htmlspecialchars($row['email'] ?? '-'); ?></small>
                                        <small class="d-block text-muted"><?= htmlspecialchars($row['no_hp'] ?? '-'); ?></small>
                                    </td>
                                    <td><span class="fw-semibold text-dark"><?= htmlspecialchars($info_buku); ?></span></td>
                                    <td class="fw-bold text-success">Rp <?= number_format($row['total_harga'], 0, ',', '.'); ?></td>
                                    <td class="text-center"><small class="text-muted"><?= date("d M Y, H:i", strtotime($row['tanggal'])); ?></small></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    <i class="fa-solid fa-ticket-simple fs-1 opacity-50 mb-3 d-block"></i>
                                    Belum ada user yang mengikuti atau memenangkan War Tiket.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <footer class="mt-5 text-center text-muted small">
            <p class="mb-0">&copy; <?= date('Y'); ?> <strong>SKY Bookstore</strong> - Admin Dashboard System.</p>
        </footer>

    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>