<?php
session_start();
include "database.php";

// =========================================
// 1. CEK HAK AKSES ADMIN
// =========================================
if (!isset($_SESSION['id_admin'])) {
    echo "<script>
        alert('Akses ditolak! Silakan login sebagai admin.');
        window.location='login.php';
    </script>";
    exit;
}

// =========================================
// 2. PROSES TAMBAH BUKU BIASA
// =========================================
if (isset($_POST['simpan'])) {

    $id_kategori = (int)$_POST['id_kategori'];
    $judul       = trim($_POST['judul']);
    $penulis     = trim($_POST['penulis']);
    $harga       = (double)$_POST['harga'];
    $rating      = !empty($_POST['rating']) ? trim($_POST['rating']) : '0';
    $stok        = (int)$_POST['stok'];
    $badge       = !empty($_POST['badge']) ? trim($_POST['badge']) : '';
    $deskripsi   = trim($_POST['deskripsi']);

    // =========================================
    // OTOMATIS BUKU BIASA
    // =========================================
    $tipe_buku = 'biasa';

    $cover = "default.png";

    // =========================================
    // UPLOAD GAMBAR COVER BUKU
    // =========================================
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {

        $ext = strtolower(pathinfo($_FILES['cover']['name'], PATHINFO_EXTENSION));

        $allowed = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($ext, $allowed)) {

            $cover_baru = time() . "_" . rand(100, 999) . "." . $ext;

            $target_folder = "img/buku/";

            if (!is_dir($target_folder)) {
                mkdir($target_folder, 0777, true);
            }

            if (move_uploaded_file(
                $_FILES['cover']['tmp_name'],
                $target_folder . $cover_baru
            )) {
                $cover = $cover_baru;
            }
        }
    }

    // =========================================
    // INSERT KE DATABASE
    // =========================================
    $stmt_ins = mysqli_prepare($conn, "
        INSERT INTO buku
        (
            id_kategori,
            judul,
            penulis,
            harga,
            rating,
            stok,
            badge,
            cover,
            deskripsi,
            tipe_buku
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    mysqli_stmt_bind_param(
        $stmt_ins,
        "issdisssss",
        $id_kategori,
        $judul,
        $penulis,
        $harga,
        $rating,
        $stok,
        $badge,
        $cover,
        $deskripsi,
        $tipe_buku
    );


    if (mysqli_stmt_execute($stmt_ins)) {

        echo "<script>
            alert('Data buku berhasil ditambahkan!');
            window.location='admin_buku.php';
        </script>";

        exit;

    } else {

        echo "<script>
            alert('Gagal menambahkan data buku: " . mysqli_error($conn) . "');
        </script>";
    }
}

// =========================================
// 3. AMBIL KATEGORI BUKU
// =========================================
$kategori = mysqli_query(
    $conn,
    "SELECT * FROM kategori ORDER BY nama_kategori ASC"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tambah Buku Baru | SKYBS Admin</title>

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">


    <style>

        :root {
            --brand-dark-brown: #4E220F;
            --brand-warm-brown: #9D6638;
            --brand-sage-green: #B0BA99;
            --brand-cream-bg: #F7F1DE;
            --radius-lg: 20px;
        }


        body {
            background-color: var(--brand-cream-bg);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--brand-dark-brown);
            min-height: 100vh;
        }


        h1, h2, h3, .font-heading {
            font-family: 'Playfair Display', serif;
        }


        .navbar-custom {
            background: var(--brand-dark-brown);
            padding: 14px 0;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        }


        .navbar-brand {
            color: #FFFFFF !important;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 12px;
        }


        .card-custom {
            background: #FFFFFF;
            border-radius: var(--radius-lg);
            box-shadow: 0 10px 25px rgba(78,34,15,0.08);
            padding: 30px;
        }


        .form-control-custom {
            background: #FCF9F2;
            border: 1px solid #E6DCD1;
            border-radius: 12px;
            padding: 12px;
        }


        .form-control-custom:focus {
            background: #FFFFFF;
            border-color: var(--brand-warm-brown);
            box-shadow: 0 0 0 4px rgba(157,102,56,0.1);
        }


        .preview-cover {
            width: 120px;
            height: 160px;
            object-fit: cover;
            border-radius: 12px;
            border: 2px dashed var(--brand-warm-brown);
        }


        .btn-save {
            background: var(--brand-warm-brown);
            color: white;
            border-radius: 50px;
            padding: 10px 24px;
            font-weight: 700;
            border: none;
        }


        .btn-save:hover {
            background: var(--brand-dark-brown);
            color: white;
        }


        .info-box {
            background: #F7F1DE;
            border-left: 4px solid var(--brand-warm-brown);
            padding: 12px 16px;
            border-radius: 8px;
            font-size: 13px;
        }

    </style>

</head>


<body>

    <!-- =========================================
         NAVBAR
    ========================================= -->

    <nav class="navbar navbar-custom sticky-top">

        <div class="container">

            <a href="admin.php" class="navbar-brand">

                <i class="fa-solid fa-book-open"></i>

                SKYBS Admin Panel

            </a>

        </div>

    </nav>

    <!-- =========================================
         CONTENT
    ========================================= -->

    <div class="container py-5">


        <div class="d-flex justify-content-between align-items-center mb-4">

            <div>

                <h2 class="font-heading fw-bold mb-1">
                    Tambah Koleksi Buku
                </h2>

                <p class="text-muted mb-0">
                    Tambahkan buku reguler ke dalam katalog SKYBS BookStore.
                </p>

            </div>


            <a href="admin_buku.php"
               class="btn btn-outline-secondary rounded-pill px-4">

                <i class="fa-solid fa-arrow-left me-1"></i>
                Kembali

            </a>

        </div>

       <!-- INFO BUKU BIASA -->

        <div class="info-box mb-4">

            <i class="fa-solid fa-circle-info me-2"></i>

            Buku yang ditambahkan melalui halaman ini otomatis masuk ke katalog buku biasa,
            bukan ke War Ticket Eksklusif.

        </div>

        <!-- FORM TAMBAH BUKU -->

        <div class="card-custom">

            <form method="POST" enctype="multipart/form-data">


                <div class="row g-4">


                    <!-- KATEGORI -->

                    <div class="col-md-6">

                        <label class="small fw-bold text-muted">
                            Kategori Buku
                        </label>

                        <select name="id_kategori"
                                class="form-select form-control-custom"
                                required>

                            <option value="">
                                -- Pilih Kategori --
                            </option>


                            <?php while ($k = mysqli_fetch_assoc($kategori)): ?>

                                <option value="<?= $k['id_kategori']; ?>">

                                    <?= htmlspecialchars($k['nama_kategori']); ?>

                                </option>

                            <?php endwhile; ?>

                        </select>

                    </div>



                    <!-- JUDUL -->

                    <div class="col-md-6">

                        <label class="small fw-bold text-muted">
                            Judul Buku
                        </label>

                        <input type="text"
                               name="judul"
                               class="form-control form-control-custom"
                               placeholder="Masukkan judul buku"
                               required>

                    </div>

                    <!-- PENULIS -->

                    <div class="col-md-6">

                        <label class="small fw-bold text-muted">
                            Penulis
                        </label>

                        <input type="text"
                               name="penulis"
                               class="form-control form-control-custom"
                               placeholder="Masukkan nama penulis"
                               required>

                    </div>

                    <!-- HARGA -->

                    <div class="col-md-3">

                        <label class="small fw-bold text-muted">
                            Harga (Rp)
                        </label>

                        <input type="number"
                               name="harga"
                               class="form-control form-control-custom"
                               placeholder="0"
                               min="0"
                               required>

                    </div>

                    <!-- STOK -->

                    <div class="col-md-3">

                        <label class="small fw-bold text-muted">
                            Stok
                        </label>

                        <input type="number"
                               name="stok"
                               class="form-control form-control-custom"
                               placeholder="0"
                               min="0"
                               required>

                    </div>

                    <!-- RATING -->

                    <div class="col-md-6">

                        <label class="small fw-bold text-muted">
                            Rating
                        </label>

                        <input type="text"
                               name="rating"
                               class="form-control form-control-custom"
                               placeholder="Contoh: 4.8">

                    </div>

                    <!-- BADGE -->

                    <div class="col-md-6">

                        <label class="small fw-bold text-muted">
                            Badge Buku
                        </label>

                        <select name="badge"
                                class="form-select form-control-custom">

                            <option value="">
                                Tidak ada badge
                            </option>

                            <option value="Bestseller">
                                Bestseller
                            </option>

                            <option value="Baru">
                                Baru
                            </option>

                            <option value="Pilihan Editor">
                                Pilihan Editor
                            </option>

                        </select>

                    </div>

                    <!-- COVER -->

                    <div class="col-md-12">

                        <label class="small fw-bold text-muted">
                            Sampul Buku
                        </label>

                        <div class="d-flex align-items-center gap-3">

                            <img src="https://via.placeholder.com/120x160?text=Cover"
                                 id="imgPreview"
                                 class="preview-cover">


                            <input type="file"
                                   name="cover"
                                   id="coverInput"
                                   class="form-control form-control-custom"
                                   onchange="previewImage()"
                                   accept=".jpg,.jpeg,.png,.webp"
                                   required>

                        </div>

                        <small class="text-muted">
                            Format yang didukung: JPG, JPEG, PNG, WEBP.
                        </small>

                    </div>

                    <!-- DESKRIPSI -->

                    <div class="col-md-12">

                        <label class="small fw-bold text-muted">
                            Deskripsi / Sinopsis
                        </label>

                        <textarea name="deskripsi"
                                  class="form-control form-control-custom"
                                  rows="4"
                                  placeholder="Masukkan deskripsi atau sinopsis buku..."
                                  required></textarea>

                    </div>

                    <!-- TOMBOL SIMPAN -->

                    <div class="col-md-12 text-end">

                        <button type="submit"
                                name="simpan"
                                class="btn btn-save">

                            <i class="fa-solid fa-save me-2"></i>

                            Simpan Buku Biasa

                        </button>

                    </div>

                </div>

            </form>

        </div>

    </div>

    <!-- PREVIEW GAMBAR -->

    <script>

        function previewImage() {

            const input = document.getElementById('coverInput');

            const preview = document.getElementById('imgPreview');


            if (input.files && input.files[0]) {

                const reader = new FileReader();


                reader.onload = function(e) {
                    preview.src = e.target.result;
                };


                reader.readAsDataURL(input.files[0]);

            }

        }

    </script>


</body>

</html>