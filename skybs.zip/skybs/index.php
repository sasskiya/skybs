<?php
session_start();
include "database.php";

// Cek status login user
$is_logged_in = isset($_SESSION['id_user']);
$user_data = null;

if ($is_logged_in) {
    $id_user = (int)$_SESSION['id_user'];
    $stmt_user = mysqli_prepare($conn, "SELECT nama, foto FROM users WHERE id_user = ?");
    mysqli_stmt_bind_param($stmt_user, "i", $id_user);
    mysqli_stmt_execute($stmt_user);
    $res_user = mysqli_stmt_get_result($stmt_user);
    $user_data = mysqli_fetch_assoc($res_user);
}

// 1. Ambil Data Kategori
$query_kategori = mysqli_query($conn, "SELECT * FROM kategori ORDER BY nama_kategori ASC");

// 2. Ambil Pengaturan Jadwal War Tiket dari Database
$query_war_setting = mysqli_query($conn, "SELECT * FROM pengaturan_war WHERE id = 1");
$war_setting = mysqli_fetch_assoc($query_war_setting);

$waktu_mulai = $war_setting['waktu_mulai'] ?? date('Y-m-d H:i:s');
$waktu_selesai = $war_setting['waktu_selesai'] ?? date('Y-m-d H:i:s');
$nama_event = $war_setting['nama_event'] ?? 'War Tiket Eksklusif';

// Cek status waktu saat ini terhadap jadwal war (Server Time)
$current_time = time();
$timestamp_mulai = strtotime($waktu_mulai);
$timestamp_selesai = strtotime($waktu_selesai);

$is_war_active = ($current_time >= $timestamp_mulai && $current_time <= $timestamp_selesai);
$is_war_upcoming = ($current_time < $timestamp_mulai);
$is_war_ended = ($current_time > $timestamp_selesai);

// Ambil Daftar Buku War Dinamis dari Database (Hanya jika war aktif)
$query_buku_war = null;
if ($is_war_active) {
    $query_buku_war = mysqli_query($conn, "
        SELECT buku.*, war_books.status_war 
        FROM war_books
        JOIN buku ON buku.id_buku = war_books.id_buku
        WHERE war_books.status_war = 'Dibuka'
        ORDER BY buku.id_buku DESC
    ");
}

// 3. Filter Pencarian & Kategori Buku Reguler
$where_clause = "";
$search_keyword = "";
$selected_kategori = "";

if (isset($_GET['cari']) && !empty(trim($_GET['cari']))) {
    $search_keyword = trim(mysqli_real_escape_string($conn, $_GET['cari']));
    $where_clause = "WHERE (buku.judul LIKE '%$search_keyword%' OR buku.penulis LIKE '%$search_keyword%') AND (buku.tipe_buku != 'war' OR buku.tipe_buku IS NULL)";
} elseif (isset($_GET['kategori']) && !empty($_GET['kategori'])) {
    $selected_kategori = (int)$_GET['kategori'];
    $where_clause = "WHERE buku.id_kategori = $selected_kategori AND (buku.tipe_buku != 'war' OR buku.tipe_buku IS NULL)";
} else {
    $where_clause = "WHERE (buku.tipe_buku != 'war' OR buku.tipe_buku IS NULL)";
}

// 4. Pengaturan Paging (Limit & Batas Buku per Halaman)
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$allowed_limits = [10, 20, 30, 40, 50];
if (!in_array($limit, $allowed_limits)) {
    $limit = 10;
}

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

// Hitung total data buku reguler untuk paging
$query_count = mysqli_query($conn, "SELECT COUNT(*) as total FROM buku LEFT JOIN kategori ON buku.id_kategori = kategori.id_kategori $where_clause");
$row_count = mysqli_fetch_assoc($query_count);
$total_data = $row_count['total'];
$total_pages = ceil($total_data / $limit);

/* 5. Query Ambil Data Buku Reguler dengan Limit & Offset */
$query_buku = mysqli_query($conn, "
    SELECT buku.*, kategori.nama_kategori
    FROM buku
    LEFT JOIN kategori ON buku.id_kategori = kategori.id_kategori
    $where_clause
    ORDER BY buku.id_buku DESC
    LIMIT $limit OFFSET $offset
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SKY Bookstore | Toko Buku Online Terlengkap</title>
    <!-- Google Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    
    <style>
        :root {
            --brand-dark-brown: #3C180A;
            --brand-warm-brown: #8D5524;
            --brand-sage-green: #97A97C;
            --brand-cream-bg: #F7F1DE;
            --brand-card-bg: #FCF9F0;
            --shadow-sm: 0 4px 20px rgba(60, 24, 10, 0.05);
            --shadow-md: 0 12px 30px rgba(60, 24, 10, 0.08);
            --radius-lg: 24px;
        }
        body { 
            background-color: var(--brand-cream-bg); 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            color: var(--brand-dark-brown); 
            min-height: 100vh; 
        }
        h1, h2, h3, h4, .font-heading { font-family: 'Playfair Display', serif; }
        
        /* Navbar Modern & Responsif */
        .navbar-custom { 
            background: rgba(60, 24, 10, 0.95); 
            backdrop-filter: blur(10px);
            padding: 14px 0; 
            box-shadow: 0 4px 25px rgba(0, 0, 0, 0.1); 
        }
        .navbar-brand { color: #FFFFFF !important; font-weight: 800; font-size: 20px; display: flex; align-items: center; gap: 10px; }
        .nav-link { color: rgba(255, 255, 255, 0.85) !important; font-weight: 500; font-size: 14px; margin: 0 4px; transition: color 0.2s; }
        .nav-link:hover, .nav-link.active { color: #FFFFFF !important; }
        .user-avatar-nav { width: 34px; height: 34px; border-radius: 50%; object-fit: cover; border: 2px solid var(--brand-warm-brown); }

        /* Banner Promo Responsif */
        .banner-promo { 
            background: linear-gradient(135deg, #3C180A 0%, #8D5524 100%); 
            border-radius: var(--radius-lg); 
            color: white; 
            padding: 40px; 
            box-shadow: var(--shadow-md); 
            position: relative; 
            overflow: hidden; 
        }
        .btn-promo { 
            background: var(--brand-cream-bg); 
            color: var(--brand-dark-brown); 
            border: none; 
            border-radius: 50px; 
            padding: 10px 24px; 
            font-weight: 700; 
            font-size: 14px; 
            transition: all 0.3s ease; 
        }
        .btn-promo:hover { background: #FFFFFF; transform: translateY(-2px); }

        /* Card Buku Modern */
        .card-book { 
            background: var(--brand-card-bg); 
            border: 1px solid rgba(141, 85, 36, 0.12); 
            border-radius: var(--radius-lg); 
            overflow: hidden; 
            box-shadow: var(--shadow-sm); 
            transition: all 0.3s ease; 
            height: 100%; 
            display: flex; 
            flex-direction: column; 
        }
        .card-book:hover { transform: translateY(-6px); box-shadow: var(--shadow-md); }
        .book-cover-wrap { position: relative; height: 250px; overflow: hidden; background: #F4EEDC; }
        .book-cover-wrap img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease; }
        .card-book:hover .book-cover-wrap img { transform: scale(1.05); }
        .badge-book { position: absolute; top: 12px; left: 12px; padding: 6px 12px; border-radius: 50px; font-size: 11px; font-weight: 700; }
        .btn-wishlist-icon { position: absolute; top: 12px; right: 12px; width: 36px; height: 36px; background: rgba(255, 255, 255, 0.9); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #dc3545; text-decoration: none; transition: all 0.2s ease; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .btn-wishlist-icon:hover { transform: scale(1.1); }
        .price-tag { font-size: 16px; font-weight: 800; color: var(--brand-warm-brown); }
        
        .btn-custom-sm { 
            background: var(--brand-dark-brown); 
            color: white; 
            border: none; 
            border-radius: 12px; 
            padding: 8px 12px; 
            font-size: 13px; 
            font-weight: 600; 
            transition: all 0.2s ease; 
        }
        .btn-custom-sm:hover { background: var(--brand-warm-brown); color: white; }

        /* Kategori Pill Nav / Filter */
        .category-pills {
            display: flex;
            gap: 8px;
            overflow-x: auto;
            padding-bottom: 12px;
            scrollbar-width: none;
        }
        .category-pills::-webkit-scrollbar { display: none; }
        .pill-item {
            background: #ffffff;
            border: 1px solid rgba(141, 85, 36, 0.2);
            color: var(--brand-dark-brown);
            padding: 8px 18px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 600;
            white-space: nowrap;
            text-decoration: none;
            transition: all 0.2s;
            box-shadow: 0 2px 5px rgba(0,0,0,0.02);
        }
        .pill-item:hover, .pill-item.active {
            background: var(--brand-dark-brown);
            color: #ffffff;
            border-color: var(--brand-dark-brown);
        }

        .about-card { background: #FFFFFF; border-radius: var(--radius-lg); border: 1px solid rgba(141, 85, 36, 0.08); box-shadow: var(--shadow-sm); }
        .feature-icon-box { width: 55px; height: 55px; border-radius: 16px; background: #F4EEDC; color: var(--brand-dark-brown); display: flex; align-items: center; justify-content: center; font-size: 22px; margin-bottom: 12px; }
        
        footer { background: var(--brand-dark-brown); color: var(--brand-cream-bg); padding: 60px 0 25px; margin-top: 80px; border-top: 4px solid var(--brand-warm-brown); }
        footer a { color: #D4A373; text-decoration: none; transition: color 0.2s; }
        footer a:hover { color: #FFFFFF; }
    </style>
</head>
<body>

    <!-- NAVBAR RESPONSIF -->
    <nav class="navbar navbar-expand-lg navbar-custom sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fa-solid fa-book-open text-warning"></i>
                <span>SKY Bookstore</span>
            </a>
            <button class="navbar-toggler border-0 text-white shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#menuNav">
                <i class="fa-solid fa-bars-staggered fs-5"></i>
            </button>
            <div class="collapse navbar-collapse" id="menuNav">
                <ul class="navbar-nav me-auto mb-3 mb-lg-0 mt-3 mt-lg-0">
                    <li class="nav-item"><a class="nav-link active" href="index.php"><i class="fa-solid fa-house me-1"></i> Beranda</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"><i class="fa-solid fa-layer-group me-1"></i> Kategori</a>
                        <ul class="dropdown-menu border-0 shadow-sm rounded-4 p-2">
                            <li><a class="dropdown-item rounded-2 py-2" href="index.php">Semua Kategori</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <?php 
                            mysqli_data_seek($query_kategori, 0);
                            while ($kat = mysqli_fetch_assoc($query_kategori)): 
                            ?>
                                <li>
                                    <a class="dropdown-item rounded-2 py-2" href="index.php?kategori=<?= $kat['id_kategori']; ?>">
                                        <?= htmlspecialchars($kat['nama_kategori']); ?>
                                    </a>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="about.php"><i class="fa-solid fa-circle-info me-1"></i> Tentang Kami</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php"><i class="fa-solid fa-headset me-1"></i> Kontak</a></li>
                    <?php if ($is_logged_in): ?>
                        <li class="nav-item"><a class="nav-link" href="myticket.php"><i class="fa-solid fa-ticket me-1"></i> Tiket Saya</a></li>
                    <?php endif; ?>
                </ul>

                <div class="d-flex flex-column flex-lg-row align-items-lg-center gap-3 pt-3 pt-lg-0 border-top border-secondary border-opacity-25 border-lg-0">
                    <?php if ($is_logged_in): ?>
                        <div class="d-flex align-items-center gap-3">
                            <a href="wishlist.php" class="nav-link text-white position-relative" title="Wishlist">
                                <i class="fa-solid fa-heart fs-5"></i><span class="d-lg-none ms-2">Wishlist</span>
                            </a>
                            <a href="keranjang.php" class="nav-link text-white position-relative" title="Keranjang">
                                <i class="fa-solid fa-cart-shopping fs-5"></i><span class="d-lg-none ms-2">Keranjang Belanja</span>
                            </a>
                        </div>
                        <div class="dropdown">
                            <?php
                            $foto_user = "img/default.png";
                            if (!empty($user_data['foto'])) {
                                if (file_exists("img/users/" . $user_data['foto'])) $foto_user = "img/users/" . $user_data['foto'];
                                elseif (file_exists("img/" . $user_data['foto'])) $foto_user = "img/" . $user_data['foto'];
                            }
                            ?>
                            <button class="btn btn-sm btn-light rounded-pill px-3 py-1 dropdown-toggle fw-bold d-flex align-items-center gap-2 shadow-sm w-100 justify-content-center justify-content-lg-start" type="button" data-bs-toggle="dropdown">
                                <img src="<?= $foto_user; ?>" alt="Avatar" class="user-avatar-nav">
                                <span class="text-truncate" style="max-width: 130px;"><?= htmlspecialchars($user_data['nama']); ?></span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end border-0 shadow rounded-4 p-2">
                                <li><a class="dropdown-item rounded-2 py-2" href="profil.php"><i class="fa-solid fa-user-pen me-2"></i>Pengaturan Profil</a></li>
                                <li><a class="dropdown-item rounded-2 py-2" href="history.php"><i class="fa-solid fa-clock-rotate-left me-2"></i>Riwayat Pesanan</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item rounded-2 py-2 text-danger" href="logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i>Logout</a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <div class="d-flex gap-2 w-100">
                            <a href="login.php" class="btn btn-sm btn-outline-light rounded-pill px-4 fw-semibold flex-fill py-2"><i class="fa-solid fa-right-to-bracket me-1"></i> Masuk</a>
                            <a href="register.php" class="btn btn-sm btn-warning rounded-pill px-4 fw-bold text-dark flex-fill py-2"><i class="fa-solid fa-user-plus me-1"></i> Daftar</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- KONTEN UTAMA -->
    <div class="container py-4">

        <!-- BANNER COUNTDOWN EVENT WAR -->
        <?php if (!$is_war_ended): ?>
        <div class="card border-0 text-white mb-5 shadow-lg overflow-hidden animate__animated animate__fadeIn" style="background: linear-gradient(135deg, #2A1005 0%, #4E220F 100%); border-radius: var(--radius-lg);">
            <div class="row g-0 align-items-center p-4 p-md-5">
                <div class="col-lg-8">
                    <span class="badge bg-danger px-3 py-2 fw-bold mb-3"><i class="fa-solid fa-bullhorn me-1"></i> PENGUMUMAN <?= htmlspecialchars(strtoupper($nama_event)); ?></span>
                    <h2 class="font-heading fw-bold mb-2">
                        <?= $is_war_active ? '🔥 WAR TIKET SEDANG BERLANGSUNG!' : 'Edisi Terbatas: ' . htmlspecialchars($nama_event); ?>
                    </h2>
                    <p class="text-white-50 mb-3 small">
                        <?= $is_war_active ? 'War tiket resmi dibuka sekarang! Amankan buku eksklusifmu sebelum kehabisan!' : 'Siapkan diri kalian! Hitung mundur menuju mulainya war tiket eksklusif.'; ?>
                    </p>
                    
                    <?php if ($is_war_upcoming): ?>
                    <div class="d-flex gap-2 gap-md-3 mb-4 text-center" style="max-width: 420px;">
                        <div class="bg-dark bg-opacity-50 px-2 px-md-3 py-2 rounded-3 flex-fill">
                            <span id="cd-days" class="fs-4 fw-bold text-warning d-block">00</span>
                            <small class="text-muted" style="font-size: 10px;">Hari</small>
                        </div>
                        <div class="bg-dark bg-opacity-50 px-2 px-md-3 py-2 rounded-3 flex-fill">
                            <span id="cd-hours" class="fs-4 fw-bold text-warning d-block">00</span>
                            <small class="text-muted" style="font-size: 10px;">Jam</small>
                        </div>
                        <div class="bg-dark bg-opacity-50 px-2 px-md-3 py-2 rounded-3 flex-fill">
                            <span id="cd-mins" class="fs-4 fw-bold text-warning d-block">00</span>
                            <small class="text-muted" style="font-size: 10px;">Menit</small>
                        </div>
                        <div class="bg-dark bg-opacity-50 px-2 px-md-3 py-2 rounded-3 flex-fill">
                            <span id="cd-secs" class="fs-4 fw-bold text-warning d-block">00</span>
                            <small class="text-muted" style="font-size: 10px;">Detik</small>
                        </div>
                    </div>
                    <button onclick="pasangPengingat()" class="btn btn-warning rounded-pill px-4 fw-bold text-dark shadow-sm">
                        <i class="fa-solid fa-bell me-2"></i> Pasang Pengingat
                    </button>
                    <?php else: ?>
                        <div class="alert alert-danger fw-bold py-2 px-3 d-inline-block small">
                            <i class="fa-solid fa-circle-exclamation me-1"></i> War Sedang Berlangsung! Berakhir pada: <?= $waktu_selesai; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- ZONA WAR TIKET EKSKLUSIF -->
        <?php if ($is_war_active && $query_buku_war && mysqli_num_rows($query_buku_war) > 0): ?>
        <div class="mb-5 animate__animated animate__fadeIn">
            <div class="d-flex align-items-center justify-content-between mb-3 border-bottom pb-2">
                <h3 class="font-heading fw-bold text-danger mb-0 fs-4">
                    <i class="fa-solid fa-bolt me-2"></i>Zona War Tiket Eksklusif (Limited)
                </h3>
                <span class="badge bg-danger px-3 py-1">Aktif</span>
            </div>
            <div class="row g-4">
                <?php while ($bw = mysqli_fetch_assoc($query_buku_war)): ?>
                    <?php
                    $cover_war_path = "img/war/" . $bw['cover'];
                    $cover_src = file_exists($cover_war_path) ? $cover_war_path : "img/buku/" . $bw['cover'];
                    ?>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card-book border-danger">
                            <div class="book-cover-wrap" style="height: 280px;">
                                <span class="badge bg-danger badge-book">WAR TIKET</span>
                                <img src="<?= htmlspecialchars($cover_src); ?>" alt="<?= htmlspecialchars($bw['judul']); ?>">
                            </div>
                            <div class="p-3 d-flex flex-column flex-grow-1">
                                <small class="text-muted fw-bold mb-1 text-uppercase" style="font-size: 11px;">Eksklusif War</small>
                                <h5 class="fw-bold text-dark mb-1 fs-6 text-truncate" title="<?= htmlspecialchars($bw['judul']); ?>"><?= htmlspecialchars($bw['judul']); ?></h5>
                                <small class="text-muted mb-2"><i class="fa-solid fa-pen-nib me-1"></i><?= htmlspecialchars($bw['penulis']); ?></small>
                                <p class="text-muted small mb-3 text-truncate" style="font-size: 12px;"><?= htmlspecialchars($bw['deskripsi']); ?></p>
                                <div class="price-tag mb-3 mt-auto text-danger">Rp <?= number_format($bw['harga'], 0, ",", "."); ?></div>
                                <?php if ($is_logged_in): ?>
                                    <a href="proses_war.php?buku=<?= $bw['id_buku']; ?>" class="btn btn-danger btn-sm rounded-pill fw-semibold w-100 shadow-sm py-2">
                                        <i class="fa-solid fa-ticket me-1"></i> Ikuti War & Amankan Tiket
                                    </a>
                                <?php else: ?>
                                    <button onclick="requiredLogin('belanja')" class="btn btn-outline-danger btn-sm rounded-pill fw-semibold w-100 py-2">
                                        <i class="fa-solid fa-ticket me-1"></i> Ikuti War Tiket
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- BANNER PROMO DISKON -->
        <div class="banner-promo mb-5 animate__animated animate__fadeIn">
            <div class="row align-items-center">
                <div class="col-md-9 position-relative">
                    <span class="badge bg-warning text-dark fw-bold mb-2 px-3 py-2">PROMO SPESIAL</span>
                    <h2 class="font-heading fw-bold mb-2 fs-3">Diskon Hingga 30% Semua Buku Pilihan!</h2>
                    <p class="mb-3 text-white-50 small">Gunakan kode voucher <strong class="text-white">`SKYBSHEBAT`</strong> saat checkout untuk potongan harga langsung.</p>
                    <button class="btn btn-promo" onclick="pakaiVoucher('SKYBSHEBAT')">
                        <i class="fa-solid fa-ticket me-2"></i>Pakai Sekarang
                    </button>
                </div>
            </div>
        </div>

        <!-- FILTER KATEGORI PILL -->
        <div class="mb-4">
            <div class="category-pills">
                <a href="index.php" class="pill-item <?= empty($selected_kategori) && empty($search_keyword) ? 'active' : ''; ?>">
                    <i class="fa-solid fa-fire me-1"></i> Semua Buku
                </a>
                <?php 
                mysqli_data_seek($query_kategori, 0);
                while ($kat_pill = mysqli_fetch_assoc($query_kategori)): 
                    $is_active_pill = ($selected_kategori == $kat_pill['id_kategori']) ? 'active' : '';
                ?>
                    <a href="index.php?kategori=<?= $kat_pill['id_kategori']; ?>" class="pill-item <?= $is_active_pill; ?>">
                        <?= htmlspecialchars($kat_pill['nama_kategori']); ?>
                    </a>
                <?php endwhile; ?>
            </div>
        </div>

        <!-- FORM PENCARIAN, FILTER JUMLAH TAMPILAN & KATALOG BUKU REGULER -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <h3 class="font-heading fw-bold mb-1 fs-3" style="color: var(--brand-dark-brown);">Katalog Buku Terbaik</h3>
                <p class="text-muted small mb-0">Temukan koleksi novel, komik, modul, dan buku pengetahuan lengkap</p>
            </div>
            
            <div class="d-flex flex-column flex-sm-row gap-2 align-items-stretch align-items-sm-center">
                <!-- Dropdown Pilih Jumlah Buku per Halaman -->
                <form method="GET" action="index.php" class="d-flex align-items-center gap-1">
                    <?php if(!empty($search_keyword)): ?><input type="hidden" name="cari" value="<?= htmlspecialchars($search_keyword); ?>"><?php endif; ?>
                    <?php if(!empty($selected_kategori)): ?><input type="hidden" name="kategori" value="<?= $selected_kategori; ?>"><?php endif; ?>
                    <select name="limit" class="form-select form-select-sm rounded-pill px-3 shadow-sm border-0 py-2" onchange="this.form.submit()">
                        <?php foreach([10, 20, 30, 40, 50] as $l_val): ?>
                            <option value="<?= $l_val; ?>" <?= ($limit == $l_val) ? 'selected' : ''; ?>>Tampil <?= $l_val; ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>

                <!-- Form Pencarian -->
                <form method="GET" action="index.php" class="d-flex gap-2" style="max-width: 320px; width: 100%;">
                    <?php if(!empty($selected_kategori)): ?><input type="hidden" name="kategori" value="<?= $selected_kategori; ?>"><?php endif; ?>
                    <?php if($limit != 10): ?><input type="hidden" name="limit" value="<?= $limit; ?>"><?php endif; ?>
                    <input type="text" name="cari" class="form-control rounded-pill px-4 border-0 shadow-sm py-2" placeholder="Cari judul/penulis..." value="<?= htmlspecialchars($search_keyword); ?>">
                    <button type="submit" class="btn btn-custom-sm rounded-pill px-4 py-2"><i class="fa-solid fa-magnifying-glass"></i></button>
                </form>
            </div>
        </div>

        <!-- DAFTAR GRID BUKU -->
        <div class="row g-3 g-md-4 mb-4">
            <?php if (mysqli_num_rows($query_buku) > 0): ?>
                <?php while ($b = mysqli_fetch_assoc($query_buku)): ?>
                    <?php
                    $cover_path = "img/buku/" . $b['cover'];
                    $img_src = (!empty($b['cover']) && file_exists($cover_path)) ? $cover_path : "https://via.placeholder.com/260x360?text=No+Cover";
                    ?>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card-book">
                            <div class="book-cover-wrap">
                                <?php if (!empty($b['badge'])): ?>
                                    <span class="badge bg-success badge-book"><?= htmlspecialchars($b['badge']); ?></span>
                                <?php endif; ?>
                                <?php if ($is_logged_in): ?>
                                    <a href="wishlist.php?id=<?= $b['id_buku']; ?>" class="btn-wishlist-icon" title="Wishlist"><i class="fa-solid fa-heart"></i></a>
                                <?php else: ?>
                                    <a href="javascript:void(0)" onclick="requiredLogin('wishlist')" class="btn-wishlist-icon" title="Wishlist"><i class="fa-regular fa-heart"></i></a>
                                <?php endif; ?>
                                <img src="<?= $img_src; ?>" alt="<?= htmlspecialchars($b['judul']); ?>">
                            </div>
                            <div class="p-3 d-flex flex-column flex-grow-1">
                                <small class="text-muted fw-bold mb-1 text-uppercase" style="font-size: 10px;">
                                    <?= !empty($b['nama_kategori']) ? htmlspecialchars($b['nama_kategori']) : 'Umum'; ?>
                                </small>
                                <h6 class="fw-bold text-dark text-truncate mb-1 fs-6" title="<?= htmlspecialchars($b['judul']); ?>"><?= htmlspecialchars($b['judul']); ?></h6>
                                <small class="text-muted mb-2 text-truncate" style="font-size: 12px;"><i class="fa-solid fa-pen-nib me-1"></i><?= htmlspecialchars($b['penulis'] ?? 'Anonim'); ?></small>
                                
                                <div class="mb-2">
                                    <?php if ($b['stok'] > 0): ?>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1 rounded-pill" style="font-size: 10px;">
                                            Stok: <?= $b['stok']; ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1 rounded-pill" style="font-size: 10px;">
                                            Stok Habis
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="price-tag mb-3 mt-auto">Rp <?= number_format($b['harga'], 0, ",", "."); ?></div>
                                <div class="d-flex gap-2 align-items-center">
                                    <a href="detail.php?id=<?= $b['id_buku']; ?>" class="btn btn-outline-secondary btn-sm rounded-pill fw-semibold px-3 py-1.5" style="font-size: 12px;">Detail</a>
                                    
                                    <?php if ($b['stok'] > 0): ?>
                                        <?php if ($is_logged_in): ?>
                                            <form action="keranjang.php" method="GET" class="d-flex gap-1 flex-grow-1 align-items-center">
                                                <input type="hidden" name="id" value="<?= $b['id_buku']; ?>">
                                                <input type="hidden" name="qty" value="1">
                                                <button type="submit" class="btn btn-custom-sm flex-grow-1 text-center py-1.5 px-2 shadow-sm" title="Beli"><i class="fa-solid fa-cart-plus me-1"></i> Beli</button>
                                            </form>
                                        <?php else: ?>
                                            <button onclick="requiredLogin('belanja')" class="btn btn-custom-sm flex-grow-1 text-center py-1.5"><i class="fa-solid fa-cart-plus me-1"></i> Beli</button>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <button class="btn btn-secondary btn-sm flex-grow-1 text-center py-1.5 px-2 disabled" style="font-size: 11px; cursor: not-allowed;" title="Stok Habis">
                                            Stok Habis
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 py-5 text-center text-muted">
                    <i class="fa-solid fa-book-open fs-1 mb-3 opacity-50 d-block text-warning"></i>
                    <h5 class="fw-bold">Buku Tidak Ditemukan</h5>
                    <p class="small text-muted">Coba cari dengan kata kunci lain atau pilih kategori yang tersedia.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- NAVIGASI PAGINATION (1-10, 1-20, sampai 50 per halaman) -->
        <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation" class="my-4">
            <ul class="pagination justify-content-center">
                <!-- Tombol Previous -->
                <li class="page-item <?= ($page <= 1) ? 'disabled' : ''; ?>">
                    <a class="page-link rounded-start-pill px-3" href="index.php?page=<?= $page - 1; ?>&limit=<?= $limit; ?><?php if(!empty($search_keyword)) echo '&cari='.urlencode($search_keyword); ?><?php if(!empty($selected_kategori)) echo '&kategori='.$selected_kategori; ?>">
                        <i class="fa-solid fa-angle-left"></i>
                    </a>
                </li>

                <!-- Nomor Halaman -->
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= ($page == $i) ? 'active' : ''; ?>">
                        <a class="page-link" href="index.php?page=<?= $i; ?>&limit=<?= $limit; ?><?php if(!empty($search_keyword)) echo '&cari='.urlencode($search_keyword); ?><?php if(!empty($selected_kategori)) echo '&kategori='.$selected_kategori; ?>">
                            <?= $i; ?>
                        </a>
                    </li>
                <?php endfor; ?>

                <!-- Tombol Next -->
                <li class="page-item <?= ($page >= $total_pages) ? 'disabled' : ''; ?>">
                    <a class="page-link rounded-end-pill px-3" href="index.php?page=<?= $page + 1; ?>&limit=<?= $limit; ?><?php if(!empty($search_keyword)) echo '&cari='.urlencode($search_keyword); ?><?php if(!empty($selected_kategori)) echo '&kategori='.$selected_kategori; ?>">
                        <i class="fa-solid fa-angle-right"></i>
                    </a>
                </li>
            </ul>
        </nav>
        <?php endif; ?>

        <!-- ABOUT US SECTION -->
        <div id="about-section" class="about-card p-4 p-md-5 my-5 shadow-sm">
            <div class="row align-items-center g-4">
                <div class="col-md-5 text-center">
                    <div class="d-inline-flex align-items-center justify-content-center text-white rounded-circle mb-3 shadow" style="width: 80px; height: 80px; font-size: 34px; background: var(--brand-dark-brown);">
                        <i class="fa-solid fa-book-open"></i>
                    </div>
                    <h3 class="font-heading fw-bold mb-1">SKY Bookstore</h3>
                    <p class="text-muted small">Jendela Dunia & Inspirasi Tanpa Batas</p>
                </div>
                <div class="col-md-7">
                    <h4 class="font-heading fw-bold mb-3 fs-4">Cerita Singkat Kami</h4>
                    <p class="text-muted small leading-relaxed mb-4">
                        Didirikan dengan semangat untuk meningkatkan literasi membaca di Indonesia, <strong>SKY Bookstore</strong> hadir sebagai toko buku digital tepercaya yang menyediakan berbagai koleksi buku original berkualitas tinggi.
                    </p>
                    <div class="row g-3">
                        <div class="col-4 text-center text-md-start">
                            <div class="feature-icon-box mx-auto mx-md-0"><i class="fa-solid fa-circle-check"></i></div>
                            <h6 class="fw-bold mb-1 fs-6">100% Original</h6>
                        </div>
                        <div class="col-4 text-center text-md-start">
                            <div class="feature-icon-box mx-auto mx-md-0"><i class="fa-solid fa-truck-fast"></i></div>
                            <h6 class="fw-bold mb-1 fs-6">Kirim Cepat</h6>
                        </div>
                        <div class="col-4 text-center text-md-start">
                            <div class="feature-icon-box mx-auto mx-md-0"><i class="fa-solid fa-headset"></i></div>
                            <h6 class="fw-bold mb-1 fs-6">Layanan 24/7</h6>
                        </div>
                        <?php if (isset($_SESSION['id_admin'])): ?>
                        <div class="mt-3">
                            <a href="admin.php" class="btn btn-sm shadow-sm" style="background:#4E220F;color:#F7F1DE;border-radius:10px;padding:10px 16px;text-decoration:none;font-weight:700;">
                                <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Admin Panel
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- FOOTER RESPONSIF -->
    <footer id="contact-section">
        <div class="container">
            <div class="row g-4 mb-5">
                <div class="col-lg-4">
                    <h4 class="font-heading fw-bold mb-3 text-warning"><i class="fa-solid fa-book-open me-2"></i>SKY Bookstore </h4>
                    <p class="small text-white-50">Platform toko buku digital tepercaya dengan ribuan koleksi novel dan buku pengetahuan terlengkap.</p>
                </div>
                <div class="col-lg-3 col-6">
                    <h6 class="fw-bold text-white mb-3 text-uppercase fs-6">Kategori Pilihan</h6>
                    <ul class="list-unstyled small">
                        <?php 
                        mysqli_data_seek($query_kategori, 0);
                        $count = 0;
                        while ($k_foot = mysqli_fetch_assoc($query_kategori)): 
                            if ($count >= 5) break;
                            $count++;
                        ?>
                            <li class="mb-2"><a href="index.php?kategori=<?= $k_foot['id_kategori']; ?>"><i class="fa-solid fa-angle-right me-1 small"></i> <?= htmlspecialchars($k_foot['nama_kategori']); ?></a></li>
                        <?php endwhile; ?>
                    </ul>
                </div>
                <div class="col-lg-5">
                    <h6 class="fw-bold text-white mb-3 text-uppercase fs-6">Hubungi & Lokasi Kami</h6>
                    <ul class="list-unstyled small text-white-50">
                        <li class="mb-2 d-flex gap-2"><i class="fa-solid fa-location-dot text-warning mt-1"></i><span>Jl. Raya Pendidikan No. 45, Jakarta Pusat</span></li>
                        <li class="mb-2 d-flex gap-2"><i class="fa-solid fa-phone text-warning mt-1"></i><span>+62 858-9140-3949</span></li>
                    </ul>
                </div>
            </div>
            <div class="pt-4 border-top border-secondary border-opacity-25 text-center small text-white-50">
                <p class="mb-0">&copy; <?= date("Y"); ?> <strong>SKY Bookstore </strong>. All Rights Reserved.</p>
            </div>
        </div>
    </footer>

    <!-- JAVASCRIPT COUNTDOWN & INTERAKTIF -->
    <script>
        <?php if ($is_war_upcoming): ?>
        const countDownDate = new Date("<?= str_replace(' ', 'T', $waktu_mulai); ?>").getTime();
        
        const timerInterval = setInterval(function() {
            const now = new Date().getTime();
            const distance = countDownDate - now;
            
            if (distance < 0) {
                clearInterval(timerInterval);
                location.reload(); 
            } else {
                const days = Math.floor(distance / (1000 * 60 * 60 * 24));
                const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((distance % (1000 * 60)) / 1000);

                document.getElementById("cd-days").innerText = String(days).padStart(2, '0');
                document.getElementById("cd-hours").innerText = String(hours).padStart(2, '0');
                document.getElementById("cd-mins").innerText = String(minutes).padStart(2, '0');
                document.getElementById("cd-secs").innerText = String(seconds).padStart(2, '0');
            }
        }, 1000);
        <?php endif; ?>

        function pasangPengingat() {
            alert('Berhasil! Pengingat telah dipasang. Kami akan mengirimkan notifikasi saat War Tiket dimulai.');
        }

        function requiredLogin(action) {
            let msg = action === 'wishlist' ? 'Silakan masuk terlebih dahulu untuk menyimpan buku ke Wishlist!' : 'Silakan masuk terlebih dahulu untuk mengikuti war tiket!';
            if (confirm(msg)) window.location.href = 'login.php';
        }

        function pakaiVoucher(code) {
            <?php if ($is_logged_in): ?>
                alert('Voucher `' + code + '` berhasil diklaim!');
                window.location.href = 'checkout.php?promo=' + code;
            <?php else: ?>
                alert('Silakan login terlebih dahulu untuk klaim voucher!');
                window.location.href = 'login.php';
            <?php endif; ?>
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>